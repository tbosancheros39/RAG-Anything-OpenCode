---
name: reddit-engagement
description: Create and execute robust Reddit engagement workflows (create post, add comment, upvote) using browser accessibility-tree semantics instead of brittle DOM ids/CSS selectors. Use when asked to automate Reddit actions with high success rate across UI changes, A/B tests, and localization differences.
---

# Reddit Engagement

Execute Reddit actions by intent and semantics, not static selectors.

## Content Policy — Read Before Writing Anything

1. **Read `PERSONA.md`** (workspace root) before composing any comment or post.
2. **Never fabricate personal stories** — no invented family members, relationships, health events, or "I personally experienced..." narratives unless the fact is recorded in `PERSONA.md`.
3. Use only: documented personal facts from `PERSONA.md`, opinion-based responses, or general observations that don't claim specific personal experience.
4. After posting, **log it** in the "已使用的故事/内容记录" table in `PERSONA.md` to prevent contradictions across posts.

## Core Operating Rules

1. Use accessibility snapshots (`snapshot` with `refs="aria"`) before every critical step.
2. Target elements by role+label+context, never by fixed DOM id/class/XPath.
3. Re-snapshot after each navigation, modal open/close, submit, or failure.
4. Validate page state before action (logged-in, subreddit resolved, composer visible, button enabled).
5. Require confirmation text for destructive/high-visibility actions when user did not explicitly pre-authorize immediate send.

## Resource Index

| Resource | Location | Purpose |
|----------|----------|---------|
| **Post Strategy** | `references/post-strategy.md` | Content angles, anti-AI rules, subreddit cultures, engagement triggers |
| **Comment Strategy** | `references/comment-strategy.md` | Reply patterns, comment-specific tactics |
| **Interaction Patterns** | `references/interaction-patterns.md` | UI automation playbooks (how to click/type/verify) |
| **Sub Archives** | `references/sub-archives.md` | Core info for all subreddits (one file) |
| **Persona Facts** | `PERSONA.md` (workspace root) | Authentic personal facts to use in content |

## Workflow Router

### Create Post

**Trigger:** user asks to publish in a subreddit.

**Content Generation Flow:**

1. **Determine Input Type**
   - If user provides full content (title + body) → use as-is, skip strategy
   - If user provides fuzzy request (e.g., "post about X") → execute strategy flow below

2. **Strategy Flow** (for fuzzy requests)
   a. Identify target subreddit — extract from user request or ask
   b. Load sub profile — read `references/post-strategy.md` for subreddit rules/tone
   c. Select content angle — read `references/post-strategy.md` for angle matching intent
   d. Load persona facts — read `PERSONA.md` for authentic personal facts
   e. Apply anti-AI rules — avoid AI-sounding language
   f. Draft content — combine sub profile + angle + persona facts + anti-AI rules
   g. Add engagement hook — for comment triggers
   h. Craft title — subreddit-specific title patterns

3. **Confirmation** — Echo generated content to user for approval (unless pre-authorized)

4. **Publish** — Execute `references/interaction-patterns.md` §1 (Create Post workflow)

5. **Log Usage** — Update `PERSONA.md` content tracking table

### Create Comment

**Trigger:** user asks to reply to a post or comment.

1. **Determine Input Type** — full text vs fuzzy request
2. **Strategy Flow** — read target, check sub archive, load persona facts, draft comment, apply anti-AI rules
3. **Confirmation** — echo to user unless pre-authorized
4. **Publish** — Execute `references/interaction-patterns.md` §2 (Create Comment workflow)
5. **Log Usage** — update `PERSONA.md` if persona facts were used

### Upvote

**Trigger:** user asks to like/upvote a post or comment.

**Flow:** Execute `references/interaction-patterns.md` §3 (Upvote workflow) — no content generation needed.

## Universal Reliability Loop

For each action step:

1. Snapshot current tab with aria refs.
2. Resolve target candidates by semantic cues (role, accessible name, nearby headings/text).
3. Score candidates (exact intent match > synonym match > position-based guess).
4. Execute one action.
5. Verify outcome with independent evidence (state change, toast, button state, new content visible).
6. If verification fails, rollback one step and retry with next candidate.

Stop after 3 failed attempts and return a clear diagnostic with:
- last confirmed state
- failing intent
- top 2 alternate hypotheses

## Semantic Targeting Standard

Prefer these signals (highest to lowest confidence):

1. Accessible role + accessible name exact match (e.g., button "Post", "Comment", "Upvote").
2. Accessible name synonym match (e.g., "Submit", "Reply", "Send").
3. Relative context anchor (inside composer region; under post action row; near subreddit title).
4. Visibility and enabled state checks.

Never rely on:
- hardcoded CSS selectors
- hardcoded DOM ids/classes
- absolute XPath
- static child index paths

## Submission Safety Gates

Before clicking final submit:

1. Echo target summary: subreddit/post URL/action/content preview.
2. Ensure required fields are non-empty and within Reddit limits.
3. Confirm account/session is authenticated.
4. Confirm no blocking validation/errors are visible.

If explicit user request already includes immediate-send intent, submit directly. Otherwise ask one short confirmation.

## Fast Troubleshooting

- Login wall/captcha: pause and ask user to complete challenge, then resume from latest snapshot.
- Button exists but disabled: inspect missing required fields or rate limits.
- Multiple matching buttons: choose candidate within nearest semantic container.
- UI redesign: rely on role/name/context fallback chain from `references/interaction-patterns.md`.
