---
name: agentseal-mcp
description: Security toolkit for AI agents with 225+ adversarial attack probes. Detects MCP poisoning, scans skill files, audits live MCP servers, and provides trust scoring. Use when red-teaming AI agents and MCP security assessment.
---

# AgentSeal - AI Agent Security Toolkit

## When to Use

- **AI agent red teaming** - Attack AI agents to find vulnerabilities
- **MCP security auditing** - Scan MCP servers for vulnerabilities
- **Skill file scanning** - Analyze AI skill definitions for threats
- **Trust scoring** - Evaluate AI agent security posture

## Features

- **225+ adversarial attack probes** - Comprehensive attack coverage
- **82 extraction techniques** - Data exfiltration methods
- **143 injection techniques** - Prompt injection patterns
- **MCP server auditing** - Scan-mcp command for live servers
- **Real-time file watcher** - Shield command for ongoing monitoring
- **Trust score (0-100)** - Deterministic security rating
- **MCP protocol support** - Full MCP security assessment

## Installation

```bash
pip install agentseal
```

## Usage

### Prompt Security Testing
```bash
# Scan a system prompt
agentseal scan --prompt "Your system prompt here"

# Test with example prompt
agentseal scan --prompt-file system_prompt.txt
```

### MCP Server Auditing
```bash
# Scan live MCP server
agentseal scan-mcp --url https://mcp-server.com

# Audit MCP configuration
agentseal audit-mcp --config ./mcp-config.json
```

### Skill File Scanning
```bash
# Scan skill files
agentseal scan-skill --path ./my-skill

# Batch scan
agentseal scan-skill --directory ./skills/
```

### Real-time Monitoring
```bash
# Watch for attacks
agentseal shield --watch

# With custom rules
agentseal shield --rules custom_rules.yaml
```

## Trust Score

The trust score (0-100) is deterministic and based on:
- Number of successful injection vectors
- Extraction capability exposure
- Tool abuse potential
- Privilege escalation paths

## Integration with Systemv2.5

| Systemv2.5 Category | AgentSeal Capability |
|---------------------|---------------------|
| AI Threat Testing | 225+ attack probes for AI systems |
| MCP Security | MCP server auditing |
| Red Team | AI agent vulnerability discovery |

## Attack Categories

| Type | Count |
|------|-------|
| Extraction Techniques | 82 |
| Injection Techniques | 143 |
| Tool Abuse Patterns | 45 |
| Privilege Escalation | 28 |

## Detection Coverage

- Prompt injection (direct, indirect, context)
- Tool abuse and unauthorized access
- Data exfiltration paths
- Session manipulation
- Model extraction