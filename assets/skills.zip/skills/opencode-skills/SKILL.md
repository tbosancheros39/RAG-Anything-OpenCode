---
name: opencode-skills
description: OpenCode skill development guide — explains the difference between opencode skills and openclaw/Claude Code skills, skill format, frontmatter schema, and integration patterns.
---

# OpenCode Skills Guide

This skill provides guidance on creating, converting, and integrating skills for OpenCode — the CLI agentic coding tool. Use this when creating new skills, porting skills from Claude Code (openclaw), or resolving skill integration issues.

## When to Activate

- User mentions "opencode skill", "create skill for opencode", "openclaw vs opencode skills", or similar
- Creating a new skill for OpenCode
- Converting a Claude Code/openclaw skill to work with OpenCode
- Fixing skill integration issues in OpenCode
- Questions about skill format or frontmatter schema

## Core Concept: OpenCode vs OpenClaw Skills

OpenCode and Claude Code (openclaw) share the same skill format with one critical difference:

| Field | Claude Code (openclaw) | OpenCode |
|-------|------------------------|----------|
| `name` | Required | Required |
| `description` | Required | Required |
| `origin` | Optional | Optional |
| `tools` | **Supported** | **Not supported** |

OpenCode does NOT have model parameter configuration. Skills only need `description` and `name` — OpenCode handles model routing internally.

## Skill Format

### File Structure

```
skill-name/
└── SKILL.md   ← Required file (capitalized)
```

### Frontmatter Schema

```yaml
---
name: skill-name
description: One-line description of what this skill does
---
```

### SKILL.md Body Structure

```markdown
# Skill Name

Brief description of when to use this skill and what it provides.

## When to Activate

- Trigger condition 1
- Trigger condition 2
- Trigger condition 3

## Core Concepts

Explanation of key concepts...

## Workflow

Step-by-step workflow...

## Examples

Example usage...
```

## Converting OpenClaw Skills to OpenCode

When porting a Claude Code skill to OpenCode:

1. **Remove `tools` field** — OpenCode doesn't support this in frontmatter
2. **Keep `name` and `description`** — These are required
3. **Preserve all content** — Everything else stays the same
4. **Test invocation** — Verify the skill loads with multiple mention variations

### Example: Before (OpenClaw)

```yaml
---
name: my-skill
description: Does something useful
---
```

### Example: After (OpenCode)

```yaml
---
name: my-skill
description: Does something useful
---
```

## Flexible Skill Invocation

OpenCode skills should be invokable regardless of mention variation. The skill system matches on:
- Exact name: `opencode-skills`
- Fuzzy matching: `opencode skill`, `opencode-skills`, `opencode skill creation`
- Hyphen/underscore tolerance: `opencode_skills` ↔ `opencode-skills`

When creating a skill, ensure the `description` field captures the intent so fuzzy matching works.

## Skill Quality Checklist

- [ ] Frontmatter has `name` and `description`
- [ ] No `tools` field (OpenCode doesn't support it)
- [ ] `SKILL.md` is in the correct directory
- [ ] Skill directory name matches `name` in frontmatter
- [ ] Description is 1-2 sentences, clear and actionable
- [ ] "When to Activate" section covers common invocation phrases
- [ ] Content is actionable with concrete steps
- [ ] Examples are provided where helpful

## Directory Locations

| Platform | Path |
|----------|------|
| Linux/macOS | `~/.config/opencode/skills/` |
| Windows | `%APPDATA%/opencode/skills/` |
| Project-level | `.opencode/skills/` |

## Common Issues

### Skill not loading
- Check `SKILL.md` exists (capitalized)
- Verify frontmatter has `name` and `description`
- Ensure directory name matches `name` field
- Restart OpenCode after adding skill

### Wrong skill invoked
- Be more specific in skill description
- Rename skill to be more distinctive
- Use consistent naming (kebab-case recommended)

### Skill works in Claude Code but not OpenCode
- Remove any `tools` field from frontmatter
- OpenCode skills don't support model parameter configuration

## See Also

- `configure-ecc` — For installing ECC skills to OpenCode
- `skill-stocktake` — For auditing installed skills
