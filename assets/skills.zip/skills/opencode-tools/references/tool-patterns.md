# Tool Patterns

Annotated TypeScript implementations of common OpenCode plugin tools.

---

## Path-Safe File Reader

Prevents directory traversal attacks by resolving paths against the project root.

```typescript
import { Plugin, tool } from "@opencode-ai/plugin";
import path from "path";

export const SafeFileReader: Plugin = async (ctx) => {
  return {
    tool: {
      safe_read: tool({
        description: "Read a file from the project directory with path traversal protection",
        args: {
          filePath: tool.schema.string().describe("Relative path to file within project"),
        },
        async execute(args, context) {
          const { directory, worktree } = context;
          
          // Resolve the absolute path
          const resolved = path.resolve(directory, args.filePath);
          
          // Ensure the resolved path stays within the project
          const worktreeRoot = path.resolve(worktree);
          if (!resolved.startsWith(worktreeRoot)) {
            return `Error: Path "${args.filePath}" escapes project root`;
          }
          
          const result = await ctx.$`cat ${resolved}`.quiet().nothrow().text();
          return result || "(empty file)";
        },
      }),
    },
  };
};
```

---

## Bash Override with Allowlist

Hardens the built-in bash tool by enforcing command allowlisting.

```typescript
import { Plugin } from "@opencode-ai/plugin";

const ALLOWED_PREFIXES = [
  "git ",
  "npm ",
  "npx ",
  "pnpm ",
  "yarn ",
  "bun ",
  "node ",
  "python ",
  "python3 ",
  "make ",
  "cargo ",
  "go ",
];

const BLOCKED_PATTERNS = [
  /;\s*rm\s+-rf/i,
  />\s*\/dev\/null/i,
  /curl\s+.*\|.*sh/i,
  /wget\s+.*\|.*sh/i,
];

export const BashHardener: Plugin = async (ctx) => {
  return {
    "tool.execute.before": async (input, output) => {
      if (input.tool !== "bash") return;
      
      const command: string = output.args.command ?? "";
      
      // Check allowlist
      const allowed = ALLOWED_PREFIXES.some(prefix => command.startsWith(prefix));
      if (!allowed) {
        throw new Error(`Command not in allowlist: ${command.split(" ")[0]}`);
      }
      
      // Check blocklist patterns
      const blocked = BLOCKED_PATTERNS.some(pattern => pattern.test(command));
      if (blocked) {
        throw new Error(`Command matches blocked pattern: ${command}`);
      }
    },
  };
};
```

---

## Audited HTTP Client

Makes HTTP requests scoped to an allowlist of hosts with full audit logging.

```typescript
import { Plugin, tool } from "@opencode-ai/plugin";

const ALLOWED_HOSTS = [
  "api.github.com",
  "api.opencode.ai",
  "localhost",
];

export const AuditedHttpClient: Plugin = async (ctx) => {
  return {
    tool: {
      http_get: tool({
        description: "Perform an audited GET request to an allowlisted host",
        args: {
          url: tool.schema.string().describe("Full URL to fetch"),
        },
        async execute(args, context) {
          let url: URL;
          try {
            url = new URL(args.url);
          } catch {
            return "Error: Invalid URL";
          }
          
          // Host allowlist check
          if (!ALLOWED_HOSTS.includes(url.hostname)) {
            return `Error: Host "${url.hostname}" not in allowlist`;
          }
          
          // Audit log entry
          await ctx.client.app.log({
            body: {
              service: "audited-http",
              level: "info",
              message: "HTTP GET request",
              extra: {
                host: url.hostname,
                path: url.pathname,
                sessionID: context.sessionID,
              },
            },
          });
          
          const result = await ctx.$`curl -s ${args.url}`.quiet().nothrow().text();
          return result || "(no content)";
        },
      }),
    },
  };
};
```

---

## Shell Environment Injector

Injects environment variables into all shell executions.

```typescript
import { Plugin } from "@opencode-ai/plugin";

export const EnvInjector: Plugin = async (ctx) => {
  return {
    "shell.env": async (input, output) => {
      output.env.PROJECT_ROOT = input.cwd;
      output.env.OPENCODE_SESSION = "1";
      // Inject secrets from a vault or env file
      // output.env.API_KEY = await getSecret("api-key");
    },
  };
};
```

---

## Session Activity Logger

Logs all tool executions with timing and session context.

```typescript
import { Plugin } from "@opencode-ai/plugin";

export const ActivityLogger: Plugin = async (ctx) => {
  return {
    "tool.execute.after": async (input, output) => {
      const duration = Date.now() - (input.args._startTime ?? Date.now());
      
      await ctx.client.app.log({
        body: {
          service: "activity-logger",
          level: "info",
          message: "Tool executed",
          extra: {
            tool: input.tool,
            sessionID: input.sessionID,
            duration,
            success: output.title !== "error",
          },
        },
      });
    },
    "tool.execute.before": async (input, output) => {
      // Attach start time for duration calculation
      output.args._startTime = Date.now();
    },
  };
};
```

---

## Key Principles

1. **Narrow parameter surface** — Only request what the tool genuinely needs
2. **Validate and sanitize** — Block path traversal, reject injection patterns
3. **Constrain execution** — Set timeouts, cap output size, pin working directory
4. **Write structured audit entries** — Every invocation logged with inputs and outcome
5. **Sanitize output** — Strip credentials and tokens before returning to model context
