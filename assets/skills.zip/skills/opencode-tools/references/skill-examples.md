# Skill Examples

Complete SKILL.md examples for security-focused workflows.

---

## YARA Rule Development Skill

A methodology skill for writing and testing YARA malware detection rules.

```markdown
---
name: yara-rule-development
description: Use when creating or debugging YARA rules for malware detection, threat hunting, or file scanning. Triggers on requests involving YARA syntax, rule writing, malware classification, or threat hunting workflows.
---

# YARA Rule Development

## When to Use

- Writing YARA rules from scratch for malware detection
- Debugging existing YARA rules that aren't matching correctly
- Adapting rules from public repositories to your target set
- Threat hunting: scanning files/processes to identify IOCs
- Validating rule syntax and testing against sample files

## Workflow

### 1. Identify Detection Objectives

Before writing any rule, define:
- What is the target malware family or threat actor?
- What are the static indicators (file strings, PE headers, hash patterns)?
- What is the operational context (file scanning, memory scanning, network)?

### 2. Gather Indicators

Collect IOCs that are:
- **Specific**: Unique to the malware, not common strings
- **Stable**: Won't change between variants
- **Actionable**: Lead to clear detection outcomes

Good indicators:
- Unique copyrighted strings
- Specific PE section names
- Encrypted/obfuscated string patterns
- Characteristic byte sequences

Bad indicators (avoid):
- Generic malware-related keywords ("malware", "trojan")
- File paths or attacker-controlled values
- Timestamps or artifact fields

### 3. Write the Rule

Structure:
```
rule PackageName_MalwareFamily {
    meta:
        description = "Detects PackageName malware"
        author = "Your name"
        date = "2026-03-28"
        severity = 85
        hash = "abc123..."
    strings:
        $s1 = "unique string 1" fullword
        $s2 = "another unique string" wide
        $b1 = { 4D 5A 90 00 } // PE header magic
    condition:
        uint16(0) == 0x5A4D and
        3 of them
}
```

### 4. Validate Syntax

```bash
# Check rule syntax
yarac rule.yar rule.yar

# Test against known-good samples (should not match)
yara -r rule.yar /path/to/clean/files/

# Test against malware samples (should match)
yara -r rule.yar /path/to/malware/samples/
```

### 5. Tune for Precision

- Require multiple unique strings to reduce false positives
- Add size constraints (`filesize < 10MB`)
- Use `fullword` modifier to avoid partial matches
- Add PE-specific conditions when targeting Windows executables

## Output Format

Report for each rule:
```
Rule: <name>
Severity: <1-100>
Matched: <count> samples
False Positives: <count> in clean set
Strings: <count> used, <count> unique
Status: [Draft|Validated|Mature]
```

## Validation Checklist

- [ ] Rule compiles without errors
- [ ] No matches on clean file corpus (>1000 samples recommended)
- [ ] All malware samples detected
- [ ] Meta fields complete (author, date, severity)
- [ ] Private rule (no public sharing without sanitization)
```

---

## Volatility Memory Forensics Skill

Methodology for analyzing memory dumps with the Volatility framework.

```markdown
---
name: volatility-memory-forensics
description: Use when analyzing memory dumps from compromised systems, performing incident response memory analysis, or extracting forensic artifacts from RAM. Triggers on memory forensics, Volatility usage, or incident response workflows.
---

# Volatility Memory Forensics

## When to Use

- Analyzing a memory dump from an incident response engagement
- Extracting running processes, network connections, or loaded modules
- Identifying injected code or rootkit behavior in RAM
- Recovering passwords, keys, or decrypted data from memory
- Timeline reconstruction from a memory capture

## Workflow

### 1. Profile Identification

```bash
volatility3 -f memory.dmp windows.info
# Or for older formats:
volatility -f memory.img --profile=Win10x64_19041 windows.info
```

Identify the OS version and build — this determines which profile to use.

### 2. Process Analysis

```bash
# List all processes
volatility3 -f memory.dmp windows.pslist

# Find hidden/injected processes
volatility3 -f memory.dmp windows.malfind

# Check for suspicious DLLs
volatility3 -f memory.dmp windows.dlllist
```

Look for:
- Processes with no parent (orphaned)
- Mismatched PID/PPID relationships
- Suspicious names or paths
- Code injection signatures in memory regions

### 3. Network Artifacts

```bash
# Active network connections
volatility3 -f memory.dmp windows.netscan

# Historical connections (if available)
volatility3 -f memory.dmp windows.netstat
```

Identify:
- C2 beacon patterns (long-dormant connections, unusual ports)
- Lateral movement (internal IP connections)
- Unknown protocols or encrypted channels

### 4. Credential Extraction

```bash
# LSASS dump for credential theft analysis
volatility3 -f memory.dmp windows.lsadump

# Cached credentials
volatility3 -f memory.dmp windows.hashdump
```

### 5. Artifact Timeline

```bash
# Command history from memory
volatility3 -f memory.dmp windows.cmdscan

# Clipboard contents
volatility3 -f memory.dmp windows.clipboard

# Browser history (if process was live)
volatility3 -f memory.dmp windows.browsers
```

## Output Format

```
Incident: <ticket/case ID>
Memory Source: <hostname> | <acquisition timestamp>
Profile: <OS version>
Duration: <analysis time>

Key Findings:
1. <Process name> (PID <N>) — <suspicious behavior>
2. <Network connection> — <C2 indicator>
3. <Credential access> — <technique used>

Artifact Highlights:
- Files created: <count>
- Processes run: <count>
- Network connections: <count>
- Credentials recovered: <count>

Recommendations:
- <containment action>
- <further investigation>
```

## Key Principles

1. **Corroborate** — Don't trust single artifacts; find at least 2-3 indicators before concluding
2. **Timeline** — Reconstruct the sequence of events; many artifacts lose context in isolation
3. **Hash everything** — Submit suspicious processes/files for VT, Malware Bazaar, or your private sandbox
4. **Preserve** — Never write to the original memory dump; work on a copy
```

---

## Threat Hunt Hypothesis Methodology

Structured approach to proactive threat hunting based on MITRE ATT&CK.

```markdown
---
name: threat-hunt-hypothesis
description: Use when conducting proactive threat hunting operations, developing hunt missions based on threat intelligence, or building detection content from adversary behavior. Triggers on threat hunting, ATT&CK-based investigations, or detection engineering.
---

# Threat Hunt Hypothesis Methodology

## When to Use

- Planning a proactive threat hunt based on threat intelligence
- Developing hunt missions from ATT&CK techniques
- Building detection content based on observed adversary behavior
- Testing detection coverage against known attack paths
- Post-incident: validating that certain attacks would have been caught

## Hypothesis-Driven Hunt Framework

### Structure

Every hunt starts with a testable hypothesis:

```
HUNT-<YYYYMMDD>-###: <Adversary/Technique> is present because <observable/rationale>
```

Example:
```
HUNT-20260328-001: APT29 is using valid accounts with weak passwords because 
our monitoring shows 3 login attempts with the same hash from two geographic 
locations within 4 hours
```

### The Hunt Cycle

```
┌─────────────────────────────────────────────────────┐
│  1. Hypothesis    ← Intel + Environment context     │
├─────────────────────────────────────────────────────┤
│  2. Hunt Feeds    ← Logging, SIEM, EDR, Network    │
├─────────────────────────────────────────────────────┤
│  3. Analytics     ← Query, correlate, detect        │
├─────────────────────────────────────────────────────┤
│  4. Findings      ← True Positive / False Positive   │
├─────────────────────────────────────────────────────┤
│  5. Resolution    ← Close, Escalate, New Hypothesis │
└─────────────────────────────────────────────────────┘
```

## Hunt Planning Checklist

### Intelligence Gathering

- [ ] MITRE ATT&CK technique selected
- [ ] Known adversary group (APTXX) or generic technique
- [ ] Prerequisites: what logging is in place?
- [ ] Time window to search (depends on log retention)
- [ ] Scope: endpoints, network, cloud, identity?

### Environment Context

- [ ] Normal baseline established (normal users, expected software)
- [ ] Known good artifacts (signed binaries, legitimate processes)
- [ ] Recent changes (new software, infrastructure changes)
- [ ] Current threat landscape (active campaigns targeting your industry)

### Detection Mapping

Map your hypothesis to specific log sources:

| ATT&CK Technique | Log Source | Search Query |
|-------------------|------------|--------------|
| T1070.004 (File Deletion) | Sysmon Event ID 23 | `windbkdeletefile` |
| T1059.001 (PowerShell) | Windows Security 4104 | `scriptblock text contains "encodedcommand"` |
| T1562.001 (Disable Security Tools) | Windows Defender event log | `Antimalware health messages` |

## Validation

After the hunt completes:

```
Hunt ID: HUNT-20260328-001
Status: [Closed - Clear | Escalated | Ongoing]
Duration: <X hours>
Coverage:
  - Endpoints searched: <N>
  - Log sources queried: <list>
  - Time range: <window>

Results:
  - True Positives: <count>
  - False Positives: <count>
  - Inconclusive: <count>

Detection Gaps Identified:
  1. <gap> — <recommendation>
  2. <gap> — <recommendation>

Artifacts:
  - Saved queries: <location>
  - IOCs extracted: <location>
  - Detection rules created: <count>
```

## Key Principles

1. **Hunt to find, not to confirm** — Assume breach; your job is to prove or disprove presence
2. **Start narrow** — Hunt one technique thoroughly before expanding scope
3. **Document everything** — Null results are still results; they show coverage is working
4. **Automate the recurring** — Turn successful hunts into detection rules or automated searches
5. **Feed back to threat intel** — Findings inform future hunts and threat models
```

---

## Common Skill Structure

Every skill should follow this template:

```markdown
---
name: skill-name
description: Use when [specific trigger]. Triggers on [contexts where this applies].
---

# Skill Title

## When to Use

- Context 1
- Context 2

## Workflow

### Step 1: [Name]
Brief description of the step.

### Step 2: [Name]
Brief description of the step.

## Output Format

Describe expected output structure.

## Validation Checklist

- [ ] Item 1
- [ ] Item 2
```
