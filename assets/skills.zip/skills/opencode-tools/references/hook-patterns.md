# Hook Patterns

Annotated implementations of OpenCode plugin hooks for common enforcement and augmentation scenarios.

---

## Rate Limiter

Detects and blocks runaway loop tool calls by tracking invocation frequency.

```typescript
import { Plugin } from "@opencode-ai/plugin";

const RATE_LIMIT_WINDOW_MS = 10_000; // 10 second window
const RATE_LIMIT_MAX_CALLS = 20;

export const RateLimiter: Plugin = async (ctx) => {
  const callHistory = new Map<string, number[]>();
  
  return {
    "tool.execute.before": async (input, output) => {
      const now = Date.now();
      const key = `${input.sessionID}:${input.tool}`;
      
      // Get existing timestamps for this session+tool
      const timestamps = callHistory.get(key) ?? [];
      
      // Filter to only recent calls within the window
      const recent = timestamps.filter(t => now - t < RATE_LIMIT_WINDOW_MS);
      
      if (recent.length >= RATE_LIMIT_MAX_CALLS) {
        throw new Error(
          `Rate limit exceeded: ${input.tool} called ${recent.length} times in ${RATE_LIMIT_WINDOW_MS}ms. ` +
          `Max allowed: ${RATE_LIMIT_MAX_CALLS}`
        );
      }
      
      // Record this call
      recent.push(now);
      callHistory.set(key, recent);
    },
  };
};
```

---

## Allowlist Enforcement

Enforces explicit command allowlist for bash tool — safer than blocklists.

```typescript
import { Plugin } from "@opencode-ai/plugin";

const ALLOWED = new Set([
  "git", "npm", "npx", "pnpm", "yarn", "bun",
  "node", "python", "python3", "make", "cargo", "go",
  "ls", "cat", "grep", "find", "head", "tail",
]);

export const BashAllowlister: Plugin = async (ctx) => {
  return {
    "tool.execute.before": async (input, output) => {
      if (input.tool !== "bash") return;
      
      const command: string = output.args.command ?? "";
      const base = command.trim().split(/\s+/)[0];
      
      if (!ALLOWED.has(base)) {
        throw new Error(
          `Command "${base}" not in allowlist. ` +
          `Allowed: ${[...ALLOWED].join(", ")}`
        );
      }
    },
  };
};
```

---

## Secret Scrubber

Strips credentials, tokens, and secrets from tool output before it re-enters model context.

```typescript
import { Plugin } from "@opencode-ai/plugin";

const SECRET_PATTERNS = [
  /(?<![A-Za-z0-9/+=])[A-Za-z0-9/+=]{40,}(?![A-Za-z0-9/+=])/g, // Long base64 strings
  /sk-[a-zA-Z0-9]{48}/g,                                         // OpenAI keys
  /ghp_[a-zA-Z0-9]{36}/g,                                        // GitHub tokens
  /xox[baprs]-[a-zA-Z0-9]{10,}/g,                                // Slack tokens
  /Bearer\s+[A-Za-z0-9\-._~+\/]+=*/g,                           // Bearer tokens
  /password\s*[=:]\s*["']?[^\s"'`]+/gi,                           // Password assignments
];

export const SecretScrubber: Plugin = async (ctx) => {
  const scrub = (text: string): string => {
    let result = text;
    for (const pattern of SECRET_PATTERNS) {
      result = result.replace(pattern, "[REDACTED]");
    }
    return result;
  };
  
  return {
    "tool.execute.after": async (input, output) => {
      output.output = scrub(output.output);
      output.title = output.title === "error" ? "error" : scrub(output.title);
    },
  };
};
```

---

## Structured JSONL Audit Trail

Writes machine-parseable audit entries for every tool call.

```typescript
import { Plugin } from "@opencode-ai/plugin";
import { appendFile } from "fs/promises";
import path from "path";

export const AuditLogger: Plugin = async (ctx) => {
  const auditPath = path.join(ctx.directory, ".opencode-audit.jsonl");
  
  return {
    "tool.execute.before": async (input, output) => {
      const entry = {
        event: "tool.call",
        timestamp: new Date().toISOString(),
        sessionID: input.sessionID,
        tool: input.tool,
        args: output.args,
      };
      await appendFile(auditPath, JSON.stringify(entry) + "\n").catch(() => {});
    },
    "tool.execute.after": async (input, output) => {
      const entry = {
        event: "tool.result",
        timestamp: new Date().toISOString(),
        sessionID: input.sessionID,
        tool: input.tool,
        success: output.title !== "error",
        duration: Date.now(),
      };
      await appendFile(auditPath, JSON.stringify(entry) + "\n").catch(() => {});
    },
  };
};
```

---

## Permission Auto-Approver

Auto-approves trusted operations while logging all permission requests.

```typescript
import { Plugin } from "@opencode-ai/plugin";

const TRUSTED_PATTERNS = [
  { permission: "read", pattern: /\.md$/ },
  { permission: "read", pattern: /^\.gitignore$/ },
  { permission: "bash", pattern: /^git\s+(status|log|diff)/ },
  { permission: "bash", pattern: /^ls\s/ },
];

export const PermissionPolicy: Plugin = async (ctx) => {
  return {
    "permission.ask": async (input, output) => {
      // Log all permission requests
      await ctx.client.app.log({
        body: {
          service: "permission-policy",
          level: "info",
          message: `Permission request: ${input.permission}`,
          extra: { patterns: input.patterns },
        },
      });
      
      // Auto-approve trusted patterns
      const trusted = TRUSTED_PATTERNS.find(
        t => t.permission === input.permission &&
          t.pattern.test(input.patterns[0] ?? "")
      );
      
      if (trusted) {
        output.status = "allow";
      }
    },
  };
};
```

---

## Env File Blocker

Prevents the agent from reading or writing .env files.

```typescript
import { Plugin } from "@opencode-ai/plugin";

const ENV_PATTERNS = [/\.env$/, /\.env\.[a-z]+$/, /credentials\.json$/];

export const EnvProtector: Plugin = async (ctx) => {
  const isEnvPath = (p: string) => ENV_PATTERNS.some(r => r.test(p));
  
  return {
    "tool.execute.before": async (input, output) => {
      if (input.tool === "read" || input.tool === "write") {
        const filePath = output.args.filePath ?? "";
        if (isEnvPath(filePath)) {
          throw new Error(`Access to sensitive file denied: ${filePath}`);
        }
      }
    },
  };
};
```

---

## Chat Params Modifier

Adjusts LLM parameters based on task type (low creativity for code, higher for brainstorming).

```typescript
import { Plugin } from "@opencode-ai/plugin";

export const AdaptiveTemperature: Plugin = async (ctx) => {
  return {
    "chat.params": async (input, output) => {
      const msg = input.message.content.toLowerCase();
      
      if (msg.includes("refactor") || msg.includes("fix bug") || msg.includes("lint")) {
        // Code-focused tasks: low temperature for precision
        output.temperature = 0.2;
        output.topP = 0.8;
      } else if (msg.includes("brainstorm") || msg.includes("design") || msg.includes("creative")) {
        // Creative tasks: higher temperature
        output.temperature = 0.8;
        output.topP = 0.95;
      }
      // Otherwise keep defaults
    },
  };
};
```

---

## Output Size Cap

Prevents tool output from exceeding a max size to protect context window.

```typescript
import { Plugin } from "@opencode-ai/plugin";

const MAX_OUTPUT_BYTES = 50_000; // 50KB

export const OutputCap: Plugin = async (ctx) => {
  return {
    "tool.execute.after": async (input, output) => {
      const outputStr: string = output.output ?? "";
      if (outputStr.length > MAX_OUTPUT_BYTES) {
        const truncated = outputStr.slice(0, MAX_OUTPUT_BYTES);
        output.output = `${truncated}\n\n[Output truncated at ${MAX_OUTPUT_BYTES} bytes — full output not shown to preserve context]`;
      }
    },
  };
};
```

---

## Key Principles

1. **Pre-execution hooks** can block by throwing — use for validation, allowlisting, rate limiting
2. **Post-execution hooks** modify `output` — use for scrubbing, capping, logging
3. **Input is read-only** — never mutate `input` directly; modify `output` only
4. **Async all the way** — all hooks are async, use `await` for filesystem and network
5. **Fail gracefully** — use try/catch around file writes and external calls
