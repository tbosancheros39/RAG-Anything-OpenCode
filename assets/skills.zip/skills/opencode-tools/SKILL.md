---
name: opencode-tools
description: Use when implementing local tools, custom skills, or secure agent tooling in OpenCode without MCP servers. Triggers on requests to create a local tool, replace a built-in OpenCode tool, implement hooks, write a skill for OpenCode, avoid MCP dependencies, sandbox execution, audit tool calls, or build a self-contained secure agent capability. Always use this skill when the user wants full ownership of their OpenCode tool or skill stack.
---

# OpenCode Local Tools & Skills

How to implement tools and skills locally in OpenCode — no MCP servers, no external dependencies, full auditability.

---

## Why Local Instead of MCP

MCP servers introduce remote execution trust boundaries, supply chain risk from unreviewed code, prompt injection surface via tool responses, context window overhead, and network dependencies. Local tools eliminate all of these while providing identical capability at the model level — the `tool_use`/`tool_result` cycle is the same regardless of where execution happens.

---

## Directory Layout

OpenCode resolves skills and tools from two scopes.

**Project scope** (applies to this codebase only):
```
.opencode/
├── skills/name/SKILL.md     ← skill definitions
└── plugins/                 ← plugin hooks and tool overrides
    └── *.ts                ← auto-discovered
```

**Global scope** (applies across all projects):
```
~/.config/opencode/
├── skills/name/SKILL.md
└── plugins/                 ← global plugins
    └── *.ts
```

Skills are registered in `opencode.json` under the `instructions` array. Plugins in `.opencode/plugins/` or `~/.config/opencode/plugins/` are **auto-discovered** at startup — no config registration required.

---

## Plugin Registration Methods

There are three ways to register a plugin:

### Method 1: Local Files (Auto-Discovered)

Place `.ts` or `.js` files in the plugins directory. OpenCode scans `{plugin,plugins}/*.{ts,js}` in `.opencode/` directories.

```
.opencode/
└── plugins/
    └── my-plugin.ts        ← auto-discovered
```

No config entry needed. OpenCode auto-generates `package.json` with `@opencode-ai/plugin` as a dependency and runs `bun install` in the `.opencode/` directory at startup.

### Method 2: npm Package

Specify in `opencode.json`:

```json
{
  "plugin": ["my-opencode-plugin@1.0.0", "@scope/opencode-plugin@latest"]
}
```

OpenCode resolves via `bun install` and imports the package's default `Plugin` export.

### Method 3: File URL

```json
{
  "plugin": ["file:///absolute/path/to/plugin.ts"]
}
```

---

## Dependencies for Local Plugins

Local plugins and custom tools can use external npm packages. Add a `package.json` to the config directory with the dependencies you need:

```json
{
  "dependencies": {
    "@opencode-ai/plugin": "^1.3.3",
    "shescape": "^2.1.0"
  }
}
```

OpenCode runs `bun install` at startup. Your plugins then import them normally:

```typescript
import { escape } from "shescape";
import { tool } from "@opencode-ai/plugin";
```

---

## Creating a Plugin

A plugin is an **async function** that receives a `PluginInput` context and returns a hooks object.

```typescript
import type { Plugin } from "@opencode-ai/plugin";

export const MyPlugin: Plugin = async (ctx) => {
  return {
    // Hooks go here
  };
};
```

### PluginInput (ctx)

```typescript
type PluginInput = {
  client: ReturnType<typeof createOpencodeClient>;  // Internal SDK client (no network)
  project: Project;                                  // Current project metadata
  directory: string;                                 // Project directory (prefer over process.cwd())
  worktree: string;                                 // Git worktree root (stable relative paths)
  serverUrl: URL;                                   // Server URL
  $: BunShell;                                      // Bun shell for executing commands
};
```

### BunShell

The `$` context provides Bun's shell API for command execution:

```typescript
// Basic command
const result = await ctx.$`git status`.quiet().nothrow().text();

// With pipe
await ctx.$`grep -r "pattern" ${ctx.directory}`.quiet().text();

// Chaining modifiers
ctx.$`npm run build`
  .cwd(ctx.directory)           // Set working directory
  .env({ NODE_ENV: "prod" })   // Set env vars
  .nothrow()                    // Don't throw on non-zero exit
  .quiet();                      // Don't echo to stdout
```

---

## Defining Custom Tools

Tools are functions the AI agent can call during a session. They use Zod for argument validation.

```typescript
import { Plugin, tool } from "@opencode-ai/plugin";

export const MyTools: Plugin = async (ctx) => {
  return {
    tool: {
      my_tool: tool({
        description: "What this tool does (shown to the AI)",
        args: {
          name: tool.schema.string().describe("Parameter description"),
          count: tool.schema.number().optional().describe("Optional param"),
          tags: tool.schema.array(tool.schema.string()).describe("Array param"),
          mode: tool.schema.enum(["fast", "slow"]).default("fast"),
        },
        async execute(args, context) {
          // args are fully typed via Zod inference
          // context: ToolContext
          return `Result: ${args.name}`;
        },
      }),
    },
  };
};
```

`tool.schema` is Zod — all Zod types are available:
- `tool.schema.string()`, `tool.schema.number()`, `tool.schema.boolean()`
- `tool.schema.array(schema)`, `tool.schema.object({})`, `tool.schema.enum([])`
- `.optional()`, `.describe("")`, `.default(value)`

### ToolContext

```typescript
type ToolContext = {
  sessionID: string;
  messageID: string;
  agent: string;
  directory: string;    // Prefer over process.cwd() for file paths
  worktree: string;    // For stable relative paths
  abort: AbortSignal;  // Cancellation signal
  metadata(input: { title?: string; metadata?: Record<string, any> }): void;
  ask(input: { permission: string; patterns: string[]; always: string[]; metadata: Record<string, any> }): Promise<void>;
};
```

---

## Available Hooks

### Tool Hooks

```typescript
// Modify tool arguments before execution — can block by throwing
"tool.execute.before"?: (
  input: { tool: string; sessionID: string; callID: string },
  output: { args: any },
) => Promise<void>

// Process tool results after execution — can transform output
"tool.execute.after"?: (
  input: { tool: string; sessionID: string; callID: string; args: any },
  output: { title: string; output: string; metadata: any },
) => Promise<void>

// Modify tool definitions (description and parameters) sent to LLM
"tool.definition"?: (
  input: { toolID: string },
  output: { description: string; parameters: any },
) => Promise<void>
```

### Session Hooks

```typescript
event?: (input: { event: Event }) => Promise<void>
"session.created"?: (input: { sessionID: string }) => Promise<void>
"session.idle"?: (input: { sessionID: string }) => Promise<void>
"session.compacted"?: (input: { sessionID: string }) => Promise<void>
"session.deleted"?: (input: { sessionID: string }) => Promise<void>
"session.error"?: (input: { sessionID: string; error: string }) => Promise<void>
"session.updated"?: (input: { sessionID: string }) => Promise<void>
"session.diff"?: (input: { sessionID: string }) => Promise<void>
"session.status"?: (input: { sessionID: string; status: string }) => Promise<void>
```

### File Hooks

```typescript
"file.edited"?: (input: { path: string; content: string }) => Promise<void>
"file.watcher.updated"?: (input: { paths: string[] }) => Promise<void>
```

### Command Hooks

```typescript
"command.executed"?: (input: { command: string; args: string[]; status: string }) => Promise<void>
"command.execute.before"?: (
  input: { command: string; sessionID: string; arguments: string },
  output: { parts: Part[] },
) => Promise<void>
```

### Permission Hooks

```typescript
"permission.asked"?: (input: Permission, output: { status: "ask" | "deny" | "allow" }) => Promise<void>
"permission.replied"?: (input: { action: string; target: string; decision: string }) => Promise<void>
```

### Shell Hooks

```typescript
// Inject environment variables into all shell executions
"shell.env"?: (
  input: { cwd: string; sessionID?: string; callID?: string },
  output: { env: Record<string, string> },
) => Promise<void>
```

### Chat Hooks

```typescript
// Called when a new message is received
"chat.message"?: (
  input: { sessionID: string; agent?: string; model?: { providerID: string; modelID: string }; messageID?: string; variant?: string },
  output: { message: UserMessage; parts: Part[] },
) => Promise<void>

// Modify LLM parameters
"chat.params"?: (
  input: { sessionID: string; agent: string; model: Model; provider: ProviderContext; message: UserMessage },
  output: { temperature: number; topP: number; topK: number; options: Record<string, any> },
) => Promise<void>

// Modify request headers sent to LLM provider
"chat.headers"?: (
  input: { sessionID: string; agent: string; model: Model; provider: ProviderContext; message: UserMessage },
  output: { headers: Record<string, string> },
) => Promise<void>
```

### Config Hook

```typescript
config?: (input: Config) => Promise<void>
```

### TUI Hooks

```typescript
"tui.prompt.append"?: (input: { prompt: string }) => Promise<void>
"tui.command.execute"?: (input: { command: string }) => Promise<void>
"tui.toast.show"?: (input: { message: string; type?: string }) => Promise<void>
```

### Experimental Hooks

```typescript
"experimental.chat.messages.transform"?: (
  input: {},
  output: { messages: { info: Message; parts: Part[] }[] },
) => Promise<void>

"experimental.chat.system.transform"?: (
  input: { sessionID?: string; model: Model },
  output: { system: string[] },
) => Promise<void>

"experimental.session.compacting"?: (
  input: { sessionID: string },
  output: { context: string[]; prompt?: string },
) => Promise<void>

"experimental.text.complete"?: (
  input: { sessionID: string; messageID: string; partID: string },
  output: { text: string },
) => Promise<void>
```

---

## Overriding Built-in Tools

If a local tool shares a name with a built-in (e.g. `bash`), the local version takes precedence. This lets you harden defaults:

```typescript
import { Plugin, tool } from "@opencode-ai/plugin";

export const HardenedBash: Plugin = async (ctx) => {
  const ALLOWED = new Set(["git", "npm", "npx", "pnpm", "node", "python"]);
  
  return {
    tool: {
      bash: tool({
        description: "Execute a shell command with hardened security",
        args: {
          command: tool.schema.string().describe("The command to execute"),
        },
        async execute(args, context) {
          const base = args.command.trim().split(/\s+/)[0];
          if (!ALLOWED.has(base)) {
            return `Error: "${base}" not in the allowlist`;
          }
          const result = await ctx.$`${args.command}`
            .cwd(context.directory)
            .quiet()
            .nothrow()
            .text();
          return result || "(no output)";
        },
      }),
    },
  };
};
```

An allowlist (explicit permit) is strictly safer than a blocklist (explicit deny). Prefer allowlists for sensitive tools.

---

## Hook Implementation Patterns

### Pre-execution: Input Validation

```typescript
"tool.execute.before": async (input, output) => {
  if (input.tool === "bash") {
    const cmd: string = output.args.command ?? "";
    if (/;\s*rm\s+-rf/i.test(cmd)) {
      throw new Error("Dangerous command blocked");
    }
  }
}
```

### Post-execution: Output Scrubbing

```typescript
"tool.execute.after": async (input, output) => {
  const scrub = (text: string) =>
    text.replace(/(sk-[a-zA-Z0-9]{48}|ghp_[a-zA-Z0-9]{36})/g, "[REDACTED]");
  output.output = scrub(output.output);
}
```

### Permission Interception

```typescript
"permission.ask": async (input, output) => {
  if (input.permission === "read" && input.patterns.some(p => /\.env$/.test(p))) {
    output.status = "deny";
  }
}
```

---

## Writing a Skill for OpenCode

A skill is a markdown file that injects methodology into the agent's context. It has **no execution capability** — it guides reasoning only.

### Frontmatter

OpenCode recognizes exactly two fields:

```yaml
---
name: skill-name          # lowercase, hyphens only, max 64 chars
description: ...          # when and why to invoke, max 1024 chars
---
```

Any other frontmatter fields (`tools`, `model`, `agents`, `version`, `license`, `metadata`) are **forbidden** in skills. OpenCode ignores them or they may cause undefined behavior.

### Body Structure

```markdown
## When to Use
- Specific trigger context 1
- Specific trigger context 2

## Workflow
### Step 1: [Name]
Brief description.

### Step 2: [Name]
Brief description.

## Output Format
Describe expected output structure.

## Validation Checklist
- [ ] Item 1
- [ ] Item 2
```

Keep SKILL.md under 500 lines. Move detailed reference material to separate files in the skill directory and reference them explicitly so the agent knows when to load them.

---

---

## Load Order

Plugin arrays from multiple config sources are **concatenated** (not replaced), loaded in this order:

1. Remote `.well-known/opencode` (org defaults)
2. Global config (`~/.config/opencode/opencode.json`)
3. Custom config (`OPENCODE_CONFIG`)
4. Project config (`opencode.json`)
5. `.opencode/` directories (auto-discovered local plugins)
6. Inline config (`OPENCODE_CONFIG_CONTENT`)

---

## Common Mistakes

| Mistake | Correct |
|---------|---------|
| Forgetting `async` on Plugin function | `export const P: Plugin = async (ctx) => {}` |
| Returning non-string from `execute` | `execute` must return `string` |
| Using `process.cwd()` for paths | Use `context.directory` or `context.worktree` |
| Mutating `input` in hooks | `input` is read-only — modify `output` only |
| Placing plugin outside `plugins/` | Must be in `{plugin,plugins}/*.{ts,js}` |
| `tool.schema` outside `args` | `tool.schema` is Zod — only use in `args` definition |
| Not handling errors in `execute` | Throw or return error string |
| Non-async hooks | All hooks are async — always use `async` |

---

## Reference Files

- `references/tool-patterns.md` — Path-safe file reader, bash allowlist, HTTP client, env injector, activity logger
- `references/hook-patterns.md` — Rate limiter, allowlist enforcement, secret scrubber, JSONL audit trail, permission auto-approver, env blocker, output cap
- `references/skill-examples.md` — YARA rule development, Volatility memory forensics, threat hunt hypothesis
