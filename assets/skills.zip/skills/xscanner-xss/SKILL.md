---
name: xscanner-xss
description: Next-Generation XSS Detection & Exploitation Framework with async engine, AI payload suggestions, WAF bypass for 9 vendors, and Playwright verification. Use when finding XSS vulnerabilities that traditional scanners miss.
---

# XScanner v3.0 - Advanced XSS Detection Framework

## When to Use

- **Advanced XSS detection** - Beyond basic reflected XSS
- **WAF bypass testing** - Test against Cloudflare, ModSecurity, Imperva, etc.
- **DOM-based XSS** - Client-side vulnerability detection
- **AI-powered payloads** - Claude API for intelligent payload generation
- **Blind XSS** - Out-of-band callback server for stored XSS

## Features

- **Async engine (aiohttp)** - 10x faster than XSStrike
- **FilterProbe** - Concurrent character matrix for filter detection
- **FuzzyDetector** - 6-signal multi-detector for reflection analysis
- **AdaptiveSequencer** - AI-powered payload learning
- **DOM structural diff** - ResponseDiffer for HTML changes
- **Blind XSS server** - Built-in callback listener
- **Playwright verification** - Headless browser proof
- **AI payload suggestions** - Claude API integration
- **WAF bypass** - 9 vendors mapped with 10 evasion techniques

## Installation

```bash
# Clone repository
git clone https://github.com/Auto-runs/xscanner.git
cd xscanner

# Install dependencies
pip install -r requirements.txt

# (Optional) AI payload suggestions
export ANTHROPIC_API_KEY="your-key-here"
```

## Usage

```bash
# Basic scan
python xscanner.py -u "https://yoursite.com/search?q=test"

# Deep scan with WAF bypass
python xscanner.py -u "https://yoursite.com" --deep --threads 5

# Scan from targets file
python xscanner.py -f targets.txt

# With AI payload generation
python xscanner.py -u "https://site.com" --ai-payloads

# Output results
python xscanner.py -u "https://site.com" --json output.json
```

## Presets

| Preset | Threads | Timeout | Delay | Depth | Use Case |
|--------|---------|---------|-------|-------|----------|
| `fast` | 1 | 20 | 5s | 10 | Quick recon |
| `normal` | 2 | 10 | 10s | 30 | Standard pentest |
| `aggressive` | 5 | 5 | 2s | 50 | Deep testing |

## Integration with Systemv2.5

| Systemv2.5 Category | XScanner Capability |
|---------------------|---------------------|
| XSS Testing | Advanced reflected, DOM, stored, blind |
| WAF Evasion | 9 vendor bypass techniques |
| Bug Bounty | High-accuracy XSS discovery |
| Web Scanning | Automated web app testing |

## WAF Bypass Support

```
Cloudflare · ModSecurity · Imperva · AWS WAF · Akamai
Sucuri · F5 BIG-IP · Barracuda · Wordfence
```

## Evasion Techniques

- Case shuffling
- HTML comment injection
- Double URL encoding
- Null byte insertion
- Tab/newline substitution
- Unicode normalization
- Partial entity encoding
- Tag breaking
- Event handler obfuscation

## Detection Capabilities

| Type | Method |
|------|--------|
| Reflected | FilterProbe + FuzzyDetector + HTML position |
| DOM | ResponseDiffer + sink analysis |
| Stored | Blind XSS callback server |
| Blind | OOB detection via built-in server |