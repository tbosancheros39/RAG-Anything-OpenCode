---
name: soushen-hunter
description: 高性能Bing/Google搜索引擎Skill。基于Playwright实现，支持搜索执行、深度页面元素提取、用户代理轮换、Cookie持久化。当用户需要进行网络搜索、提取网页结构信息、绕过简单反爬时触发。
---

# 搜神猎手 (SouShen Hunter)

## 核心功能

### 1. Bing/Google 搜索
执行搜索并返回结构化结果：标题、URL、摘要、来源网站。支持Bing和Google双引擎切换。

### 2. 深度页面分析
对指定URL进行深度扫描，提取：所有链接、表单信息、按钮元素、外部脚本、页面元数据（meta tags、Open Graph等）。

## 使用方法

### 基础搜索
```bash
./soushen "OpenClaw AI Agent"
./soushen "AI 人工智能" --num 20
./soushen "AI" --engine google
```

### 深度页面分析
```bash
./soushen --deep https://example.com
```

### 配置
```bash
./soushen --set-default-engine bing
./soushen --set-default-engine google
./soushen --config
```

### Python API
```python
from bing_search import BingSearchAgent

async with BingSearchAgent(headless=True) as agent:
    results = await agent.search("关键词", num_results=10)

from google_search import GoogleSearchAgent

async with GoogleSearchAgent(headless=True) as agent:
    results = await agent.search("关键词", num_results=10)

elements = await agent.extract_page_elements("https://example.com")
```

## 反检测特性

### Bing
- 禁用自动化控制标记
- 模拟真实用户代理
- 设置合理视口大小

### Google（高级）
- 用户数据目录复用（保留Cookie和会话）
- 浏览器指纹伪装
- 行为模拟（随机延迟、鼠标移动）
- 多用户代理轮换
- 地理位置模拟

## 依赖
- Python 3.8+
- playwright
- Chrome/Chromium

## 注意事项
Google搜索可能遇到人机验证，建议：使用有登录态的Chrome、控制搜索频率（每分钟不超过5-10次）、遇到验证时切换到Bing。
