---
name: phantom-ai
description: Autonomous AI penetration testing agent using ReAct loop with 30+ security tools, Docker sandbox isolation, and verified vulnerability reports. Use when needing AI-driven pentests with proof-of-concept generation.
---

# Phantom - Autonomous Adversary Simulation Platform

## When to Use

- **Autonomous ReAct pentesting** - AI that reasons about targets
- **Verified findings** - Every vulnerability includes working PoC
- **Docker sandbox** - Safe tool execution in isolation
- **MITRE ATT&CK mapping** - Automatically tag findings with ATT&CK techniques

## Features

- **ReAct loop**: Plans → executes tools → reads results → re-plans
- **30+ security tools**: nmap, nuclei, sqlmap, ffuf, httpx, katana, subfinder, etc.
- **Verified findings**: Re-exploits every finding to confirm
- **Docker sandbox isolation**: Safe execution environment
- **OWASP Top 10, PCI DSS, NIST 800-53** compliance mapping
- **100+ LLM providers** via LiteLLM (Anthropic, OpenAI, DeepSeek, Ollama)

## Installation

```bash
# Install via pip
pip install phantom-agent

# Or with pipx for isolation
pipx install phantom-agent
```

## Usage

```bash
# Quick scan (~15 min) - CI/CD friendly
phantom -t https://example.com -m quick

# Deep scan (1-3 hours) - exhaustive coverage
phantom -t https://example.com -m deep

# Use specific LLM
phantom -t https://example.com --llm anthropic/claude-sonnet-4-20250514
```

## Output

Every scan produces:
- `findings.json` - Structured vulnerability data
- `report.md` - Human-readable report
- `evidence/` - Raw HTTP evidence for each finding
- `logs/` - Execution logs

## Integration with Systemv2.5

| Systemv2.5 Category | Phantom Capability |
|---------------------|-------------------|
| Bug Bounty Hunting | Autonomous scanning with verified findings |
| CVE Research | Automatic CVE correlation and exploitation |
| Web Testing | Automated XSS, SQLi, RCE detection |
| Network Scanning | Nmap integration with AI reasoning |

## Tool Stack

| Category | Tools |
|----------|-------|
| Recon | nmap, subfinder, httpx, katana |
| Scanning | nuclei, nikto, ffuf, gobuster |
| Exploitation | sqlmap, commix, xsser |
| Password | hydra, john, hashcat |

## Verification

Every finding is independently re-exploited. Can't reproduce it? Killed as false positive. This eliminates the 40-70% false positive rate typical of traditional scanners.