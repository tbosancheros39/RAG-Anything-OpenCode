---
name: telegram-OC
description: OpenCode Telegram Bot project (grinev/opencode-telegram-bot). Use when working with the OpenCode Telegram Bot on Linux — grammY 1.42 handlers, 34 TypeScript commands, multi-user access control, SSE streaming, BullMQ task queue, system monitoring, systemd deployment with PATH, and local OpenCode server integration. Triggered when user mentions the OpenCode Telegram Bot, grammY, local bridge, or the grinev/opencode-telegram-bot project.
---

# OpenCode Telegram Bot Skill — Local Server Mode

Guides setup, extension, and troubleshooting of the grinev/opencode-telegram-bot project on Linux using **`opencode serve` running locally** (no remote OpenCode cloud API).

---

## Project Overview

| Property | Value |
|----------|-------|
| **Version** | 0.13.2 |
| **Repository** | github.com/grinev/opencode-telegram-bot |
| **npm package** | @grinev/opencode-telegram-bot |
| **License** | MIT |
| **Author** | Ruslan Grinev |
| **Project root** | `/media/ext4_storage/workspace/OpenCodeTelegramBot/opencode-telegram-bot` |

**Concept:** "A single OpenCode CLI window in Telegram" — mobile client for OpenCode AI coding assistant. Bridges Telegram and a locally running OpenCode server so you can send prompts, manage sessions, monitor progress, and receive results — all from your phone.

---

## Architecture

```
Phone (Telegram)
       │
       ▼ polling (no open ports)
Telegram Bot API
       │
       ▼
[opencode-telegram-bot]  ← runs on LOCAL Linux PC
   grammY 1.42 (TypeScript, ESM)
       │
       ▼ HTTP to localhost:4096
[opencode serve]         ← ALSO runs on LOCAL Linux PC
       │
       ▼ HTTPS
AI Model (Anthropic / OpenAI / etc — cloud-hosted)
```

**Key facts:**
- Bot runs **locally** via polling — no open ports, no nginx, no domain
- `opencode serve` runs **on the same machine** as the bot, listening on `localhost:4096`
- `OPENCODE_API_URL` = `http://localhost:4096` — always, no exceptions
- `/shell`, `/ls`, `/read` execute on your **local PC** via the OpenCode SDK's `session.shell()` method
- Results stream back via **SSE (Server-Sent Events)** from the local server
- Security: `TELEGRAM_ALLOWED_USER_ID` restricts access; multi-user support with super/simple/restricted roles
- Session state is **in-memory per chat** — resets on bot restart
- No `OPENCODE_API_KEY` needed — auth is optional via `OPENCODE_SERVER_PASSWORD`

---

## Technology Stack

| Component | Technology |
|-----------|-----------|
| **Language** | TypeScript 5.x (strict mode, ESM) |
| **Runtime** | Node.js 20+ |
| **Package Manager** | npm |
| **Bot Framework** | grammY **1.42.0** (updated 2026-03-01) |
| **Bot Menus** | @grammyjs/menu 1.3+ |
| **OpenCode SDK** | @opencode-ai/sdk 1.1.21 |
| **Task Queue** | BullMQ 5.71 + Redis (ioredis 5.10) |
| **Scheduled Tasks** | better-sqlite3 12.6 |
| **Testing** | Vitest 3.2 + @vitest/coverage-v8 |
| **Linting** | ESLint 8 + Prettier 3.8 |
| **Proxy Support** | socks-proxy-agent, https-proxy-agent |
| **Telegram Formatting** | telegram-markdown-v2 |

---

## Architecture (8 Layers)

1. **Bot Layer** — grammY setup, middleware, commands, callback handlers, streaming (`src/bot/`)
2. **OpenCode Client** — SDK wrapper + SSE event subscription (`src/opencode/`)
3. **State Managers** — session, project, settings, question, permission, model, agent, variant, keyboard, pinned, interaction
4. **Summary Pipeline** — SSE event aggregation → Telegram-friendly formatting (`src/summary/`)
5. **Process Manager** — local OpenCode server start/stop/status (`src/process/`)
6. **Runtime/CLI** — mode detection, config bootstrap, CLI commands (`src/runtime/`, `src/cli/`, `src/cli.ts`)
7. **I18n** — 6 locales: en, de, es, fr, ru, zh (`src/i18n/`)
8. **Safety/Users** — security sandboxing (`src/safety/`), multi-user access control (`src/users/`)

**Data Flow:**
```
Telegram User → grammY Bot → Managers + OpenCodeClient → OpenCode Server (localhost:4096)
OpenCode Server → SSE Events → Summary Aggregator → Telegram Bot → Telegram User
```

---

## Bot Commands (34 total)

All commands are centralized in `src/bot/commands/definitions.ts`.

| Command | Description |
|---------|-------------|
| `/status` | Server, project, session, model info |
| `/new` | Create new session |
| `/abort` | Stop current task |
| `/stop` | Alias for /abort (works while busy) |
| `/sessions` | Browse and switch sessions |
| `/projects` | Switch projects |
| `/task` | Create scheduled task |
| `/tasklist` | Browse/delete scheduled tasks |
| `/rename` | Rename current session |
| `/commands` | Browse and run custom OpenCode commands |
| `/task` | Task management |
| `/tasks` | Task list |
| `/messages` | Browse session messages with fork/revert |
| `/skills` | Browse and select skills |
| `/mcps` | Browse available MCP servers |
| `/models` | Select model |
| `/compact` | Compact context |
| `/journal` | Control systemd journal monitoring |
| `/health` | System health check (disk, memory, load, CPU temp, SMART) |
| `/logs` | View recent logs |
| `/shell <cmd>` | Execute a shell command locally |
| `/ls [path]` | List directory contents |
| `/read <file>` | Read a local file's contents |
| `/opencode_start` | Start OpenCode server (emergency) |
| `/opencode_stop` | Stop OpenCode server (emergency) |
| `/sandbox` | Security sandboxing (bubblewrap) |
| `/cost` | Cost tracking |
| `/diff` | Git diff |
| `/branch` | Git branch management |
| `/commit` | Git commit |
| `/export` | Export session |
| `/notify` | Notification settings |
| `/ask_and_leave` | Ask AI and leave session |
| `/steer` | Steer conversation direction (works while busy) |
| `/help` | Show help |

**Inline menus** provide: model, agent, variant, and context actions (replaced old bottom reply keyboard).

**Inline mode** supports inline commands (e.g., `@bot feynman: explain X`).

**Non-command text** is treated as a prompt for OpenCode when no blocking interaction is active.

**Voice/audio messages** are transcribed via STT (Whisper-compatible: OpenAI, Groq, Together).

**Photo/document messages** are forwarded to OpenCode with vision support.

---

## Environment Setup (Linux)

### System packages

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl git build-essential
```

### Node.js 20+

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
source ~/.bashrc   # or ~/.zshrc
nvm install 20
nvm use 20
```

### Install OpenCode CLI

```bash
npm install -g opencode-ai
# Verify:
opencode --version
```

### Clone & install bot

```bash
git clone https://github.com/grinev/opencode-telegram-bot.git
cd opencode-telegram-bot
npm install
```

---

## Configuration (.env)

```env
# REQUIRED
TELEGRAM_BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrsTUVwxyz
TELEGRAM_ALLOWED_USER_ID=987654321

# LOCAL OpenCode server — NOT a cloud URL
OPENCODE_API_URL=http://localhost:4096

# No OPENCODE_API_KEY needed for local server
# Optionally protect with basic auth:
# OPENCODE_SERVER_USERNAME=opencode
# OPENCODE_SERVER_PASSWORD=your-password

# MODEL — configured in opencode itself, matched here
OPENCODE_MODEL_PROVIDER=opencode
OPENCODE_MODEL_ID=big-pickle   # free default

# OPTIONAL
BOT_LOCALE=en
LOG_LEVEL=info
SERVICE_MESSAGES_INTERVAL_SEC=5
RESPONSE_STREAMING=true
MESSAGE_FORMAT_MODE=markdown
HIDE_THINKING_MESSAGES=false
HIDE_TOOL_CALL_MESSAGES=false
```

> **Critical:** `OPENCODE_API_URL` must be `http://localhost:4096`.

---

## Running — Two Processes Required

You need **both** processes running on your PC simultaneously.

### Terminal 1 — Start OpenCode Server

```bash
cd /path/to/your/project   # e.g. ~/projects/my-app
opencode serve --port 4096
```

### Terminal 2 — Start the Bot

```bash
cd /media/ext4_storage/workspace/OpenCodeTelegramBot/opencode-telegram-bot
npm run dev
```

---

## Project Structure

```
opencode-telegram-bot/
├── .env
├── package.json
├── tsconfig.json
├── vitest.config.ts
├── src/
│   ├── index.ts                    ← entry point
│   ├── config.ts                   ← env config loading
│   ├── constants.ts                ← app constants
│   ├── cli.ts                      ← CLI bootstrap
│   ├── app/
│   │   └── start-bot-app.ts        ← application bootstrap
│   ├── bot/
│   │   ├── index.ts                ← bot setup, middleware, command wiring
│   │   ├── commands/               ← 34 command handlers
│   │   │   └── definitions.ts      ← command registry (SINGLE SOURCE OF TRUTH)
│   │   ├── handlers/               ← prompt, question, permission, inline handlers
│   │   ├── middleware/             ← auth, interaction-guard, unknown-command
│   │   ├── streaming/              ← SSE response streamers
│   │   └── utils/                  ← chunking, formatting, keyboard helpers
│   ├── opencode/
│   │   ├── client.ts               ← SDK wrapper → localhost:4096
│   │   └── events.ts               ← SSE subscription
│   ├── session/                    ← session state + cache manager
│   ├── project/                    ← project selector
│   ├── settings/                   ← persistent settings (settings.json)
│   ├── summary/                    ← SSE event aggregation + formatting
│   ├── monitoring/                 ← system health + journal monitoring
│   ├── process/                    ← local OpenCode server control
│   ├── permission/                 ← permission request handling
│   ├── question/                   ← OpenCode Q&A handler
│   ├── keyboard/                   ← inline keyboard builders
│   ├── pinned/                     ← pinned status message manager
│   ├── model/                      ← model picker + capabilities
│   ├── agent/                      ← agent mode selector
│   ├── variant/                    ← variant selector
│   ├── interaction/                ← flow control (blocks concurrent interactions)
│   ├── rename/                     ← session rename flow
│   ├── safety/                     ← security sandboxing (bubblewrap)
│   ├── users/                       ← multi-user access control
│   ├── scheduled-task/            ← scheduled task creation/execution
│   ├── task-queue/                 ← BullMQ task queue
│   ├── queue/                      ← BullMQ worker setup
│   ├── stt/                        ← speech-to-text (Whisper)
│   ├── runtime/                    ← runtime mode detection
│   ├── i18n/                       ← 6 locales: en, de, es, fr, ru, zh
│   └── utils/                      ← logger, helpers
├── tests/                          ← Vitest tests (mirrors src/)
└── dist/                           ← compiled output
```

---

## Adding a New Command

1. **Create handler** in `src/bot/commands/<name>.ts`:
   ```typescript
   import { CommandContext, Context } from "grammy";
   export async function myCommand(ctx: CommandContext<Context>) {
       const arg = (ctx.match as string)?.trim();
       if (!arg) return ctx.reply("Usage: /mycommand <arg>");
       // ... logic ...
   }
   ```

2. **Register** in `src/bot/commands/definitions.ts`:
   ```typescript
   { command: "mycommand", descriptionKey: "cmd.description.mycommand" }
   ```

3. **Wire** in `src/bot/index.ts` (BEFORE any fallback text handler):
   ```typescript
   import { myCommand } from "./commands/mycommand.js";
   bot.command("mycommand", myCommand);
   ```

4. **Add i18n keys** in `src/i18n/en.ts` (and other locales)

5. **Add test** in `tests/bot/commands/<name>.test.ts`

6. **Verify:** `npm run build && npm run lint && npm test`

---

## OpenCode SDK Integration

```typescript
import { createOpencodeClient } from "@opencode-ai/sdk";

const client = createOpencodeClient({ baseUrl: "http://localhost:4096" });

// Health check
await client.global.health();

// Projects
await client.project.list();
await client.project.current();

// Sessions
await client.session.list();
await client.session.create({ body: { title: "My session" } });
await client.session.prompt({
  path: { id: "session-id" },
  body: { parts: [{ type: "text", text: "Implement feature X" }] },
});
await client.session.abort({ path: { id: "session-id" } });

// Shell execution
await client.session.shell({
  path: { id: "session-id" },
  body: { command: "ls -la" },
});

// SSE Events
const events = await client.event.subscribe();
for await (const event of events.stream) {
  // Handle: message_start, message_delta, message_end,
  //         tool_call_start, tool_call_end, thinking, etc.
}
```

Full SDK docs: https://opencode.ai/docs/sdk

---

## Running as systemd Services

**CRITICAL: systemd requires explicit PATH** — the service runs with a minimal PATH that doesn't include `/home/anini39/.opencode/bin` where `opencode` binary lives. Both services MUST have PATH environment variable.

### Service 1: /etc/systemd/system/opencode-serve.service

```ini
[Unit]
Description=OpenCode Server
After=network.target

[Service]
Type=simple
User=anini39
WorkingDirectory=/path/to/your/project
ExecStart=/usr/bin/env opencode serve --port 4096
Restart=on-failure
RestartSec=10
Environment="PATH=/usr/local/cuda/bin:/home/anini39/.config:/home/anini39/.bun/bin:/home/anini39/.local/bin:/home/anini39/.opencode/bin:/home/anini39/.kimi:/home/anini39/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:..."

[Install]
WantedBy=multi-user.target
```

### Service 2: /etc/systemd/system/opencode-telegram-bot.service

```ini
[Unit]
Description=OpenCode Telegram Bot
After=network.target opencode-serve.service

[Service]
Type=simple
User=anini39
WorkingDirectory=/media/ext4_storage/workspace/OpenCodeTelegramBot/opencode-telegram-bot
ExecStart=/usr/bin/node dist/index.js
Restart=always
RestartSec=5
Environment="PATH=/usr/local/cuda/bin:/home/anini39/.config:/home/anini39/.bun/bin:/home/anini39/.local/bin:/home/anini39/.opencode/bin:/home/anini39/.kimi:/home/anini39/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin:/home/anini39/.dotnet/tools:/home/anini39/tizen-studio/tools:/home/anini39/tizen-studio/tools/ide/bin"
EnvironmentFile=/media/ext4_storage/workspace/OpenCodeTelegramBot/opencode-telegram-bot/.env

[Install]
WantedBy=multi-user.target
```

### Enable both services

```bash
sudo systemctl daemon-reload
sudo systemctl enable opencode-serve
sudo systemctl start opencode-serve
sudo systemctl enable opencode-telegram-bot
sudo systemctl start opencode-telegram-bot
```

### View logs

```bash
journalctl -u opencode-serve -f             # live opencode server logs
journalctl -u opencode-telegram-bot -f      # live bot logs
```

---

## Key Features (Implemented)

- Remote coding via Telegram text/voice prompts
- Session management (create, switch, rename, abort)
- Project switching with directory cache
- Model switching (favorites + recent from OpenCode state)
- Agent modes (Plan / Build)
- Custom commands + built-ins (init, review)
- Interactive Q&A — inline buttons for permissions and questions
- Voice/audio transcription (Whisper-compatible: OpenAI, Groq, Together)
- File attachments — images, PDFs, text files
- Scheduled tasks with SQLite storage and BullMQ queue
- Response streaming (SSE → Telegram message updates with draft)
- Live pinned status (project, model, context usage, changed files)
- Context compaction from chat
- Input flow control (blocks concurrent interactions)
- System monitoring — disk, memory, load, CPU temp, SMART health
- Systemd journal monitoring with Telegram alerts
- OpenCode watchdog — auto-restart on crash
- Service message visibility controls (thinking/tool calls)
- i18n for 6 languages (en, de, es, fr, ru, zh)
- Multi-user access control (super users, simple users, restricted users)
- Inline mode for inline commands
- Proxy support (SOCKS5, HTTP/HTTPS)
- Busy-state commands: `/steer` and `/stop` work even during active tasks

---

## Constraints & Rules

1. **DO NOT break existing functionality** — all existing commands must continue working
2. **Use `.js` extensions** in all imports (ESM: `import { ... } from "./foo.js"`)
3. **Use `CommandContext<Context>`** type for command handlers
4. **Use `logger`** from `../../utils/logger.js` for logging — never `console.log`
5. **Register commands BEFORE** `bot.on("message:text", ...)` in `bot/index.ts`
6. **After all changes:** `npm run build && npm run lint` — must be clean
7. **`opencode serve` must be running** before starting the bot — always
8. **Never use nodemon** — breaks SSE streams mid-task
9. **Centralize command definitions** in `src/bot/commands/definitions.ts` only
10. **HTML escaping order:** `&` first, then `<`, then `>`
11. **PATH in systemd** — always include full PATH in service Environment variable

---

## Critical Gotchas

### Never Use nodemon
**nodemon breaks SSE streams mid-task.** Always use `npm start` or the systemd service.

### ESM Import Extensions
All local imports must use `.js` extensions (not `.ts`):
```typescript
// ✅ Correct
import { logger } from "../utils/logger.js";
// ❌ Wrong — will fail at runtime
import { logger } from "../utils/logger";
```

### Session State is In-Memory
Session state is in-memory per chat — **resets on bot restart**. If `/shell` returns "session not found", send any text prompt first to initialize a session, then use `/shell`.

### Telegram Rate Limits
- ~1 message per second per chat
- ~20 messages per minute in groups
- Use `SERVICE_MESSAGES_INTERVAL_SEC` (default: 5s) to batch thinking/tool messages

### Interaction Blocking
Only one interactive flow can be active at a time. If a user is in a menu/question/permission flow, unrelated text input is blocked.
**Exception:** `/steer`, `/stop`, `/abort`, `/status`, `/help` work even during active interactions.

### Systemd PATH Requirement
systemd services run with minimal PATH. You MUST include the full PATH in the service file:
```ini
Environment="PATH=/home/anini39/.opencode/bin:/home/anini39/.bun/bin:..."
```
Otherwise you'll get `ENOENT` errors when the bot tries to spawn `opencode`.

---

## Quality Gates

```bash
npm run build    # 0 errors expected
npm run lint     # 0 warnings expected
npm test         # all tests pass
npm run test:coverage  # with coverage report
```

---

## Open Tasks (from PRODUCT.md)

- [ ] Dynamic subagent activity display during task execution
- [ ] Git tree support
- [ ] Docker runtime support and deployment guide
- [ ] Create new OpenCode projects directly from Telegram
- [ ] Add project file browsing helpers (ls and open flows)
- [ ] Add a bot settings command with in-chat UI

## Remaining from Improvement Plan

- [ ] **Phase 3: Bubblewrap Sandboxing** — `src/safety/sandbox.ts` + `/analyze` command (NOT STARTED)
- [ ] **Phase 4: Progress Heartbeats** — periodic status updates for long-running shell commands (NOT STARTED)

---

## Environment Variables Reference

| Variable | Required | Default | Description |
|---|---|---|---|
| `TELEGRAM_BOT_TOKEN` | ✅ | — | Token from @BotFather |
| `TELEGRAM_ALLOWED_USER_ID` | ✅ | — | Your numeric Telegram ID |
| `OPENCODE_API_URL` | ✅ | `http://localhost:4096` | **Local server only** — NEVER a cloud URL |
| `OPENCODE_MODEL_PROVIDER` | ✅ | `opencode` | Model provider |
| `OPENCODE_MODEL_ID` | ✅ | `big-pickle` | Model ID |
| `OPENCODE_SERVER_USERNAME` | — | `opencode` | Basic auth username |
| `OPENCODE_SERVER_PASSWORD` | — | — | Optional: protect local server |
| `BOT_LOCALE` | — | `en` | UI language (en/de/es/fr/ru/zh) |
| `LOG_LEVEL` | — | `info` | debug / info / warn / error |
| `SERVICE_MESSAGES_INTERVAL_SEC` | — | `5` | Batch interval for thinking/tool messages |
| `RESPONSE_STREAMING` | — | `true` | Stream assistant responses |
| `MESSAGE_FORMAT_MODE` | — | `markdown` | markdown or raw |
| `HIDE_THINKING_MESSAGES` | — | `false` | Hide thinking indicators |
| `HIDE_TOOL_CALL_MESSAGES` | — | `false` | Hide tool call messages |
| `STT_API_URL` | — | — | Whisper-compatible STT endpoint |
| `STT_API_KEY` | — | — | STT API key |
| `TELEGRAM_PROXY_URL` | — | — | Proxy URL (socks5/http/https) |

---

## Troubleshooting

### Bot doesn't respond
- Verify `TELEGRAM_ALLOWED_USER_ID` matches your ID (check with @userinfobot)
- Confirm `npm run dev` is running with no errors
- Check: `journalctl -u opencode-telegram-bot -f`

### "OpenCode server is not available" / connection refused
- Confirm `opencode serve` is running: `curl http://localhost:4096/global/health`
- Check `OPENCODE_API_URL=http://localhost:4096` in `.env` — not a cloud URL
- If using systemd, verify `opencode-serve.service` is active

### TypeScript build errors
- Verify imports match exact file paths with `.js` extensions
- Run `npm run lint` for detailed errors

### `/shell` returns "session not found"
- Session state is **in-memory** — resets on bot restart
- Send any text prompt first to initialize session, then use `/shell`

### Bot stops responding after a while
- Use systemd with `Restart=always`
- Never use `nodemon` — it breaks SSE streams mid-task
- Prevent laptop suspend: `sudo systemctl mask sleep.target suspend.target`

### No models in /model menu
- Open OpenCode TUI: `opencode`
- Go to model selection, press **Ctrl+F** on any model to favorite it
- Favorites then appear in `/model` in Telegram

### "spawn opencode ENOENT" in systemd logs
- This means systemd PATH doesn't include `/home/anini39/.opencode/bin`
- Add full PATH to service Environment variable (see systemd section above)

---

## Further Reference

- OpenCode Server API docs: `http://localhost:4096/doc` (available once `opencode serve` is running)
- OpenCode SDK docs: https://opencode.ai/docs/sdk
- OpenCode Server docs: https://opencode.ai/docs/server
- grammY docs: https://grammy.dev/
- Project docs: `project.md`, `TLDR.md`, `SETUP_COMMANDS.md` in workspace root