---
name: mastra-ai
description: Mastra AI — TypeScript-native AI agent framework for production. Covers agents, memory, RAG, tools, workflows, and skill patterns. Use when building AI agents, implementing tool calling, or designing agent memory systems. Triggered when users mention Mastra AI, mastra-ai, building AI agents, agent memory, RAG pipelines, or tool calling patterns in TypeScript.
---

# Mastra AI

Mastra is a TypeScript-native AI agent framework designed for production deployments. It provides a comprehensive platform for building, deploying, and monitoring AI agents with built-in support for memory, RAG, tools, and complex workflows.

---

## Overview

Mastra is an open-source AI agent framework that emphasizes:
- **TypeScript-first** architecture with full type safety
- **Built-in memory** systems for persistent agent context
- **RAG (Retrieval-Augmented Generation)** pipeline support
- **Tool calling** with structured outputs
- **Workflow orchestration** for complex multi-step agents
- **Observability** with tracing and monitoring

---

## When to Activate

- Building AI agents in TypeScript with tool calling
- Implementing persistent memory for AI agents
- Creating RAG pipelines for knowledge retrieval
- Designing multi-step workflow agents
- Building production AI applications with monitoring
- Need agent skill/ability composition system
- Implementing agent-to-agent communication patterns

---

## Key Features & Patterns

### Agent Creation

```typescript
import { Mastra } from "@mastra/core";

const mastra = new Mastra({
  agents: {
    myAgent: {
      model: openaiModel("gpt-4o"),
      instructions: "You are a helpful assistant",
      tools: [weatherTool, searchTool],
    },
  },
});

const agent = mastra.getAgent("myAgent");
const response = await agent.stream("What is the weather in Tokyo?");
```

### Memory System

```typescript
import { AgentMemory } from "@mastra/core/memory";

const memory = new AgentMemory({
  storage: new PostgreSQLMemoryStorage(),
  options: {
    lastMessages: 10,
    semanticMemory: true,
    episodicMemory: true,
  },
});

await memory.add("user_preference", "User prefers detailed responses");
const context = await memory.retrieveRelevant("user preferences");
```

### RAG Pipeline

```typescript
import { createRagPipeline } from "@mastra/rag";

const ragPipeline = createRagPipeline({
  embedder: openaiEmbedder("text-embedding-3-small"),
  vectorStore: pgVectorStore,
  chunker: textChunker({ chunkSize: 512 }),
});

await ragPipeline.index("docs", documents);
const results = await ragPipeline.query("relevant information");
```

### Tools

```typescript
import { tool } from "@mastra/core";

const weatherTool = tool({
  name: "get_weather",
  description: "Get current weather for a location",
  schema: z.object({
    location: z.string().describe("City name"),
    unit: z.enum(["celsius", "fahrenheit"]).default("celsius"),
  }),
  execute: async ({ location, unit }) => {
    const weather = await fetchWeather(location, unit);
    return weather;
  },
});
```

### Workflows

```typescript
import { workflow } from "@mastra/core";

const researchWorkflow = workflow({
  name: "research-workflow",
  steps: [
    step1_search,
    step2_summarize,
    step3_format,
  ],
});

const result = await researchWorkflow.run({
  topic: "TypeScript AI frameworks",
});
```

---

## Integration Tips

### For Telegram Bot Projects

- Use Mastra agents as the AI backend instead of direct model calls
- Implement Mastra memory to maintain conversation context across Telegram sessions
- Create Mastra tools that wrap Telegram API calls for agent actions
- Use Mastra workflows to orchestrate complex bot command sequences
- Leverage Mastra's observability for monitoring agent performance

### TypeScript Best Practices

- Always use the schema validation for tool inputs
- Configure proper error handling in agent instructions
- Use streaming responses for better UX in Telegram
- Implement proper cleanup for memory resources

---

## Official Resources

- Website: https://mastra.ai/
- GitHub: mastra-ai/mastra
- Documentation: https://mastra.ai/docs
- Official Skills: mastra-ai/skills
