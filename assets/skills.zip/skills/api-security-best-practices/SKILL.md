---
name: api-security-best-practices
description: >
  API security best practices covering authentication, authorization, input validation, rate limiting, CORS,
  security headers, and vulnerability prevention. Includes guidance on preventing SQL injection, XSS, command
  injection, and CSRF attacks. Covers penetration testing workflows, security audit checklists, and OWASP
  Top 10 mitigation strategies for REST APIs.
---
