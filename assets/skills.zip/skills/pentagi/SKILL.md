---
name: pentagi
description: Fully autonomous AI agent system for complex penetration testing with 13 specialized agents, Docker sandbox isolation, and Neo4j knowledge graph. Use when running autonomous pentests, multi-phase attack chains, or need AI-driven vulnerability discovery.
---

# PentAGI - Autonomous AI Penetration Testing

## When to Use

- **Autonomous pentesting** - Let AI handle full penetration test
- **Multi-phase attacks** - Complex attack chains across recon → exploitation → post-ex
- **Knowledge graph tracking** - Visualize attack paths and findings
- **Docker sandbox** - Safe execution without polluting host system

## Features

- **13 specialized AI agents**: Researcher, Coder, Infrastructure, Exploiter, etc.
- **Neo4j knowledge graph**: Session memory and attack path visualization
- **20+ integrated security tools**: nmap, nuclei, sqlmap, ffuf, gobuster, etc.
- **Docker-based isolation**: No tools installed on host machine
- **Autonomous reasoning**: AI decides which tools to use based on findings

## Installation

```bash
# Quick start with Docker
curl -O https://raw.githubusercontent.com/vxcontrol/pentagi/master/docker-compose.yml
docker compose up -d

# Access UI
# Open http://localhost:8080
```

## Usage

### Web UI (Recommended)
- Navigate to `http://localhost:8080`
- Enter target URL or IP range
- Choose scan type: Quick, Standard, Deep
- Watch AI agents work in real-time

### CLI Mode
```bash
# Via Docker exec
docker exec -it pentagi-pentagi-1 pentagi --target 10.10.10.10 --scope internal
```

## Integration with Systemv2.5

| Systemv2.5 Category | PentAGI Capability |
|---------------------|-------------------|
| Bug Bounty Hunting | Autonomous scanning of targets |
| CVE Research | Automated CVE detection and exploitation |
| Network Scanning | Nmap integration for port discovery |
| Exploitation | SQLi, RCE, XSS automated exploitation |

## Supported Tools

| Category | Tools |
|----------|-------|
| Recon | nmap, subfinder, amass |
| Scanning | nuclei, nikto, ffuf |
| Exploitation | sqlmap, commix |
| Post-ex | responder, impacket |

## Notes

- Requires Docker and at least 4GB RAM
- All tools run in isolated containers
- Neo4j visualization requires additional setup
- Best for complex targets requiring multi-step attacks