---
name: bug-bounty-hunting
description: Complete bug bounty workflow — recon, vulnerability hunting, validation, and reporting. Use when hunting for bugs on HackerOne, Bugcrowd, or any security program.
---

# Bug Bounty Hunting Workflow

Full pipeline: Recon → Learn → Hunt → Validate → Report

## The Golden Rules

> **"Can an attacker do this RIGHT NOW against a real user who has taken NO unusual actions -- and does it cause real harm (stolen money, leaked PII, account takeover, code execution)?"**
>
> If answer is NO → **STOP. Do not write. Move on.**

### Kill Signals (Theoretical Bugs)
| Pattern | Why Kill |
|---------|----------|
| "Could theoretically allow..." | Not exploitable |
| "An attacker with X, Y, Z..." | Too many preconditions |
| "Wrong but no practical impact" | Harmless |
| "Could be used in a chain if..." | Build chain first |

## Critical Rules

1. **READ FULL SCOPE FIRST** — verify every asset before testing
2. **NO THEORETICAL BUGS** — prove it works or drop it
3. **KILL WEAK FINDINGS FAST** — 7-Question Gate BEFORE writing
4. **5-MINUTE RULE** — no progress after 5 min = move on
5. **IMPACT-FIRST** — "worst thing if auth broken?"
6. **CREDENTIAL LEAKS** — finding keys isn't enough, prove what they access

## Recon Workflow

```
1. Subdomain Enumeration: subfinder, amass, chaos
2. Live Hosts: httpx, naabu
3. URL Discovery: katana, gospider
4. Tech Fingerprinting: wappalyzer, whatweb
5. Nuclei Scan: nuclei -t cves, -t exposures
```

## Vulnerability Classes (20 Web2)

| Bug Class | Key Techniques |
|-----------|---------------|
| **IDOR** | Object-level, field-level, GraphQL node(), UUID enum |
| **XSS** | Reflected, stored, DOM, mXSS, CSP bypass |
| **SSRF** | Cloud metadata, DNS rebinding, IP bypasses |
| **SQLi** | Error-based, blind, ORM bypass, WAF bypass |
| **Auth Bypass** | Missing middleware, BFLA, client-side |
| **OAuth** | Missing PKCE, state bypass, redirect_uri |
| **Business Logic** | Workflow bypass, price manipulation |
| **Race Conditions** | TOCTOU, coupon reuse, double spend |
| **File Upload** | Extension bypass, MIME confusion, polyglots |
| **GraphQL** | Introspection, node() IDOR, batching bypass |
| **LLM/AI** | Prompt injection, chatbot IDOR, ASI01-ASI10 |
| **API Misconfig** | Mass assignment, JWT attacks, CORS |
| **ATO** | Password reset poisoning, token leaks |
| **SSTI** | Jinja2, Twig, ERB → RCE |
| **Subdomain Takeover** | GitHub Pages, S3, Heroku, Netlify |
| **Cloud** | S3 listing, EC2 metadata, K8s |
| **HTTP Smuggling** | CL.TE, TE.CL, H2.CL |
| **Cache Poisoning** | Unkeyed headers, parameter cloaking |
| **MFA Bypass** | No rate limit, OTP reuse, race |
| **SAML/SSO** | XSW, signature stripping, XXE |

## A→B Bug Chaining

| Bug A (Signal) | Hunt for Bug B | Escalate to C |
|---------------|-----------------|---------------|
| IDOR (read) | PUT/DELETE on same endpoint | Full data manipulation |
| SSRF (any) | Cloud metadata | IAM → RCE |
| XSS (stored) | HttpOnly check | Session hijack → ATO |
| Open redirect | OAuth redirect_uri | Auth code theft → ATO |
| S3 bucket listing | JS bundles grep | Secret → OAuth chain |

## Validation: 7-Question Gate

1. **Scope** — Is target in scope?
2. **Impact** — Real harm to real users?
3. **Exploitability** — Works right now?
4. **Uniqueness** — Not already reported?
5. **Payout** — Worth the time?
6. **Reproducibility** — Consistent?
7. **Evidence** — Can prove it?

## Report Structure

```
Title | CVSS Score | CWE/OWASP
## Reproduction Steps
## Impact
## Remediation
## PoC
```

## Tools

- `subfinder` — Subdomain enumeration
- `httpx` — Live host discovery
- `katana` — URL crawling
- `nuclei` — Vulnerability scanning
- `ffuf` — Fuzzing
- `sqlmap` — SQL injection