---
name: ai-reddit-lead-mining-machine
description: Scrape Reddit in real-time across any niche to detect buying intent posts, recommendation requests, product complaints, and "looking for" threads. Score each lead by purchase urgency, find contact info, generate platform-native outreach, and produce a niche authority video via InVideo AI. Powered by Apify + InVideo AI + Claude AI.
---

# AI Reddit Lead Mining Machine — Find Buyers Hiding in Subreddits & Close Them Today

---

**Category:** Social Selling / Lead Generation
**Powered by:** [Apify](https://www.apify.com) + [InVideo AI](https://invideo.sjv.io/TBB) + Claude AI

> Reddit has 50 million daily active users openly asking for product recommendations, complaining about competitors, and announcing they have budget to spend — right now. This skill scrapes every relevant subreddit in real-time, detects buying intent posts before anyone else responds, and generates the perfect platform-native reply that converts without sounding like an ad.

---

## Why This Is the Most Untapped Lead Source

Every lead gen skill targets LinkedIn, Google Maps, or cold email. **Nobody is mining Reddit.** That's the opportunity.

Reddit is the only platform where people openly say:
- *"I need a tool that does X — budget is $500/month, any recommendations?"*
- *"We just switched from [Competitor] and regret it — looking for alternatives"*
- *"Our company is evaluating CRMs — shortlist of 3, any thoughts?"*

**What gets automated:**
- 📡 Monitor **any subreddit** in real-time for buying intent signals
- 🔥 Detect **"looking for" posts**, recommendation requests, competitor complaints
- 🎯 Score each post by **purchase urgency** — how close is this person to buying?
- 👤 Find **commenter profiles** — Reddit history reveals industry, company, budget signals
- ✍️ Generate **platform-native replies** that help first, pitch second
- 📧 Find **contact details** for highest-intent posters via cross-platform search
- 🎬 Produce **niche authority video** via [InVideo AI](https://invideo.sjv.io/TBB) to pin to profile

---

## Tools Used

| Tool | Purpose |
|---|---|
| [Apify](https://www.apify.com) — Reddit Scraper | Real-time posts across target subreddits |
| [Apify](https://www.apify.com) — Reddit Comments Scraper | Full thread context |
| [Apify](https://www.apify.com) — Twitter/X Scraper | Cross-reference Reddit users on Twitter |
| [Apify](https://www.apify.com) — LinkedIn Profile Scraper | Find Reddit posters on LinkedIn |
| [Apify](https://www.apify.com) — Google Search Scraper | Find poster's company via username cross-reference |
| [InVideo AI](https://invideo.sjv.io/TBB) | Produce niche authority video |
| Claude AI | Intent scoring, reply generation, contact personalization |

---

## The Reddit Buying Intent Signal Library

```
SIGNAL TYPE 1 — Direct Recommendation Request (Highest Intent)
  Keywords: "looking for", "recommendations for", "best tool for",
            "anyone using", "what do you use for", "suggestions for"
  Example: "Looking for a project management tool for a 20-person remote team — budget $300/month"
  Intent score: 85–100
  Action: Reply immediately with value, DM with offer

SIGNAL TYPE 2 — Competitor Complaint (Very High Intent)
  Keywords: "leaving [competitor]", "cancelling [competitor]", "frustrated with",
            "switching from", "alternatives to [competitor]"
  Example: "Cancelling our Salesforce subscription — too expensive, too complex. What are people using instead?"
  Intent score: 80–95
  Action: Reply with your alternative, position as the obvious next step

SIGNAL TYPE 3 — Problem Statement (High Intent)
  Keywords: "we're struggling with", "our team can't", "biggest challenge is",
            "anyone else dealing with", "how do you handle"
  Intent score: 65–80
  Action: Reply with insight first, soft mention of solution

SIGNAL TYPE 4 — Evaluation Post (High Intent)
  Keywords: "shortlisting", "evaluating", "comparing X vs Y", "which is better",
            "we're deciding between"
  Intent score: 70–85
  Action: Reply with unbiased comparison that subtly positions your product

SIGNAL TYPE 5 — Budget Signal (Medium-High Intent)
  Keywords: "budget approved", "we have $X to spend", "looking to invest in"
  Intent score: 75–90
  Action: Reply with ROI framing, budget-appropriate positioning
```

---

## Full Workflow

```
INPUT: Your product + problem it solves + target subreddits
        ↓
STEP 1 — Real-Time Subreddit Monitoring
  └─ Scan target subreddits every hour for new posts
  └─ Filter: posted in last 24h + minimum engagement threshold
        ↓
STEP 2 — Intent Classification
  └─ Classify each post by signal type (1–5)
  └─ Extract key buying signals from post text
  └─ Read top comments — has anyone already answered well?
        ↓
STEP 3 — Poster Intelligence
  └─ Reddit post history: what industry are they in?
  └─ Account age + karma: legitimate user or throwaway?
  └─ Cross-platform: same username on LinkedIn or Twitter?
        ↓
STEP 4 — Intent Scoring (0–100)
  └─ Signal type strength (35%)
  └─ Post recency (25%): older = colder
  └─ Engagement level (20%): upvotes + comments
  └─ Poster profile quality (20%): established account = real buyer
        ↓
STEP 5 — Reply Strategy Selection
  └─ Score 80+: Reply + DM + find LinkedIn for direct outreach
  └─ Score 60–79: Reply with value, soft mention of solution
  └─ Score 40–59: Reply with pure value, no mention of product
  └─ Score below 40: Monitor only
        ↓
STEP 6 — Claude AI Writes Platform-Native Reply
  └─ Reads like a helpful community member, not an ad
  └─ Leads with genuine value or experience
  └─ Mentions product naturally if high intent
  └─ Ends with DM invite for personalized help
        ↓
STEP 7 — Direct Outreach for Top Leads
  └─ Find contact via cross-platform search
  └─ LinkedIn DM references their Reddit post specifically
  └─ Email if found — subject references their exact problem
        ↓
STEP 8 — InVideo AI Produces Authority Video
  └─ 60-second "here's how to solve [niche problem]" video
  └─ Pin to Reddit profile — establishes credibility before reply
        ↓
OUTPUT: Ranked buying intent posts + replies + contact details + authority video
```

---

## Inputs

```json
{
  "your_product": {
    "name": "Your Product Name",
    "solves": "The problem it solves",
    "key_result": "Average customer result",
    "differentiator": "What makes it different from competitors",
    "competitor_alternatives": ["HubSpot", "Salesforce", "Pipedrive"]
  },
  "monitoring": {
    "primary_subreddits": ["r/sales", "r/smallbusiness", "r/startups", "r/saas"],
    "secondary_subreddits": ["r/marketing", "r/agency", "r/freelance"],
    "intent_keywords": ["looking for CRM", "leaving Salesforce", "best tool for"],
    "lookback_hours": 24,
    "min_intent_score": 60
  },
  "output": {
    "max_leads": 20,
    "find_contact_for_score_above": 75,
    "reply_for_score_above": 60
  },
  "production": {
    "invideo_api_key": "YOUR_INVIDEO_API_KEY",
    "video_topic": "Topic for niche authority video"
  },
  "apify_token": "YOUR_APIFY_TOKEN"
}
```

---

## Reddit Reply Rules — Non-Negotiable

- Never sound like an ad
- Personal experience beats product features every time
- Ask a clarifying question = 3x more replies
- "Happy to DM" converts better than direct pitch
- **Maximum 200 words** per reply
- **Reply within 1 hour** — Reddit feeds move fast, first helpful reply wins
- **Never mention your product in first reply on score below 80** — value first, product second
- **Pin your authority video to your Reddit profile** — credibility before the conversation starts

---

## Cost Estimate

| Run | Apify Cost | InVideo Cost | Total |
|---|---|---|---|
| Daily scan (20 leads) | ~$0.40 | ~$3 | ~$3.40 |
| Weekly (5 days) | ~$2 | ~$3 | ~$5 |
| Monthly automation | ~$8 | ~$12 | ~$20/month |

---

## Setup in 3 Steps

**Step 1 — Get your [Apify](https://www.apify.com) API Token**
Settings → Integrations → API Token

**Step 2 — Get your [InVideo AI](https://invideo.sjv.io/TBB) account**
Settings → API → Copy your key

**Step 3 — Set your subreddits + keywords & run daily**
Product + intent keywords + subreddits. Fresh buying signals every morning.
