---
name: api-security-testing
description: GraphQL, REST API, WebSocket, and Web LLM security testing. Use when testing API endpoints, GraphQL resolvers, or WebSocket connections.
---

# API Security Testing

Test APIs for vulnerabilities including GraphQL, REST, WebSocket, and Web LLM attacks.

## When to Use

- Testing REST API endpoints
- GraphQL security assessment
- WebSocket vulnerability testing
- API authentication/authorization
- Testing Web LLM integrations

## GraphQL Attacks

### Introspection
```graphql
query { __schema { types { name fields { name } } } }
```

### IDOR via node()
```graphql
query { node(id: "user123") { ...UserFragment } }
```

### Batching Attack
```graphql
[
  { query: "mutation { login(u:\"admin\",p:\"wrong\") {...}" },
  { query: "mutation { login(u:\"admin\",p:\"wrong2\") {...}" }
]
```

### Mutation Auth Bypass
- Check if mutations require auth
- Test field-level authorization
- Nested mutations

## REST API Testing

| Issue | Test |
|-------|------|
| **IDOR/BOLA** | Change resource IDs |
| **Mass Assignment** | Add unexpected fields |
| **Parameter Pollution** | Duplicate params |
| **Method Tampering** | CHANGE to GET/DELETE |
| **Versioning** | Test /v1/, /v2/ endpoints |

## WebSocket Testing

- Cross-origin hijacking
- Message injection
- Protocol downgrade
- Auth token in URL

## Workflow

1. Map all API endpoints
2. Test authentication bypass
3. Check for IDOR/BOLA
4. Probe GraphQL for introspection
5. Test rate limiting
6. Check for information disclosure

## Tools

- `inql` — GraphQL inspector
- `graphqurl` — GraphQL client
- `wsdump` — WebSocket testing
- `ffuf` — API fuzzing