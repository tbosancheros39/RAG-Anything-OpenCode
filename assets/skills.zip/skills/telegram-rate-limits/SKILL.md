---
name: telegram-rate-limits
description: Telegram Bot API rate limit handling for TypeScript. Covers per-group limits (~1 msg/sec, ~20 msg/min), universal rate limits, message batching strategies, flood wait handling, and concurrent update processing. Use when building high-volume bots or group bots.
Reference: Telegram Bot API docs — "Frequently asked questions" — spam prevention rules
---

# Telegram Rate Limit Handling

## Overview

Telegram enforces rate limits to prevent spam. Understanding these limits is critical for building bots that work reliably in groups and high-volume scenarios. Limits apply per-chat, per-bot, and globally.

## When to Activate

- Building bots that post frequently in groups
- Implementing auto-reply or notification bots
- Handling flood wait errors (`RetryAfter`)
- Optimizing message batching strategies
- Designing high-volume broadcast systems
- Building inline query handlers
- Working with multiple bots

## Rate Limit Rules

### Telegram's Spam Prevention Limits

| Context | Limit | Description |
|---------|-------|-------------|
| Group messages | ~1 msg/sec | Per-chat sending rate |
| Group messages | ~20 msg/min | Per-chat per-minute limit |
| Direct messages | ~30 msg/sec | Per-bot global DM limit |
| Inline queries | 60/min | Per-user inline query rate |
| Callback answers | 100/sec | Per-bot callback response rate |
| Message edits | Unlimited | No explicit limit |

### Flood Wait Error Handling

```typescript
import { Bot, Context, Api } from "grammy";

class FloodWaitHandler {
    private pendingQueue: Array<() => Promise<void>> = [];
    private isProcessing = false;
    private baseDelay = 1000;

    constructor(private api: Api, private maxRetries = 5) {}

    async sendWithRetry(
        chatId: number | string,
        text: string,
        options?: Record<string, unknown>
    ): Promise<void> {
        try {
            await this.api.sendMessage(chatId, text, options);
        } catch (error: unknown) {
            if (this.isFloodWaitError(error)) {
                const retryAfter = (error as { parameters?: { retry_after?: number } }).parameters?.retry_after || 60;
                console.log(`Flood wait: sleeping for ${retryAfter}s`);
                await this.sleep(retryAfter * 1000);
                return this.sendWithRetry(chatId, text, options);
            }
            throw error;
        }
    }

    private isFloodWaitError(error: unknown): boolean {
        return (
            error instanceof Error &&
            error.message.includes("Too Many Requests") &&
            (error as { parameters?: { retry_after?: number } }).parameters?.retry_after !== undefined
        );
    }

    private sleep(ms: number): Promise<void> {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }
}

const bot = new Bot(process.env.TELEGRAM_BOT_TOKEN!);
const floodHandler = new FloodWaitHandler(bot.api);
```

### Message Batching Queue

```typescript
interface QueuedMessage {
    chatId: number;
    text: string;
    options?: Record<string, unknown>;
    priority: number;
    timestamp: number;
}

class MessageQueue {
    private queue: QueuedMessage[] = [];
    private processing = false;
    private minInterval = 1000; // 1 message per second for groups

    async add(message: QueuedMessage): Promise<void> {
        this.queue.push(message);
        this.queue.sort((a, b) => a.priority - b.priority || a.timestamp - b.timestamp);

        if (!this.processing) {
            this.process();
        }
    }

    private async process(): Promise<void> {
        if (this.queue.length === 0) {
            this.processing = false;
            return;
        }

        this.processing = true;
        const message = this.queue.shift()!;

        try {
            await bot.api.sendMessage(message.chatId, message.text, message.options);
            await this.sleep(this.minInterval);
        } catch (error) {
            if (this.isFloodWaitError(error)) {
                // Re-queue with delay
                const retryAfter = this.getRetryAfter(error);
                console.log(`Flood wait, requeuing after ${retryAfter}s`);
                this.queue.unshift(message);
                await this.sleep((retryAfter + 5) * 1000);
            }
        }

        this.process();
    }

    private sleep(ms: number): Promise<void> {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }

    private isFloodWaitError(error: unknown): boolean {
        return (
            error instanceof Error &&
            error.message.includes("Too Many Requests")
        );
    }

    private getRetryAfter(error: unknown): number {
        // Extract retry_after from error
        return 5; // Default fallback
    }
}

const messageQueue = new MessageQueue();

// Usage in command handler
bot.command("broadcast", async (ctx) => {
    const text = ctx.match;

    await ctx.reply("Starting broadcast...");

    const chats = await db.getAllChats();

    for (const chat of chats) {
        await messageQueue.add({
            chatId: chat.id,
            text: `📢 ${text}`,
            priority: chat.isPremium ? 1 : 2,
            timestamp: Date.now(),
        });
    }

    await ctx.reply(`Queued broadcast for ${chats.length} chats`);
});
```

### Group Bot Rate Limiter

```typescript
interface GroupRateLimit {
    chatId: number;
    lastMessageTime: number;
    messageCount: number;
    windowStart: number;
}

class GroupRateLimiter {
    private limits = new Map<number, GroupRateLimit>();
    private windowMs = 60000; // 1 minute window
    private maxPerWindow = 20;

    canSend(chatId: number): boolean {
        const limit = this.limits.get(chatId);
        const now = Date.now();

        if (!limit || now - limit.windowStart > this.windowMs) {
            return true;
        }

        return limit.messageCount < this.maxPerWindow;
    }

    recordSend(chatId: number): void {
        const now = Date.now();
        let limit = this.limits.get(chatId);

        if (!limit || now - limit.windowStart > this.windowMs) {
            limit = { chatId, lastMessageTime: now, messageCount: 0, windowStart: now };
            this.limits.set(chatId, limit);
        }

        limit.messageCount++;
        limit.lastMessageTime = now;
    }

    getRetryAfter(chatId: number): number {
        const limit = this.limits.get(chatId);
        if (!limit) return 0;

        const elapsed = Date.now() - limit.windowStart;
        return Math.max(0, (this.windowMs - elapsed) / 1000);
    }

    cleanup(): void {
        const now = Date.now();
        for (const [chatId, limit] of this.limits) {
            if (now - limit.windowStart > this.windowMs * 2) {
                this.limits.delete(chatId);
            }
        }
    }
}

const groupLimiter = new GroupRateLimiter();

// Cleanup every 5 minutes
setInterval(() => groupLimiter.cleanup(), 5 * 60 * 1000);

bot.on("message", async (ctx) => {
    const chatId = ctx.chat.id;

    if (ctx.chat.type !== "private") {
        if (!groupLimiter.canSend(chatId)) {
            const retryAfter = groupLimiter.getRetryAfter(chatId);
            console.log(`Group ${chatId} rate limited, retry in ${retryAfter}s`);
            // Don't reply — just silently skip
            return;
        }
        groupLimiter.recordSend(chatId);
    }
});
```

### Concurrent Update Processing

```typescript
import { Bot, Context } from "grammy";
import P from "p-series";

const bot = new Bot(process.env.TELEGRAM_BOT_TOKEN!);

// Sequential processing for group commands
bot.chatType(["group", "supergroup"]).command("stats", async (ctx) => {
    const chatId = ctx.chat.id;

    // Only process one stats command at a time per group
    const lockKey = `stats:${chatId}`;

    if (activeLocks.has(lockKey)) {
        await ctx.reply("⏳ Stats command already running. Please wait.");
        return;
    }

    activeLocks.add(lockKey);

    try {
        await ctx.reply("📊 Gathering stats...");

        // Run stats collection (which may be slow)
        const stats = await collectChatStats(chatId);

        await ctx.reply(stats);
    } finally {
        activeLocks.delete(lockKey);
    }
});

const activeLocks = new Set<string>();

async function collectChatStats(chatId: number): Promise<string> {
    // Simulate slow operation
    await new Promise((resolve) => setTimeout(resolve, 2000));
    return `Stats for chat ${chatId}: 1000 messages today`;
}

// Parallel processing with concurrency limit
class ConcurrencyLimiter {
    private running = 0;
    private queue: Array<() => Promise<void>> = [];

    constructor(private maxConcurrent: number) {}

    async run<T>(fn: () => Promise<T>): Promise<T> {
        return new Promise((resolve, reject) => {
            this.queue.push(async () => {
                try {
                    const result = await fn();
                    resolve(result);
                } catch (error) {
                    reject(error);
                }
            });
            this.process();
        });
    }

    private async process(): Promise<void> {
        while (this.running < this.maxConcurrent && this.queue.length > 0) {
            const fn = this.queue.shift()!;
            this.running++;
            fn().finally(() => {
                this.running--;
                this.process();
            });
        }
    }
}
```

## Common Pitfalls

1. **Per-chat vs global limits** — Telegram limits are per-chat (group) AND per-bot globally. A burst in one group can affect DM performance.

2. **Reply rate vs send rate** — If your bot only replies to messages (not initiating), you're less likely to hit limits. Bots that proactively send messages hit limits faster.

3. **Inline query limits** — Users can make 60 inline queries per minute. Your bot receives ALL queries to it, regardless of user count.

4. **Flood wait is per-chat** — `RetryAfter` applies to the specific chat that triggered it. Your bot can still send to other chats.

5. **No batching API** — Telegram has no native message batching. You must implement your own queue with rate limit awareness.

## Reference

- [Telegram Bot API - Rate Limits](https://core.telegram.org/bots/faq#are-there-limits-for-bots)
- [Telegram Bot API - FAQ](https://core.telegram.org/bots/faq)
- [Flood Wait Handling](https://core.telegram.org/bots/faq#my-bot-is-hitting-rate-limits)
- [gramMY Rate Limiter Middleware](https://grammy.dev/plugins/rate-limiter)
