---
name: bot-evasion-stealth
description: Implement advanced browser fingerprint spoofing to evade bot detection including Canvas, WebGL, AudioContext fingerprinting, and CDP Runtime.Enable detection bypass.
origin: AntiGravity Offense Team
---

# Bot Evasion - Stealth Implementation

Implement advanced fingerprint spoofing techniques to bypass 2026 bot detection methods including Canvas, WebGL, AudioContext fingerprinting, and CDP Runtime.Enable detection.

## When to Activate

- Implementing Canvas 2D fingerprint spoofing
- Adding WebGL vendor/renderer spoofing
- Bypassing CDP Runtime.Enable detection
- Creating AudioContext fingerprint consistency
- Integrating advanced stealth patches into the Evasion project
- Testing against fingerprinting sites (browserleaks.com, fingerprintjs.com)

## Critical: CDP Runtime.Enable Detection

**THIS IS THE #1 DETECTION METHOD IN 2026**

Detection sites check if `Runtime.Enable` CDP command was sent. If detected = instant bot flag.

### The Problem
```javascript
// BAD: rebrowser-puppeteer-core with default mode sends Runtime.Enable
// Detection code:
const isBot = navigator.webdriver === true || // Old check
              !!window.chrome?.runtime?.OnInstalledReason || // CDP leak
              document.$cdc_asdjflasutopfhvcZLmcfl_; // ChromeDriver property
```

### The Solution: alwaysIsolated Mode

**Step 1: Update .env file**
```bash
# /media/ext4_storage/workspace/AntiGravity/Evasion/.env

# CRITICAL: Source URL for rebrowser patches
REBROWSER_PATCHES_SOURCE_URL=https://raw.githubusercontent.com/rebrowser/rebrowser-patches/main/patches/puppeteer-core/21.0.0/index.js

# CRITICAL: Must use 'alwaysIsolated' to prevent Runtime.Enable detection
# Options: 'alwaysIsolated' (safe) or 'neverIsolated' (unsafe, for debugging)
REBROWSER_PATCHES_UTILITY_WORLD_NAME=alwaysIsolated

# Your other env vars...
PROXY_HOST=your-proxy-host
PROXY_PORT=8080
CAPTCHA_API_KEY=your-key
```

**Step 2: Verify Isolation Mode in engine/browser.js**
```javascript
// /media/ext4_storage/workspace/AntiGravity/Evasion/engine/browser.js

const puppeteer = require('rebrowsers-puppeteer-core');

class StealthBrowser {
  async launch() {
    this.browser = await puppeteer.launch({
      headless: 'new',
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--disable-gpu',
        // Additional stealth args
        '--disable-blink-features=AutomationControlled',
        '--disable-features=IsolateOrigins,site-per-process',
      ],
    });
    
    // Verify isolation mode is active
    const envMode = process.env.REBROWSER_PATCHES_UTILITY_WORLD_NAME;
    if (envMode !== 'alwaysIsolated') {
      console.warn('⚠️  WARNING: Not in alwaysIsolated mode - bot detection likely!');
    }
  }
}
```

**Step 3: Test CDP Detection**
```bash
# Run this test to verify CDP isolation
node -e "
const puppeteer = require('rebrowsers-puppeteer-core');
(async () => {
  const browser = await puppeteer.launch({ headless: 'new' });
  const page = await browser.newPage();
  await page.goto('https://bot-detector.rebrowser.net/');
  await page.waitForTimeout(5000);
  
  // Check detection result
  const result = await page.evaluate(() => {
    return document.body.innerText.includes('Automation') ? 'DETECTED' : 'CLEAN';
  });
  
  console.log('CDP Detection Result:', result);
  await browser.close();
})();
"
```

**Expected Result:** "CLEAN" (if alwaysIsolated mode is working)

## Canvas Fingerprint Spoofing

### Implementation: tools/stealth/canvas-spoof.js

```javascript
// /media/ext4_storage/workspace/AntiGravity/Evasion/tools/stealth/canvas-spoof.js

/**
 * Canvas Fingerprint Spoofing Module
 * Intercepts Canvas 2D API calls and injects noise to make fingerprint unique but consistent per profile
 */

class CanvasSpoof {
  constructor(profile) {
    this.profile = profile;
    this.noiseSeed = this.generateNoiseSeed();
  }

  /**
   * Generate consistent noise seed from profile
   */
  generateNoiseSeed() {
    // Use profile ID + browser version to create consistent noise
    const seedStr = `${this.profile.id}-${this.profile.browser.version}`;
    let hash = 0;
    for (let i = 0; i < seedStr.length; i++) {
      const char = seedStr.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash);
  }

  /**
   * Apply spoofing to page via CDP
   */
  async apply(page) {
    await page.evaluateOnNewDocument((seed) => {
      // Store original methods
      const originalGetImageData = CanvasRenderingContext2D.prototype.getImageData;
      const originalToDataURL = HTMLCanvasElement.prototype.toDataURL;
      const originalToBlob = HTMLCanvasElement.prototype.toBlob;

      // Pseudo-random number generator with seed
      function seededRandom(seed) {
        let s = seed;
        return function() {
          s = Math.sin(s) * 10000;
          return s - Math.floor(s);
        };
      }

      const rng = seededRandom(seed);

      // Spoof getImageData
      CanvasRenderingContext2D.prototype.getImageData = function(x, y, w, h) {
        const imageData = originalGetImageData.call(this, x, y, w, h);
        
        // Add imperceptible noise to alpha channel
        for (let i = 3; i < imageData.data.length; i += 4) {
          if (imageData.data[i] > 0 && imageData.data[i] < 255) {
            // Add/subtract 1-2 to alpha for sites that check exact pixel values
            const noise = Math.floor(rng() * 3) - 1; // -1, 0, or 1
            imageData.data[i] = Math.max(0, Math.min(255, imageData.data[i] + noise));
          }
        }
        
        return imageData;
      };

      // Spoof toDataURL and toBlob
      HTMLCanvasElement.prototype.toDataURL = function(type, quality) {
        // Force a draw operation to apply noise
        const ctx = this.getContext('2d');
        if (ctx) {
          ctx.fillStyle = ctx.fillStyle; // Trigger internal state
        }
        return originalToDataURL.call(this, type, quality);
      };

      HTMLCanvasElement.prototype.toBlob = function(callback, type, quality) {
        return originalToBlob.call(this, callback, type, quality);
      };

      // Override canvas fingerprinting detection
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      // Pre-warm canvas to establish consistent baseline
      canvas.width = 200;
      canvas.height = 200;
      ctx.fillStyle = '#f0f0f0';
      ctx.fillRect(0, 0, 200, 200);
      ctx.fillStyle = '#ff0000';
      ctx.fillText('warming', 50, 100);
      
    }, this.noiseSeed);
  }

  /**
   * Verify Canvas spoofing is working
   */
  async verify(page) {
    const fingerprint = await page.evaluate(() => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = 200;
      canvas.height = 200;
      
      // Draw standard fingerprinting pattern
      ctx.fillStyle = '#f0f0f0';
      ctx.fillRect(0, 0, 200, 200);
      ctx.fillStyle = '#ff0000';
      ctx.fillText('test', 50, 100);
      
      // Get fingerprint hash
      const data = ctx.getImageData(0, 0, 200, 200).data;
      let hash = 0;
      for (let i = 0; i < data.length; i++) {
        hash = ((hash << 5) - hash) + data[i];
        hash = hash & hash;
      }
      return hash;
    });
    
    return fingerprint;
  }
}

module.exports = CanvasSpoof;
```

### Integration into tools/stealth/index.js

```javascript
// Add to /media/ext4_storage/workspace/AntiGravity/Evasion/tools/stealth/index.js

const CanvasSpoof = require('./canvas-spoof');

class StealthTools {
  constructor(config) {
    this.canvasSpoof = new CanvasSpoof(config.profile);
  }

  async applyAll(page) {
    // Apply Canvas spoofing
    await this.canvasSpoof.apply(page);
    
    // Apply other stealth measures...
    await this.applyUserAgentSpoof(page);
    await this.applyWebGLSpoof(page);
    await this.applyAudioSpoof(page);
  }
}
```

## WebGL Fingerprint Spoofing

### Implementation: tools/stealth/webgl-spoof.js

```javascript
// /media/ext4_storage/workspace/AntiGravity/Evasion/tools/stealth/webgl-spoof.js

/**
 * WebGL Fingerprint Spoofing Module
 * Spoofs WebGL vendor/renderer to match Canvas capabilities
 */

class WebGLSpoof {
  constructor(profile) {
    this.profile = profile;
    this.vendor = profile.webgl?.vendor || 'Intel Inc.';
    this.renderer = profile.webgl?.renderer || 'Intel Iris OpenGL Engine';
    this.unmaskedVendor = profile.webgl?.unmaskedVendor || 'Intel Inc.';
    this.unmaskedRenderer = profile.webgl?.unmaskedRenderer || 'Intel Iris Xe Graphics';
  }

  /**
   * Get WebGL parameters that identify GPU
   */
  getWebGLParams() {
    return {
      vendor: this.vendor,
      renderer: this.renderer,
      unmaskedVendor: this.unmaskedVendor,
      unmaskedRenderer: this.unmaskedRenderer,
      // Common params that fingerprinting libraries check
      shadingLanguageVersion: 'WebGL GLSL ES 3.00 (OpenGL ES GLSL ES 3.0 Chromium)',
      version: 'WebGL 2.0 (OpenGL ES 3.0 Chromium)',
    };
  }

  /**
   * Apply spoofing to page via CDP
   */
  async apply(page) {
    const params = this.getWebGLParams();
    
    await page.evaluateOnNewDocument((spoofParams) => {
      // Store original getParameter
      const originalGetParameter = WebGLRenderingContext.prototype.getParameter;
      const originalGetParameter2 = WebGL2RenderingContext?.prototype.getParameter;

      // Parameter constants
      const VENDOR = 0x1F00;
      const RENDERER = 0x1F01;
      const UNMASKED_VENDOR_WEBGL = 0x9245;
      const UNMASKED_RENDERER_WEBGL = 0x9246;
      const SHADING_LANGUAGE_VERSION = 0x8B8C;
      const VERSION = 0x1F02;

      function spoofedGetParameter(pname) {
        switch (pname) {
          case VENDOR:
            return spoofParams.vendor;
          case RENDERER:
            return spoofParams.renderer;
          case UNMASKED_VENDOR_WEBGL:
            return spoofParams.unmaskedVendor;
          case UNMASKED_RENDERER_WEBGL:
            return spoofParams.unmaskedRenderer;
          case SHADING_LANGUAGE_VERSION:
            return spoofParams.shadingLanguageVersion;
          case VERSION:
            return spoofParams.version;
          default:
            return originalGetParameter.call(this, pname);
        }
      }

      // Override WebGL1
      WebGLRenderingContext.prototype.getParameter = spoofedGetParameter;

      // Override WebGL2 if available
      if (WebGL2RenderingContext) {
        WebGL2RenderingContext.prototype.getParameter = spoofedGetParameter;
      }

      // Also spoof getShaderPrecisionFormat for advanced detection
      const originalGetShaderPrecisionFormat = WebGLRenderingContext.prototype.getShaderPrecisionFormat;
      WebGLRenderingContext.prototype.getShaderPrecisionFormat = function(shaderType, precisionType) {
        const result = originalGetShaderPrecisionFormat.call(this, shaderType, precisionType);
        // Some sites check precision values - ensure they match Intel profile
        if (result) {
          result.precision = Math.min(result.precision, 23); // Cap at typical Intel precision
        }
        return result;
      };

    }, params);
  }

  /**
   * Verify WebGL spoofing is working
   */
  async verify(page) {
    const report = await page.evaluate(() => {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      
      if (!gl) return { error: 'WebGL not supported' };
      
      return {
        vendor: gl.getParameter(0x1F00),
        renderer: gl.getParameter(0x1F01),
        unmaskedVendor: gl.getParameter(0x9245),
        unmaskedRenderer: gl.getParameter(0x9246),
        shadingLanguageVersion: gl.getParameter(0x8B8C),
        version: gl.getParameter(0x1F02),
      };
    });
    
    return report;
  }
}

module.exports = WebGLSpoof;
```

## AudioContext Fingerprint Spoofing

### Implementation: tools/stealth/audio-spoof.js

```javascript
// /media/ext4_storage/workspace/AntiGravity/Evasion/tools/stealth/audio-spoof.js

/**
 * AudioContext Fingerprint Spoofing Module
 * Ensures AudioContext fingerprint consistency with other spoofed values
 */

class AudioSpoof {
  constructor(profile) {
    this.profile = profile;
    // Use same seed as Canvas for consistency
    this.seed = this.generateSeed();
  }

  generateSeed() {
    const seedStr = `${this.profile.id}-audio`;
    let hash = 0;
    for (let i = 0; i < seedStr.length; i++) {
      const char = seedStr.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash);
  }

  async apply(page) {
    await page.evaluateOnNewDocument((seed) => {
      // Store original methods
      const originalCreateOscillator = AudioContext.prototype.createOscillator;
      const originalCreateDynamicsCompressor = AudioContext.prototype.createDynamicsCompressor;
      const originalCreateAnalyser = AudioContext.prototype.createAnalyser;

      // Seeded random for consistent "noise"
      function seededRandom(s) {
        let x = s;
        return function() {
          x = Math.sin(x) * 10000;
          return x - Math.floor(x);
        };
      }

      const rng = seededRandom(seed);

      // Spoof createDynamicsCompressor (commonly used for fingerprinting)
      AudioContext.prototype.createDynamicsCompressor = function() {
        const compressor = originalCreateDynamicsCompressor.call(this);
        
        // Override threshold getter to add consistent variation
        const originalThreshold = Object.getOwnPropertyDescriptor(
          Object.getPrototypeOf(compressor), 'threshold'
        );
        
        Object.defineProperty(compressor, 'threshold', {
          get: function() {
            const value = originalThreshold.get.call(this);
            // Add imperceptible variation (-0.001 to +0.001 dB)
            return value + (rng() * 0.002 - 0.001);
          },
          configurable: true
        });

        return compressor;
      };

      // Spoof AnalyserNode for frequency data consistency
      AudioContext.prototype.createAnalyser = function() {
        const analyser = originalCreateAnalyser.call(this);
        
        // Ensure fftSize is consistent
        analyser.fftSize = 2048;
        analyser.smoothingTimeConstant = 0.8;
        
        return analyser;
      };

      // Spoof sampleRate to match common values
      const originalSampleRate = Object.getOwnPropertyDescriptor(
        AudioContext.prototype, 'sampleRate'
      );
      
      Object.defineProperty(AudioContext.prototype, 'sampleRate', {
        get: function() {
          // Return standard sample rate instead of actual
          return 48000;
        },
        configurable: true
      });

      // Spoof baseLatency
      Object.defineProperty(AudioContext.prototype, 'baseLatency', {
        get: function() {
          return 0.005; // Standard value
        },
        configurable: true
      });

      // Spoof outputLatency  
      Object.defineProperty(AudioContext.prototype, 'outputLatency', {
        get: function() {
          return 0.01; // Standard value
        },
        configurable: true
      });

    }, this.seed);
  }

  /**
   * Verify Audio spoofing is working
   */
  async verify(page) {
    const result = await page.evaluate(async () => {
      try {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        
        // Create oscillator and compressor (common fingerprinting pattern)
        const oscillator = audioContext.createOscillator();
        const compressor = audioContext.createDynamicsCompressor();
        const analyser = audioContext.createAnalyser();
        
        oscillator.connect(compressor);
        compressor.connect(analyser);
        
        // Get compressor threshold
        const threshold = compressor.threshold.value;
        
        // Get frequency data
        const dataArray = new Uint8Array(analyser.frequencyBinCount);
        analyser.getByteFrequencyData(dataArray);
        
        return {
          sampleRate: audioContext.sampleRate,
          baseLatency: audioContext.baseLatency,
          outputLatency: audioContext.outputLatency,
          compressorThreshold: threshold,
          fftSize: analyser.fftSize,
          fingerprint: dataArray.slice(0, 10).join(',') // First 10 values
        };
      } catch (e) {
        return { error: e.message };
      }
    });
    
    return result;
  }
}

module.exports = AudioSpoof;
```

## Integration Checklist

### Phase 1: CDP Detection Fix (CRITICAL - Do First)
- [ ] Add `REBROWSER_PATCHES_SOURCE_URL` to .env
- [ ] Add `REBROWSER_PATCHES_UTILITY_WORLD_NAME=alwaysIsolated` to .env
- [ ] Verify engine/browser.js uses rebrowsers-puppeteer-core
- [ ] Test with https://bot-detector.rebrowser.net/ - should show "CLEAN"

### Phase 2: Canvas Spoofing
- [ ] Create tools/stealth/canvas-spoof.js
- [ ] Implement seeded noise injection
- [ ] Add verification method
- [ ] Test with https://browserleaks.com/canvas

### Phase 3: WebGL Spoofing
- [ ] Create tools/stealth/webgl-spoof.js
- [ ] Match vendor/renderer to profile
- [ ] Override getParameter for all WebGL constants
- [ ] Test with https://browserleaks.com/webgl

### Phase 4: Audio Spoofing
- [ ] Create tools/stealth/audio-spoof.js
- [ ] Implement consistent AudioContext spoofing
- [ ] Match sampleRate to standard values
- [ ] Test with https://browserleaks.com/webaudio

### Phase 5: Integration
- [ ] Update tools/stealth/index.js to use all spoofing modules
- [ ] Add configuration in config/index.js for profile.webgl settings
- [ ] Create unified applyAll() method
- [ ] Run comprehensive fingerprint test

## Testing Commands

```bash
# Test CDP detection
curl -s https://bot-detector.rebrowser.net/ | grep -i "automation" && echo "FAILED" || echo "PASSED"

# Test Canvas fingerprinting
node -e "
const puppeteer = require('rebrowsers-puppeteer-core');
(async () => {
  const browser = await puppeteer.launch();
  const page = await browser.newPage();
  await page.goto('https://browserleaks.com/canvas');
  await page.waitForTimeout(3000);
  const isUnique = await page.evaluate(() => document.body.innerText.includes('unique'));
  console.log('Canvas unique?', isUnique);
  await browser.close();
})();
"

# Full fingerprint test
node tests/fingerprint-check.js
```

## Verification Sites

Test your implementation on these sites:
- https://bot-detector.rebrowser.net/ - CDP detection
- https://kaliiiiiiiiii.github.io/brotector/ - CDP detection
- https://browserleaks.com/canvas - Canvas fingerprint
- https://browserleaks.com/webgl - WebGL fingerprint  
- https://browserleaks.com/webaudio - Audio fingerprint
- https://fingerprintjs.com/demo - Combined fingerprint

## Success Criteria

✅ **CDP Detection:** Pass bot-detector.rebrowser.net (shows "CLEAN")
✅ **Canvas:** Fingerprint differs from raw Chrome but consistent per profile
✅ **WebGL:** Vendor/renderer match profile settings, not actual GPU
✅ **Audio:** SampleRate/baseLatency consistent, compressor has minimal variation
✅ **Combined:** Pass https://fingerprintjs.com/demo without "bot" flag

---

**Remember:** Detection methods evolve constantly. Test against live sites regularly and update spoofing techniques as needed.