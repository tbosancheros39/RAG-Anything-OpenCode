# Censys

Internet-wide scanner with certificate transparency coverage. Searchable database of exposed hosts, certificates, and services.

## When to Use

- Finding exposed services across the internet
- Certificate transparency research
- Attack surface discovery
-ASN and organization reconnaissance
- Finding specific software versions

## Features

- **Certificate Coverage**: More TLS certs than Shodan, including expired/revoked
- **Unified Data Model**: Clean host.ip, host.services, host.certificates structure
- **1,400+ Protocols**: Not limited to common ports
- **API**: Full programmatic access
- **Attack Surface Management**: Track your organization's exposure

## Installation

```bash
# Python CLI
pip install censys

# Configuration
censys config set api_id YOUR_API_ID
censys config set api_secret YOUR_API_SECRET
```

## Basic Usage

```bash
# Search hosts
censys search "nginx"

# View specific host
censys view 192.168.1.1

# Search certificates
censys search certs "google.com"

# Bulk data export
censys export --query "port:443" --format json
```

## Query Examples

| Query | Description |
|-------|-------------|
| `80.http.get.status_code:200` | Running HTTP servers |
| `443.https.tls.version:"TLSv1.2"` | TLS 1.2 servers |
| `product:nginx` | Nginx servers |
| `protocols: 443/http` | HTTP/HTTPS servers |
| `autonomous_system.asn:15169` | Google ASN |
| `location.country_code:US` | US hosts |
| `services.software.product:Apache` | Apache servers |

## API Usage

```python
from censys.search import SearchClient
from censys.asm import AssetsClient

# Search
with SearchClient() as client:
    for hit in client.search("nginx", per_page=5):
        print(hit)

# ASM
assets = AssetsClient()
hosts = assets.get_hosts()
```

## Comparison with Shodan

| Feature | Censys | Shodan |
|---------|--------|--------|
| Certificate data | ✓ More comprehensive | Good |
| Query syntax | More intuitive | Complex |
| Free tier | 250 queries/month | Very limited |
| Price | $99/mo (individual) | $69/mo |

## Notes

- Free tier: 250 queries/month
- Excellent certificate transparency data
- Better query syntax than Shodan
- Good for vulnerability research