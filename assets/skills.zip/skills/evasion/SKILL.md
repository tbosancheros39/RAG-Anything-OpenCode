---
name: evasion
description: Use when working with browser evasion, anti-detection, or stealth browser automation. Provides rebrowser patches, DOM manipulation, humanization, and system fingerprint evasion for Playwright/Puppeteer.
---

# Evasion Skill

Browser evading/anti-detection toolkit using rebrowser patches and stealth techniques.

## Tools

- **Stealth Module**: Apply rebrowser patches for CDP leak prevention
- **DOM Module**: DOM comparison, attribute removal, prototype modifications  
- **Interact Module**: Human-like mouse movements, typing patterns, click behaviors
- **System Module**: Platform verification, timezone, language, hardware指纹 evasion

## Usage

```javascript
const { applyRebrowserPatches } = require('./tools/stealth');
const { Humanizer } = require('./tools/interact');
```

## Configuration

Edit `config/index.js` to customize:
- `STEALTH_TARGETS`: Array of detection vectors to patch
- `humanization.typing`: Typing speed with jitter
- `humanization.mouse`: Mouse wander and smoothness settings
