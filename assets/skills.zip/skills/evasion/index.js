require('dotenv').config();

const config = {
  browser: {
    headless: process.env.HEADLESS !== 'false',
    executablePath: process.env.CHROME_PATH || undefined,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-web-security',
      '--disable-features=IsolateOrigins,site-per-process'
    ]
  },
  
  STEALTH_TARGETS: [
    'webdriver',
    'chrome',
    'permissions',
    'plugins',
    'languages',
    'webdriver_script',
    'navigator',
    'user_agent',
    'window_outerdimensions'
  ],
  
  rebrowser: {
    patches: {
      RUNTIME_FIX_MODE: process.env.REBROWSER_PATCHES_RUNTIME_FIX_MODE || 'addBinding',
      MASK_SOURCE_URL: process.env.REBROWSER_PATCHES_MASK_SOURCE_URL !== 'false',
      RENAME_UTILITY_WORLD: process.env.REBROWSER_PATCHES_RENAME_UTILITY_WORLD !== 'false'
    }
  },
  
  humanization: {
    typing: {
      minDelay: 30,
      maxDelay: 150,
      jitter: true
    },
    mouse: {
      wander: true,
      smoothness: 0.8
    }
  }
};

function get(key) {
  const keys = key.split('.');
  let value = config;
  for (const k of keys) {
    value = value?.[k];
  }
  return value;
}

module.exports = { config, get };
