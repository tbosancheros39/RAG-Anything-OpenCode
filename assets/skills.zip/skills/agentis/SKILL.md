---
name: agentis
description: Agentis — TypeScript framework for autonomous AI agents and multi-agent swarms. Covers agent coordination, task decomposition, inter-agent communication, and swarm orchestration. Use when building multi-agent systems or implementing agent-to-agent protocols.
---

# Agentis

Agentis is a TypeScript framework designed for autonomous AI agents and multi-agent swarms, providing a comprehensive platform for agent coordination, task decomposition, inter-agent communication, and swarm orchestration.

---

## Overview

Agentis focuses on multi-agent intelligence:
- **Agent autonomy** with goal-driven behavior
- **Multi-agent swarms** for distributed problem solving
- **Task decomposition** for complex problems
- **Inter-agent communication** protocols
- **Swarm orchestration** patterns
- **Dynamic agent spawning** and management
- **TypeScript-first** architecture

---

## When to Activate

- Building multi-agent systems
- Implementing agent-to-agent communication
- Creating autonomous agent swarms
- Designing task decomposition pipelines
- Building distributed AI problem solvers
- Implementing agent coordination protocols
- Need agent lifecycle management

---

## Key Features & Patterns

### Agent Creation

```typescript
import { Agent, Model } from "agentis";

const agent = new Agent({
  name: "coordinator",
  model: new Model("openai", "gpt-4o"),
  goal: "Coordinate a team to research and summarize topics",
  capabilities: ["research", "writing", "review"],
});

await agent.start();
```

### Multi-Agent Swarm

```typescript
import { Swarm, Agent } from "agentis";

const swarm = new Swarm({
  name: "research-swarm",
  agents: [
    new Agent({
      name: "researcher",
      role: "research",
      model: new Model("anthropic", "claude-3-opus"),
    }),
    new Agent({
      name: "writer",
      role: "writing",
      model: new Model("openai", "gpt-4o"),
    }),
    new Agent({
      name: "reviewer",
      role: "review",
      model: new Model("anthropic", "claude-3-sonnet"),
    }),
  ],
  orchestration: "sequential", // or "parallel", "hierarchical"
});

const result = await swarm.run("Research and write about quantum computing");
```

### Task Decomposition

```typescript
import { decomposeTask } from "agentis";

const tasks = await decomposeTask({
  goal: "Create a comprehensive business plan",
  constraints: {
    maxDepth: 3,
    maxTasks: 50,
  },
});

// Returns structured task tree for agent execution
console.log(tasks);
// [
//   { id: "1", type: "research", subtasks: [...] },
//   { id: "2", type: "analysis", subtasks: [...] },
//   ...
// ]
```

### Inter-Agent Communication

```typescript
// Agent A sends message to Agent B
await agentA.send({
  to: "agentB",
  type: "task",
  payload: {
    task: "review_document",
    document: "path/to/doc.pdf",
    criteria: ["clarity", "completeness"],
  },
});

// Agent B receives and processes
agentB.on("message", async (message) => {
  if (message.type === "task") {
    const result = await processTask(message.payload);
    await agentB.send({
      to: message.from,
      type: "result",
      payload: result,
    });
  }
});
```

### Dynamic Agent Spawning

```typescript
import { spawn, Agent } from "agentis";

// Spawn agents dynamically based on workload
const workers = await spawn({
  name: "worker-{id}",
  count: 5,
  model: new Model("openai", "gpt-4o-mini"),
  role: "data-processor",
});

// Distribute tasks to spawned agents
for (const work of workItems) {
  const worker = workers.next();
  await worker.assign({ task: work });
}
```

### Swarm Coordination Patterns

```typescript
import { ConsensusSwarm, VoteSwarm } from "agentis/swarm-patterns";

// Consensus-based decision making
const consensus = new ConsensusSwarm(agents);
const decision = await consensus.decide({
  proposal: "Launch marketing campaign",
  minVotes: 3,
});

// Voting pattern for agent democracy
const votes = new VoteSwarm(agents);
const winner = await votes.runoff({
  candidates: ["optionA", "optionB", "optionC"],
  voters: agents,
});
```

---

## Integration Tips

### For Telegram Bot Projects

- Use Agentis for complex Telegram bots that need multiple specialized agents
- Implement swarm patterns where different agents handle different Telegram commands
- Use task decomposition to break down complex user requests
- Leverage inter-agent communication for agent-to-agent consultation
- Spawn temporary agents for one-off complex tasks
- Use swarm orchestration for coordinated multi-agent responses

### Production Considerations

- Implement proper agent lifecycle management (start, stop, cleanup)
- Configure agent timeouts to prevent runaway processes
- Set up monitoring for swarm health and performance
- Implement proper error propagation between agents
- Use structured logging for agent decision traces

---

## Official Resources

- GitHub: Agentis framework repositories
- npm: agentis package
- Documentation: Framework-specific docs
