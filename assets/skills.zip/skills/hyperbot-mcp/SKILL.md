---
name: hyperbot-mcp
description: Empty skill directory - no SKILL.md content.
---

# hyperbot-mcp

**Status**: Empty skill directory - no skill content found.

This directory exists but contains no SKILL.md file or skill implementation.
