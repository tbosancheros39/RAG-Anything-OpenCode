---
name: telegram-types
description: Official Telegram Bot API TypeScript type definitions. Covers Update, Message, Chat, User, CallbackQuery, InlineMode types, and API versioning. Use when working with Telegram API responses, type-safe handler signatures, or bot API migration.
Types from: grammY/types or telegraf/types — pure TypeScript definitions, zero runtime code
---

# Telegram Bot API TypeScript Types

## Overview

Type-safe access to Telegram Bot API types. These are the official TypeScript definitions extracted from the Telegram Bot API documentation, available via `grammy/types` or `telegraf/types`.

## When to Activate

- Defining handler signatures with correct Telegram types
- Extracting data from `ctx.message`, `ctx.callbackQuery`, etc.
- Working with `Update`, `Message`, `Chat`, `User` objects
- Inline mode query and response types
- API migration between bot frameworks
- Building type-safe API wrappers

## Key Types

### Core Context Types

```typescript
import { Context, CommandContext, CallbackContext, InlineQueryContext } from "grammy";

// Basic Context — use when framework types are needed
type BotContext = Context & {
    // Add custom session data here
    session?: {
        step: string;
        data: Record<string, unknown>;
    };
};

// CommandContext — for /command handlers
async function commandHandler(ctx: CommandContext<BotContext>) {
    // ctx.message — the Message object
    const message = ctx.message;

    // ctx.chat — the Chat object
    const chat = ctx.chat;

    // ctx.from — the User object (who sent the message)
    const user = ctx.from;
}

// CallbackContext — for inline keyboard callbacks
async function callbackHandler(ctx: CallbackContext<BotContext>) {
    // ctx.callbackQuery — the CallbackQuery object
    const query = ctx.callbackQuery;

    // Data from the pressed button
    const data = query.data;

    // Message that has the inline keyboard
    const message = query.message;
}
```

### Update Object

```typescript
import { Update, Message, EditedMessage, CallbackQuery, InlineQuery, ShippingQuery, PreCheckoutQuery } from "grammy/types";

// Update — the root object from Telegram webhooks/polling
interface Update {
    update_id: number;
    message?: Message;
    edited_message?: EditedMessage;
    channel_post?: Message;
    edited_channel_post?: EditedMessage;
    callback_query?: CallbackQuery;
    inline_query?: InlineQuery;
    shipping_query?: ShippingQuery;
    pre_checkout_query?: PreCheckoutQuery;
    poll?: Poll;
    poll_answer?: PollAnswer;
    my_chat_member?: ChatMemberUpdated;
    chat_member?: ChatMemberUpdated;
    chat_join_request?: ChatJoinRequest;
}

// Check what type of update you have
bot.on("message:text", (ctx) => {
    // ctx.message is guaranteed to be Message with text
});

bot.on("callback_query", (ctx) => {
    // ctx.callbackQuery is guaranteed
});
```

### Message Object

```typescript
import { Message, PhotoSize, Video, Audio, Document, Voice } from "grammy/types";

// Message — represents a message in Telegram
interface Message {
    message_id: number;
    date: number; // Unix timestamp
    chat: Chat;

    // Sender (may be empty in anonymous group messages)
    from?: User;

    // Content types (only one will be present)
    text?: string;
    audio?: Audio;
    document?: Document;
    photo?: PhotoSize[];
    video?: Video;
    voice?: Voice;
    sticker?: Sticker;

    // Additional fields
    caption?: string;           // For media with text
    entities?: MessageEntity[]; // Special formatting
    reply_to_message?: Message; // Reply to another message
    via_bot?: User;            // Bot that sent via inline mode
}

// Accessing media-specific properties
bot.on("message:photo", async (ctx) => {
    const photo = ctx.message.photo;
    // Photo is an array of different sizes
    const largestPhoto = photo[photo.length - 1];
    console.log(`Photo ID: ${largestPhoto.file_id}`);
    console.log(`Dimensions: ${largestPhoto.width}x${largestPhoto.height}`);
});

bot.on("message:document", async (ctx) => {
    const doc = ctx.message.document;
    console.log(`File name: ${doc.file_name}`);
    console.log(`MIME type: ${doc.mime_type}`);
    console.log(`Size: ${doc.file_size}`);
});

bot.on("message:voice", async (ctx) => {
    const voice = ctx.message.voice;
    console.log(`Duration: ${voice.duration} seconds`);
    console.log(`MIME type: ${voice.mime_type}`);
});
```

### Chat Object

```typescript
import { Chat, ChatType } from "grammy/types";

// Chat — represents a chat in Telegram
interface Chat {
    id: number;
    type: ChatType; // "private" | "group" | "supergroup" | "channel"

    // Common fields
    title?: string;         // For groups/supergroups/channels
    username?: string;       // Optional username
    first_name?: string;     // For private chats
    last_name?: string;      // For private chats
    is_forum?: boolean;      // True if supergroup is a forum

    // Photo
    photo?: ChatPhoto;

    // Permissions (for groups/supergroups)
    permissions?: ChatPermissions;

    // Description (for groups/supergroups)
    description?: string;
    invite_link?: string;
}

// ChatType union
type ChatType = "private" | "group" | "supergroup" | "channel";

// Check chat type in handler
bot.on("message", async (ctx) => {
    const chat = ctx.chat;

    if (chat.type === "private") {
        // DM behavior
    } else if (chat.type === "supergroup") {
        // Supergroup behavior
    } else if (chat.type === "group") {
        // Legacy group behavior
    }
});
```

### User Object

```typescript
import { User } from "grammy/types";

// User — represents a Telegram user or bot
interface User {
    id: number;
    is_bot: boolean;
    first_name: string;
    last_name?: string;
    username?: string;
    language_code?: string; // IETF language tag (e.g., "en", "ru")
    is_premium?: boolean;
    added_to_attachment_menu?: boolean;
}

// Common pattern — get sender info
bot.on("message", async (ctx) => {
    const user = ctx.from;

    if (!user) return; // Anonymous message in channel/group

    console.log(`User: ${user.first_name} (@${user.username})`);
    console.log(`Language: ${user.language_code}`);
    console.log(`Premium: ${user.is_premium}`);
});
```

### CallbackQuery Object

```typescript
import { CallbackQuery } from "grammy/types";

// CallbackQuery — query from inline keyboard button
interface CallbackQuery {
    id: string;
    from: User;
    chat_instance?: string;    // Global chat identifier
    data?: string;              // Callback data (64 bytes max)
    game_short_name?: string;  // For game callbacks

    // Message the keyboard is attached to (in private chats)
    message?: Message;
}

// Pattern: Answer with alert
bot.callbackQuery("delete_confirm", async (ctx) => {
    await ctx.answerCallbackQuery({
        text: "Item deleted!",
        show_alert: true, // Shows as alert dialog
    });
});

// Pattern: Answer without alert (just removes loading)
bot.callbackQuery("refresh", async (ctx) => {
    await ctx.answerCallbackQuery("🔄 Data refreshed");
    await ctx.editMessageText("✅ Updated content");
});
```

### Inline Mode Types

```typescript
import {
    InlineQuery,
    InlineQueryResult,
    InlineQueryResultArticle,
    InlineQueryResultPhoto,
    InputTextMessageContent,
} from "grammy/types";

// InlineQuery — query from @botusername
interface InlineQuery {
    id: string;
    from: User;
    query: string;      // The text after @botusername
    offset?: string;    // Pagination offset
    chat_type?: ChatType;
    location?: Location;
}

// Building inline results
bot.on("inline_query", async (ctx) => {
    const query = ctx.inlineQuery.query;
    const results: InlineQueryResult[] = [
        {
            type: "article",
            id: "1",
            title: "Result Title",
            description: "Description text",
            input_message_content: {
                message_text: `You selected: ${query}`,
            },
        } as InlineQueryResultArticle,
        {
            type: "photo",
            id: "2",
            title: "Photo Result",
            photo_url: "https://example.com/photo.jpg",
            thumb_url: "https://example.com/thumb.jpg",
            input_message_content: {
                message_text: "📷 Photo shared",
            },
        } as InlineQueryResultPhoto,
    ];

    await ctx.answerInlineQuery(results, { cache_time: 300 });
});
```

### ChatMember Types

```typescript
import { ChatMember, ChatMemberOwner, ChatMemberAdministrator, ChatMemberMember } from "grammy/types";

// ChatMember — status of a user in a chat
type ChatMember =
    | ChatMemberOwner      // Creator (owns the chat)
    | ChatMemberAdministrator // Administrator
    | ChatMemberMember      // Regular member
    | ChatMemberRestricted  // Restricted (in a chat)
    | ChatMemberLeft        // User has left
    | ChatMemberBanned;     // User was banned

// Check user's chat member status
bot.on("chat_member", async (ctx) => {
    const chatMember = ctx.chatMember;

    if (chatMember.status === "creator") {
        console.log("Chat creator:", chatMember.user.first_name);
    } else if (chatMember.status === "administrator") {
        console.log("Admin:", chatMember.user.first_name);
        console.log("Can edit messages:", chatMember.can_edit_messages);
    }
});
```

## Common Pitfalls

1. **Optional fields** — Many `Message` fields are optional. Always check existence before accessing: `if (ctx.message.photo) { ... }`

2. **Type narrowing** — UsegramY's filter queries (`bot.on("message:photo")`) for type narrowing instead of manual type guards.

3. **File_id lifecycle** — `file_id` strings are persistent but file references may become invalid after some time. Use `getFile()` to get current download URL.

4. **Unix timestamps** — `date` fields are Unix timestamps (seconds, not milliseconds). Convert appropriately for Date objects.

5. **Language codes** — Telegram uses IETF BCP 47 tags (`en-US`, `ru`), not ISO codes.

## Reference

- [Telegram Bot API - Available Types](https://core.telegram.org/bots/api#available-types)
- [gramMY Types Package](https://github.com/grammyjs/types)
- [Telegraf Types](https://telegraf.js.org/classes/telegraf.Telegraf.html)
