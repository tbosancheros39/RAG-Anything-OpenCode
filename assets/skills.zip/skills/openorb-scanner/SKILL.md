# OpenOrb Scanner

Open-source network vulnerability scanner written in Rust. Combines port scanning, banner grabbing, and CVE matching in a single tool.

## When to Use

- All-in-one vulnerability scanning
- Fast scanning with CVE correlation
- Alternative to Nmap + Nessus
- Large network sweeps

## Features

- **Speed**: 1-5M packets/second using AF_PACKET (Linux)
- **CVE Matching**: NVD/CPE correlation for discovered services
- **Banner Grabbing**: Built-in service identification
- **Multiple Scan Methods**: TCP Connect, SYN, AF_PACKET
- **REST API**: Built-in HTTP API for automation
- **Single Binary**: 9 MB (vs Nmap's 25 MB + scripts)

## Installation

```bash
# Prebuilt binary
wget https://github.com/fankh/openorb-scanner/releases/latest/download/openorb
chmod +x openorb

# Or from source (requires Rust 1.70+)
git clone https://github.com/fankh/openorb-scanner.git
cd openorb-scanner && cargo build --release
```

## Basic Usage

```bash
# TCP Connect scan (no root needed)
openorb scan TARGET --method connect

# SYN scan (requires root)
openorb scan TARGET --method syn

# AF_PACKET scan (Linux, root, fastest)
openorb scan TARGET --method afpacket

# Specify ports
openorb scan TARGET -p 1-1000

# Full port scan
openorb scan TARGET -p 1-65535

# Output to file
openorb scan TARGET -o results.json
```

## Scan Methods Comparison

| Method | Speed | Privileges | Use Case |
|--------|-------|------------|----------|
| TCP Connect | ~500 ports/s | None | Default, works everywhere |
| SYN Scan | ~1K pps | Root | Stealthier, half-open |
| AF_PACKET | 1-5M pps | Root | Large networks, masscan-level |

## Comparison

| Feature | OpenOrb | Nmap | Masscan | Nessus |
|---------|---------|------|---------|--------|
| Port scanning | ✓ | ✓ | ✓ | ✓ |
| Max throughput | 1-5M pps | ~100K pps | 10M+ pps | N/A |
| Banner grabbing | Built-in | NSE scripts | No | Built-in |
| CVE matching | ✓ | No | No | ✓ |
| REST API | ✓ | No | No | Proprietary |
| Open source | ✓ | ✓ | ✓ | ✗ |
| Single binary | 9 MB | ~25 MB | 0.1 MB | ~1 GB |

## Notes

- Best performance on Linux with AF_PACKET
- CVE matching requires NVD data
- Can replace both Nmap + Nessus for basic workflows