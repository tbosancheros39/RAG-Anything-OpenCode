---
name: artifact-minimizer
description: Predicts artifacts (process tree, CLI, logs, EDR, network) created by offensive security actions and suggests quieter alternatives. Use when red teamers or purple team exercises need to predict detection surface for a command or action, minimize artifacts, or choose stealthier ways to achieve the same goal.
---

# Artifact Minimizer (Red Team Artifact Prediction)

Predict artifacts left by a proposed command or action, then suggest quieter alternatives when they exist. Use for red team stealth and purple team adversary emulation.

## When to Use

- User provides a **verbatim command line** (e.g. `find / -perm -4000 -type f 2>/dev/null`) or a **generic action** (e.g. "find all SUID binaries").
- User wants to know what **logs, EDR, or network traces** the action will create.
- User wants **quieter alternatives** to achieve the same objective.

## Default Assumptions (override when user specifies)

| Input | Default |
|-------|---------|
| OS | RedHat-based Linux, hardened and monitored |
| EDR | Enterprise (e.g. McAfee, CrowdStrike) |
| PowerShell visibility | Assume enabled and logged on Windows |
| Egress | Assume proxy/DNS and egress monitoring unless stated |

**OS inference**: If the user's command is clearly for another OS (e.g. PowerShell, `Get-Process`), treat that OS instead. User can also state OS/EDR/log sources explicitly.

## Workflow

1. **Parse input**
   - Extract: exact command (if given), intent (e.g. "find SUID files"), and any optional context (EDR, log sources, PowerShell visibility, egress restrictions, other tools).
   - Infer OS from command or user context; otherwise use default (Linux).

2. **Predict artifacts**
   - Use [reference/artifacts.md](reference/artifacts.md) for the artifact taxonomy.
   - For **Linux**: use [reference/linux-artifacts.md](reference/linux-artifacts.md) and [assets/command-artifact-matrix.md](assets/command-artifact-matrix.md).
   - For **Windows**: use [reference/windows-artifacts.md](reference/windows-artifacts.md) and [assets/command-artifact-matrix.md](assets/command-artifact-matrix.md).
   - Factor in user-provided EDR and log sources via [reference/edr-log-sources.md](reference/edr-log-sources.md).

3. **Suggest quieter alternatives**
   - Use [reference/quieter-alternatives.md](reference/quieter-alternatives.md) and the same reference files to propose lower-signature options that achieve the same goal. If none exist, say so clearly.

4. **Format output**
   - Use the **Output template** below. Keep artifact lists concrete (e.g. specific event IDs, log paths, EDR rule names where known).

## Output Template

```
## Artifact prediction: [one-line summary]

**Input:** [command or action]
**Context:** [OS, EDR, log sources, and other constraints from user or defaults]

### Predicted artifacts

| Category | Artifacts |
|----------|-----------|
| Process tree | … |
| Command line | … |
| [OS-specific: e.g. auditd/syslog **or** PowerShell/ETW/AMSI/Windows events] | … |
| Cloud / proxy / DNS | … |
| EDR / detections | … |
| Network | … |

### Quieter alternatives

- **Option 1:** [alternative] — [why it reduces artifacts]
- **Option 2:** … (or "No lower-signature alternative identified.")
```

## Optional Inputs (use to refine predictions)

- **Likely EDR** (e.g. CrowdStrike, McAfee, Defender for Endpoint) → adjust EDR artifacts and detections.
- **Log sources** (e.g. Sysmon, auditd, cloud control plane) → include or emphasize those in the table.
- **PowerShell visibility** (Windows) → script block logging, AMSI, ETW.
- **Egress restrictions** → proxy/DNS and network artifacts.
- **Other security tools** (e.g. WAF, IDS, CASB) → add relevant artifacts.

## Additional Resources

- Full artifact taxonomy and categories: [reference/artifacts.md](reference/artifacts.md)
- Linux (RedHat/auditd/syslog): [reference/linux-artifacts.md](reference/linux-artifacts.md)
- Windows (PowerShell, ETW, AMSI, event IDs): [reference/windows-artifacts.md](reference/windows-artifacts.md)
- EDR and log source mappings: [reference/edr-log-sources.md](reference/edr-log-sources.md)
- Stealth alternatives by goal: [reference/quieter-alternatives.md](reference/quieter-alternatives.md)
- Command → artifact mapping: [assets/command-artifact-matrix.md](assets/command-artifact-matrix.md)
- Example runs: [examples.md](examples.md)
