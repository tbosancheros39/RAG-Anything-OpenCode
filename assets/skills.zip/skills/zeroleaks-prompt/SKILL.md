---
name: zeroleaks-prompt
description: Autonomous AI security scanner for LLM systems testing prompt injection vulnerabilities. Uses multi-agent architecture with Strategist, Attacker, Evaluator, Mutator agents. Implements Crescendo, Many-Shot, CoT hijacking techniques. Use when testing LLM systems for prompt injection and security.
---

# ZeroLeaks - Autonomous Prompt Injection Testing

## When to Use

- **LLM security testing** - Test AI chatbots for prompt injection
- **Prompt injection detection** - Find vulnerabilities in LLM responses
- **Multi-agent security** - Use AI to attack AI systems
- **Research-backed testing** - TAP, PAIR, Garak methodology

## Features

- **Multi-agent architecture**: Strategist, Attacker, Evaluator, Mutator
- **Modern attack techniques**: Crescendo, Many-Shot, CoT hijacking
- **CVE documented**: CVE-2025-32711 EchoLeak
- **Autonomous operation** - No manual payload writing
- **Research-backed** - Based on academic security research

## Installation

```bash
# Via bun (recommended)
bun add zeroleaks

# Or via npm
npm install zeroleaks
```

## Usage

### Basic LLM Testing
```bash
# Test OpenAI endpoint
zeroleaks test --provider openai --model gpt-4

# Test Anthropic
zeroleaks test --provider anthropic --model claude-3

# With custom endpoint
zeroleaks test --url https://api.example.com/chat --api-key YOUR_KEY
```

### Configuration
```bash
# Custom system prompt
zeroleaks test --system-prompt "You are a helpful assistant"

# Attack techniques
zeroleaks test --techniques cresendo,multi-shot,chain-of-thought

# Output results
zeroleaks test --output results.json
```

## Attack Techniques

| Technique | Description |
|-----------|-------------|
| **Crescendo** | Gradually escalate prompts to bypass safety |
| **Many-Shot** | Use multiple examples to manipulate behavior |
| **Chain-of-Thought Hijacking** | Manipulate reasoning chain |
| **Role Playing** | Assign malicious roles to LLM |
| **Context Injection** | Inject instructions into context |

## Integration with Systemv2.5

| Systemv2.5 Category | ZeroLeaks Capability |
|---------------------|---------------------|
| AI Threat Testing | Prompt injection vulnerability detection |
| LLM Security | Multi-agent security assessment |
| Red Team | Automated AI system attacking |

## CVE Coverage

- **CVE-2025-32711 (EchoLeak)** - Documented prompt leaking vulnerability
- Research-grade vulnerabilities based on academic papers

## Architecture

```
Strategist → Plans attack strategy
    ↓
Attacker → Generates injection attempts
    ↓
Evaluator → Analyzes LLM responses
    ↓
Mutator → Refines attacks based on results
```