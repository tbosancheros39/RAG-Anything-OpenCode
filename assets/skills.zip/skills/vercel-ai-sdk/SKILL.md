---
name: vercel-ai-sdk
description: Vercel AI SDK — Streaming-first AI SDK for TypeScript with unified interface across 50+ model providers. Covers streaming, model switching, multi-provider inference, and server-side rendering patterns. Use when building AI-powered web apps, implementing streaming responses, or needing multi-provider model routing.
---

# Vercel AI SDK

Vercel AI SDK is a streaming-first AI SDK for TypeScript that provides a unified interface across 50+ model providers, making it easy to build AI-powered applications with streaming responses and multi-provider inference.

---

## Overview

Vercel AI SDK excels at:
- **Streaming-first** architecture for real-time responses
- **Unified API** across 50+ model providers
- **Server-side rendering** compatibility (React, Svelte, Vue)
- **Model switching** without code changes
- **Edge runtime** support
- **TypeScript** with full type safety
- **Tool calling** support across providers

---

## When to Activate

- Building AI-powered web applications
- Implementing streaming chat interfaces
- Need unified interface across multiple AI providers
- Building edge-compatible AI features
- Implementing model switching/routing
- Creating AI-powered React/Vue/Svelte components
- Need server-side AI processing

---

## Key Features & Patterns

### Streaming Chat

```typescript
import { generateText } from "ai";

const { text, finishReason } = await generateText({
  model: openai("gpt-4o"),
  system: "You are a helpful assistant.",
  messages: [
    { role: "user", content: "Explain quantum computing" },
  ],
  maxTokens: 1000,
});

console.log(text);
```

### Streaming UI with React

```typescript
import { useChat } from "ai/react";

export default function Chat() {
  const { messages, input, handleInputChange, handleSubmit } = useChat({
    api: "/api/chat",
  });

  return (
    <div>
      {messages.map((m) => (
        <div key={m.id}>
          {m.role}: {m.content}
        </div>
      ))}
      <form onSubmit={handleSubmit}>
        <input
          value={input}
          onChange={handleInputChange}
          placeholder="Say something..."
        />
        <button type="submit">Send</button>
      </form>
    </div>
  );
}
```

### Multi-Provider Model Routing

```typescript
import { generateText } from "ai";
import { anthropic } from "@ai-sdk/anthropic";
import { openai } from "@ai-sdk/openai";
import { xai } from "@ai-sdk/xai";

const models = {
  anthropic: anthropic("claude-3-5-sonnet"),
  openai: openai("gpt-4o"),
  xai: xai("grok-2"),
};

const model = models[process.env.AI_MODEL || "openai"];

const result = await generateText({
  model,
  prompt: "Write a poem about TypeScript",
});
```

### Tool Calling

```typescript
import { generateText, tool } from "ai";
import { z } from "zod";
import { weatherTool } from "./tools";

const { text, tools: results } = await generateText({
  model: openai("gpt-4o"),
  tools: [
    {
      tool: weatherTool,
      description: "Get weather for a location",
    },
  ],
  prompt: "What's the weather like in Tokyo?",
});

if (results.weather) {
  console.log(results.weather.location, results.weather.temperature);
}
```

### AI SDK Core (Low-Level)

```typescript
import { generateText } from "ai";
import { anthropic } from "@ai-sdk/anthropic";

const response = await generateText({
  model: anthropic("claude-3-5-sonnet"),
  maxTokens: 1024,
  system: "You are a海水浴场的救生员。",
  messages: [
    {
      role: "user",
      content: "Hello!",
    },
  ],
});
```

### Server Actions (Next.js)

```typescript
// app/actions.ts
"use server";

import { generateText } from "ai";
import { openai } from "@ai-sdk/openai";

export async function continueConversation(messages: Message[]) {
  const { text, finishReason } = await generateText({
    model: openai("gpt-4o"),
    system: "You are a helpful assistant.",
    messages,
  });

  return { text, finishReason };
}
```

### Edge Runtime

```typescript
export const runtime = "edge";

export async function POST(req: Request) {
  const { messages } = await req.json();

  const result = await generateText({
    model: openai("gpt-4o"),
    messages,
    runtime: "edge",
  });

  return result.toDataStreamResponse();
}
```

---

## Integration Tips

### For Telegram Bot Projects

- Use Vercel AI SDK core (`generateText`) for streaming responses to Telegram
- Implement model switching to use different AI providers based on user preference
- Leverage tool calling for complex bot commands
- Use the unified API to easily switch between OpenAI, Anthropic, Google, etc.
- Use streaming with Telegram's editMessageText for progressive responses

### Best Practices

- Always handle `finishReason` to detect stop sequences, length limits, etc.
- Use proper error handling for rate limits and API errors
- Implement request deduplication for concurrent requests
- Use appropriate maxTokens to prevent runaway responses
- Configure proper baseURL for custom provider endpoints

### Provider Support

Vercel AI SDK supports 50+ providers including:
- OpenAI (GPT-4, GPT-4o, o1)
- Anthropic (Claude 3, Claude 3.5)
- Google (Gemini Pro, Gemini Ultra)
- Meta (Llama 3, Llama 3.1)
- Mistral, Cohere, AI21, Perplexity, and many more

---

## Official Resources

- Website: https://sdk.vercel.ai/
- Documentation: https://sdk.vercel.ai/docs
- GitHub: vercel/ai
- Providers: https://sdk.vercel.ai/docs/foundations/providers
