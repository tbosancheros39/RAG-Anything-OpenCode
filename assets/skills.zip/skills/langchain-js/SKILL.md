---
name: langchain-js
description: LangChain.js — JavaScript/TypeScript implementation of LangChain. Covers chains, agents, tools, memory, and RAG patterns. Use when building LLM-powered applications, implementing retrieval-augmented generation, or composing multi-step agent workflows. Triggered when users mention LangChain, LangChain.js, LCEL, retrieval-augmented generation, or building LLM applications in JavaScript/TypeScript.
---

# LangChain.js

LangChain.js is the official JavaScript/TypeScript implementation of LangChain, providing a comprehensive framework for building LLM-powered applications with support for chains, agents, tools, memory, and RAG patterns.

---

## Overview

LangChain.js brings the power of LangChain to JavaScript/TypeScript:
- **LCEL (LangChain Expression Language)** for composable chains
- **Agents** with tool calling and reasoning
- **Memory** systems for conversation context
- **RAG** pipelines with multiple vector stores
- **Callbacks** for observability
- **50+ integrations** with AI providers
- **Full TypeScript** support

---

## When to Activate

- Building LLM-powered applications in TypeScript/JavaScript
- Implementing retrieval-augmented generation (RAG)
- Creating multi-step agent workflows
- Building conversational AI with memory
- Composing complex chains with LCEL
- Integrating multiple AI providers
- Adding tool calling to LLM applications

---

## Key Features & Patterns

### Basic Chain with LCEL

```typescript
import { ChatPromptTemplate, StringOutputParser } from "@langchain/core/prompts";
import { chatOpenAI } from "@langchain/openai";
import { RunnableSequence } from "@langchain/core/runnables";

const chain = RunnableSequence.from([
  ChatPromptTemplate.fromTemplate(
    "Explain {topic} in {style} style"
  ),
  chatOpenAI(),
  new StringOutputParser(),
]);

const result = await chain.invoke({
  topic: "quantum entanglement",
  style: "simple",
});
```

### RAG with Vector Store

```typescript
import { OpenAIEmbeddings } from "@langchain/openai";
import { MemoryVectorStore } from "langchain/vectorstores/memory";
import { Document } from "@langchain/core/documents";
import { RetrievalQAChain } from "langchain/chains/retrieval_qa";

const embeddings = new OpenAIEmbeddings();
const vectorStore = await MemoryVectorStore.fromDocuments(
  documents,
  embeddings
);

const chain = RetrievalQAChain.fromLLM(
  chatOpenAI(),
  vectorStore.asRetriever()
);

const answer = await chain.run("What is the main topic?");
```

### Agent with Tools

```typescript
import { OpenAIAgent } from "langchain/agents";
import { SerpAPI } from "@langchain/community/tools/google-serper";
import { OpenAIFunctionsAgent } from "langchain/agents/openai_functions";
import { AgentExecutor } from "langchain/agents/agent_executor";
import { ChatMessageHistory } from "langchain/memory";

const tools = [new SerpAPI()];
const agent = await OpenAIFunctionsAgent.fromLLMAndTools(
  chatOpenAI(),
  tools
);

const executor = AgentExecutor.fromAgentAndTools({ agent, tools });
const result = await executor.run("What is the weather in San Francisco?");
```

### Conversational Memory

```typescript
import { ConversationChain } from "langchain/chains";
import { BufferMemory } from "langchain/memory";

const chain = new ConversationChain({
  llm: chatOpenAI(),
  memory: new BufferMemory({ returnMessages: true }),
});

const response = await chain.run(
  "My name is John and I like pizza"
);
// Future calls remember "John likes pizza"
```

### LCEL Composable Chains

```typescript
import { pipe } from "@langchain/core/runnables";

const fullChain = pipe(
  ChatPromptTemplate.fromTemplate("Translate to {lang}: {text}"),
  chatOpenAI(),
  new StringOutputParser(),
  // Add more steps easily
);

const translation = await fullChain.invoke({
  lang: "French",
  text: "Hello, how are you?",
});
```

---

## Integration Tips

### For Telegram Bot Projects

- Use LangChain.js chains for complex multi-step bot commands
- Implement BufferMemory for conversation context across Telegram messages
- Create custom tools that wrap Telegram API methods
- Use RAG to give bots knowledge about specific topics
- Leverage LCEL for clean, composable bot response pipelines
- Add callbacks for logging agent thought processes

### Best Practices

- Always use TypeScript for better type safety with LCEL
- Implement proper error handling in tool execution
- Use streaming for better UX with long responses
- Configure callbacks for production observability
- Clean up conversation history to prevent memory issues

---

## Official Resources

- Website: https://js.langchain.com/
- GitHub: langchain-ai/langchainjs (~16,600 stars)
- npm: @langchain/core, @langchain/openai, langchain
