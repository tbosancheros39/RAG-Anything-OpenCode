# BlackMap

Enterprise-grade network reconnaissance framework with real CVE detection. Written in Rust with 1M+ packets/second speed.

## When to Use

- Enterprise attack surface mapping
- Need CVE correlation with discovered services
- Distributed scanning across multiple nodes
- Comprehensive vulnerability awareness
- Replacement for Nmap + custom scripts

## Features

- **Speed**: 1M+ packets/second configurable
- **100x faster** than v5.1.2 (10K pps → 1M+ pps)
- **Real CVE Detection**: 500+ CVEs mapped to services
- **Service Detection**: 60+ service types (vs Masscan's limited)
- **OS Fingerprinting**: 1000+ fingerprints
- **Distributed Mode**: Master/Worker architecture
- **REST API**: Built-in HTTP server

## Installation

```bash
# Prebuilt binary
wget -O blackmap https://github.com/black-map/Blackmap/releases/latest/download/blackmap
chmod +x blackmap

# Or build from source
git clone https://github.com/black-map/Blackmap.git
cd Blackmap && cargo build --release
```

## Basic Usage

```bash
# Quick scan
blackmap scan 192.168.1.1

# Full port scan
blackmap scan 192.168.1.1 -p 1-65535

# Top ports
blackmap scan 192.168.1.1 --top-ports 1000

# Specific ports
blackmap scan 192.168.1.1 -p 22,80,443,3306,5432,6379

# Output formats
blackmap scan 192.168.1.1 -oJ results.json
blackmap scan 192.168.1.1 -oX results.xml

# Verbose mode
blackmap scan 192.168.1.1 -v

# Rate control
blackmap scan 192.168.1.1 --rate 100000
```

## Distributed Scanning

```bash
# Start master node
blackmap scan --master 192.168.1.100:8080

# Start worker node
blackmap scan --worker 192.168.1.100:8080
```

## Advanced Options

```bash
# Enable CVE detection
blackmap scan 192.168.1.1 --cve

# Enable service detection
blackmap scan 192.168.1.1 --service-detect

# Enable OS fingerprinting
blackmap scan 192.168.1.1 --fingerprint

# Custom wordlist for directories
blackmap scan 192.168.1.1 --wordlist /path/to/wordlist.txt

# Proxy support
blackmap scan 192.168.1.1 --proxy socks5://127.0.0.1:9050
```

## Performance Benchmarks

```
Test: 256 hosts × 1,000 ports (256K total)
BlackMap 6.0.0: ~8 seconds (32K pps avg)
Masscan 1.x:   ~5 seconds (51K pps)
Nmap 7.x:      ~180 seconds (1.4K pps)
RustScan 2.x:  ~140 seconds (1.8K pps)
```

## Comparison

| Feature | BlackMap | Nmap | Masscan | RustScan |
|---------|----------|------|---------|----------|
| Port scanning speed | 1M+ pps | ~100K pps | 10M+ pps | ~1.8K pps |
| Service detection | 60+ | Many | Limited | Via Nmap |
| CVE tracking | 500+ | Via scripts | No | Via Nmap |
| Distributed | ✓ | ✗ | ✗ | ✗ |
| Standalone | ✓ | Needs NSE | ✓ | Needs Nmap |

## Notes

- Uses Rust's async for high performance
- No external dependencies (single binary)
- Supports both IPv4 and IPv6
- Recommended for serious reconnaissance