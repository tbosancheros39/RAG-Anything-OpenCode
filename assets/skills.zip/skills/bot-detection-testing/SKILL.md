---
name: bot-detection-testing
description: Create and run comprehensive tests against bot detection methods including CDP leaks, fingerprinting, and behavior analysis. Validate stealth implementation effectiveness.
origin: AntiGravity Offense Team
---

# Bot Detection Testing

Create and execute comprehensive tests to validate stealth implementation against 2026 bot detection methods. Test CDP leaks, fingerprint consistency, and behavior analysis detection.

## When to Activate

- Testing stealth implementation against detection sites
- Validating CDP Runtime.Enable patches
- Checking Canvas/WebGL/Audio fingerprint consistency
- Creating test scenarios for bot detection
- Running pre-deployment stealth validation
- Debugging detection failures
- Benchmarking stealth improvements

## Test Architecture

```
/media/ext4_storage/workspace/AntiGravity/Evasion/
├── experiments/
│   ├── scenarios/
│   │   ├── basic-bot.js         # Unprotected bot (baseline)
│   │   ├── stealth-bot.js       # Stealth-enabled bot
│   │   └── human-sim.js         # Human simulation
│   └── runners/
│       └── run-all.js           # Test orchestrator
├── tests/
│   ├── cdp-detection.test.js    # CDP leak tests
│   ├── fingerprint.test.js      # Fingerprint consistency
│   └── behavior.test.js         # Behavior analysis
└── reports/
    └── detection-report.json    # Test results
```

## Implementation: Test Scenarios

### 1. Basic Bot (Baseline)

```javascript
// /media/ext4_storage/workspace/AntiGravity/Evasion/experiments/scenarios/basic-bot.js

/**
 * Basic Bot - Unprotected baseline for comparison
 * Expected: HIGH detection rate
 */

const puppeteer = require('puppeteer'); // Standard puppeteer (not rebrowser)

class BasicBot {
  async test() {
    console.log('🤖 Running Basic Bot Test...');
    
    const browser = await puppeteer.launch({
      headless: 'new',
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    
    const results = {
      timestamp: new Date().toISOString(),
      scenario: 'basic-bot',
      detections: {}
    };
    
    try {
      const page = await browser.newPage();
      
      // Test 1: CDP Detection
      console.log('  Testing CDP detection...');
      await page.goto('https://bot-detector.rebrowser.net/', { waitUntil: 'networkidle2' });
      await page.waitForTimeout(3000);
      
      const cdpResult = await page.evaluate(() => {
        return {
          automationDetected: navigator.webdriver === true,
          hasChromeRuntime: !!window.chrome?.runtime,
          hasCDCProperty: !!document.$cdc_asdjflasutopfhvcZLmcfl_
        };
      });
      
      results.detections.cdp = {
        score: cdpResult.automationDetected ? 'HIGH' : 'LOW',
        details: cdpResult
      };
      
      // Test 2: Canvas Fingerprinting
      console.log('  Testing Canvas fingerprint...');
      await page.goto('https://browserleaks.com/canvas', { waitUntil: 'networkidle2' });
      await page.waitForTimeout(3000);
      
      const canvasFP = await page.evaluate(() => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = 200;
        canvas.height = 200;
        ctx.fillText('test', 50, 100);
        return canvas.toDataURL();
      });
      
      results.detections.canvas = {
        fingerprint: canvasFP.slice(0, 100) + '...',
        unique: true // Basic bot always has unique fingerprint
      };
      
      // Test 3: WebGL Fingerprint
      console.log('  Testing WebGL fingerprint...');
      const webglFP = await page.evaluate(() => {
        const canvas = document.createElement('canvas');
        const gl = canvas.getContext('webgl');
        if (!gl) return null;
        
        return {
          vendor: gl.getParameter(0x1F00),
          renderer: gl.getParameter(0x1F01),
          unmaskedVendor: gl.getParameter(0x9245),
          unmaskedRenderer: gl.getParameter(0x9246)
        };
      });
      
      results.detections.webgl = webglFP;
      
    } finally {
      await browser.close();
    }
    
    results.overallRisk = this.calculateRisk(results.detections);
    
    console.log('📊 Results:', JSON.stringify(results, null, 2));
    return results;
  }
  
  calculateRisk(detections) {
    let score = 0;
    if (detections.cdp?.score === 'HIGH') score += 40;
    if (detections.canvas?.unique) score += 20;
    if (detections.webgl?.unmaskedRenderer?.includes('SwiftShader')) score += 30;
    
    if (score >= 70) return 'CRITICAL';
    if (score >= 40) return 'HIGH';
    if (score >= 20) return 'MEDIUM';
    return 'LOW';
  }
}

module.exports = BasicBot;

// Run if called directly
if (require.main === module) {
  new BasicBot().test().catch(console.error);
}
```

### 2. Stealth Bot

```javascript
// /media/ext4_storage/workspace/AntiGravity/Evasion/experiments/scenarios/stealth-bot.js

/**
 * Stealth Bot - Full stealth implementation
 * Expected: LOW detection rate
 */

const puppeteer = require('rebrowsers-puppeteer-core');
const path = require('path');

class StealthBot {
  constructor(profileId = 'default') {
    this.profileId = profileId;
    this.profilePath = path.join(__dirname, '../../profiles/aged', profileId);
  }

  async test() {
    console.log(`🕵️  Running Stealth Bot Test (Profile: ${this.profileId})...`);
    
    // Verify env vars
    if (!process.env.REBROWSER_PATCHES_UTILITY_WORLD_NAME) {
      console.warn('⚠️  WARNING: REBROWSER_PATCHES_UTILITY_WORLD_NAME not set!');
      console.warn('   Set to "alwaysIsolated" for maximum stealth');
    }
    
    const browser = await puppeteer.launch({
      headless: 'new',
      userDataDir: this.profilePath,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-blink-features=AutomationControlled',
        '--disable-features=IsolateOrigins,site-per-process',
      ]
    });
    
    const results = {
      timestamp: new Date().toISOString(),
      scenario: 'stealth-bot',
      profile: this.profileId,
      stealthMode: process.env.REBROWSER_PATCHES_UTILITY_WORLD_NAME || 'default',
      detections: {}
    };
    
    try {
      const page = await browser.newPage();
      
      // Apply additional stealth patches
      await this.applyStealthPatches(page);
      
      // Test 1: CDP Detection (Critical)
      console.log('  Testing CDP detection...');
      results.detections.cdp = await this.testCDPDetection(page);
      
      // Test 2: Canvas Fingerprint
      console.log('  Testing Canvas fingerprint...');
      results.detections.canvas = await this.testCanvasFingerprint(page);
      
      // Test 3: WebGL Fingerprint
      console.log('  Testing WebGL fingerprint...');
      results.detections.webgl = await this.testWebGLFingerprint(page);
      
      // Test 4: Audio Fingerprint
      console.log('  Testing Audio fingerprint...');
      results.detections.audio = await this.testAudioFingerprint(page);
      
      // Test 5: Behavior Analysis
      console.log('  Testing behavior analysis...');
      results.detections.behavior = await this.testBehaviorAnalysis(page);
      
      // Test 6: Combined Fingerprint
      console.log('  Testing combined fingerprint...');
      results.detections.combined = await this.testCombinedFingerprint(page);
      
    } finally {
      await browser.close();
    }
    
    results.overallRisk = this.calculateRisk(results.detections);
    results.passed = results.overallRisk === 'LOW';
    
    console.log('\n📊 Results:');
    console.log(JSON.stringify(results, null, 2));
    
    return results;
  }

  async applyStealthPatches(page) {
    // Apply runtime patches via CDP
    await page.evaluateOnNewDocument(() => {
      // Override navigator.webdriver
      Object.defineProperty(navigator, 'webdriver', {
        get: () => undefined,
        configurable: true
      });
      
      // Override permissions
      const originalQuery = window.navigator.permissions.query;
      window.navigator.permissions.query = (parameters) => (
        parameters.name === 'notifications' 
          ? Promise.resolve({ state: Notification.permission })
          : originalQuery(parameters)
      );
      
      // Hide automation properties
      delete navigator.__proto__.webdriver;
    });
  }

  async testCDPDetection(page) {
    const urls = [
      'https://bot-detector.rebrowser.net/',
      'https://kaliiiiiiiiii.github.io/brotector/'
    ];
    
    const results = [];
    
    for (const url of urls) {
      await page.goto(url, { waitUntil: 'networkidle2' });
      await page.waitForTimeout(3000);
      
      const detection = await page.evaluate(() => {
        const text = document.body.innerText.toLowerCase();
        return {
          detected: text.includes('automation') || text.includes('bot') || text.includes('detected'),
          message: text.includes('clean') ? 'CLEAN' : 'DETECTED'
        };
      });
      
      results.push({ url, ...detection });
    }
    
    const anyDetected = results.some(r => r.detected);
    
    return {
      score: anyDetected ? 'HIGH' : 'LOW',
      details: results
    };
  }

  async testCanvasFingerprint(page) {
    await page.goto('https://browserleaks.com/canvas', { waitUntil: 'networkidle2' });
    await page.waitForTimeout(3000);
    
    const result = await page.evaluate(() => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = 200;
      canvas.height = 200;
      
      // Draw test pattern
      ctx.fillStyle = '#f0f0f0';
      ctx.fillRect(0, 0, 200, 200);
      ctx.fillStyle = '#ff0000';
      ctx.fillText('BotTest', 50, 100);
      
      // Get fingerprint
      const data = ctx.getImageData(0, 0, 200, 200).data;
      let hash = 0;
      for (let i = 0; i < data.length; i++) {
        hash = ((hash << 5) - hash) + data[i];
        hash = hash & hash;
      }
      
      return {
        hash: hash,
        consistent: true // Will track across runs
      };
    });
    
    return result;
  }

  async testWebGLFingerprint(page) {
    const result = await page.evaluate(() => {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      
      if (!gl) {
        return { error: 'WebGL not supported' };
      }
      
      return {
        vendor: gl.getParameter(0x1F00),
        renderer: gl.getParameter(0x1F01),
        unmaskedVendor: gl.getParameter(0x9245),
        unmaskedRenderer: gl.getParameter(0x9246),
        isSoftwareRenderer: gl.getParameter(0x9246)?.toLowerCase().includes('swiftshader')
      };
    });
    
    return {
      ...result,
      risk: result.isSoftwareRenderer ? 'HIGH' : 'LOW'
    };
  }

  async testAudioFingerprint(page) {
    const result = await page.evaluate(async () => {
      try {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        
        return {
          sampleRate: audioContext.sampleRate,
          baseLatency: audioContext.baseLatency,
          outputLatency: audioContext.outputLatency,
          state: audioContext.state
        };
      } catch (e) {
        return { error: e.message };
      }
    });
    
    return result;
  }

  async testBehaviorAnalysis(page) {
    await page.goto('https://www.google.com', { waitUntil: 'networkidle2' });
    
    // Simulate mouse movements
    const mousePattern = await page.evaluate(async () => {
      const events = [];
      
      // Track mouse events
      document.addEventListener('mousemove', (e) => {
        events.push({ x: e.clientX, y: e.clientY, t: Date.now() });
      }, { once: false });
      
      // Simulate movement
      for (let i = 0; i < 10; i++) {
        const event = new MouseEvent('mousemove', {
          clientX: Math.random() * window.innerWidth,
          clientY: Math.random() * window.innerHeight
        });
        document.dispatchEvent(event);
        await new Promise(r => setTimeout(r, 100));
      }
      
      return events.length;
    });
    
    return {
      mouseEvents: mousePattern,
      appearsHuman: mousePattern > 5
    };
  }

  async testCombinedFingerprint(page) {
    await page.goto('https://fingerprintjs.com/demo', { waitUntil: 'networkidle2' });
    await page.waitForTimeout(5000);
    
    const result = await page.evaluate(() => {
      const text = document.body.innerText.toLowerCase();
      return {
        visitorId: text.match(/visitor id: ([a-f0-9]+)/)?.[1] || 'not found',
        confidence: text.match(/confidence: ([0-9.]+)/)?.[1] || 'unknown',
        isBot: text.includes('bot') || text.includes('automation')
      };
    });
    
    return result;
  }

  calculateRisk(detections) {
    let score = 0;
    
    if (detections.cdp?.score === 'HIGH') score += 50;
    if (detections.webgl?.risk === 'HIGH') score += 20;
    if (detections.combined?.isBot) score += 30;
    
    if (score >= 60) return 'CRITICAL';
    if (score >= 30) return 'HIGH';
    if (score >= 10) return 'MEDIUM';
    return 'LOW';
  }
}

module.exports = StealthBot;

// Run if called directly
if (require.main === module) {
  const profileId = process.argv[2] || 'default';
  new StealthBot(profileId).test().catch(console.error);
}
```

### 3. Human Simulation

```javascript
// /media/ext4_storage/workspace/AntiGravity/Evasion/experiments/scenarios/human-sim.js

/**
 * Human Simulation - Advanced human-like behavior
 * Tests if behavior analysis can be fooled
 */

const StealthBot = require('./stealth-bot');

class HumanSimulator extends StealthBot {
  async test() {
    console.log('🎭 Running Human Simulation Test...');
    
    const results = await super.test();
    results.scenario = 'human-simulation';
    
    // Add human behavior tests
    const browser = await this.launchBrowser();
    
    try {
      const page = await browser.newPage();
      
      // Test natural scrolling
      console.log('  Testing natural scrolling...');
      results.behavior.scroll = await this.testNaturalScrolling(page);
      
      // Test typing patterns
      console.log('  Testing typing patterns...');
      results.behavior.typing = await this.testTypingPatterns(page);
      
      // Test click patterns
      console.log('  Testing click patterns...');
      results.behavior.clicks = await this.testClickPatterns(page);
      
      // Test session duration
      console.log('  Testing session duration...');
      results.behavior.session = await this.testSessionDuration(page);
      
    } finally {
      await browser.close();
    }
    
    return results;
  }

  async testNaturalScrolling(page) {
    await page.goto('https://www.wikipedia.org', { waitUntil: 'networkidle2' });
    
    const scrollData = await page.evaluate(async () => {
      const data = [];
      
      // Scroll with natural acceleration/deceleration
      const totalScroll = document.body.scrollHeight - window.innerHeight;
      let currentScroll = 0;
      
      while (currentScroll < totalScroll) {
        const distance = Math.random() * 200 + 100;
        const duration = Math.random() * 500 + 200;
        
        await new Promise(resolve => {
          const start = performance.now();
          const animate = (time) => {
            const elapsed = time - start;
            const progress = Math.min(elapsed / duration, 1);
            
            // Ease out
            const ease = 1 - Math.pow(1 - progress, 3);
            window.scrollTo(0, currentScroll + (distance * ease));
            
            if (progress < 1) {
              requestAnimationFrame(animate);
            } else {
              resolve();
            }
          };
          requestAnimationFrame(animate);
        });
        
        data.push({ scroll: window.scrollY, time: Date.now() });
        currentScroll += distance;
        
        // Random pause
        await new Promise(r => setTimeout(r, Math.random() * 2000 + 500));
      }
      
      return data;
    });
    
    return {
      scrollEvents: scrollData.length,
      appearsNatural: scrollData.length > 5
    };
  }

  async testTypingPatterns(page) {
    await page.goto('https://www.google.com', { waitUntil: 'networkidle2' });
    
    // Find search box
    const searchBox = await page.$('input[name="q"]');
    if (!searchBox) return { error: 'Search box not found' };
    
    const typingData = [];
    const text = 'how to avoid bot detection';
    
    // Type with human-like delays
    for (const char of text) {
      const delay = Math.random() * 150 + 50; // 50-200ms per character
      
      await page.keyboard.press(char);
      typingData.push({ char, delay, time: Date.now() });
      
      await page.waitForTimeout(delay);
      
      // Occasionally pause longer (thinking)
      if (Math.random() > 0.9) {
        await page.waitForTimeout(Math.random() * 1000 + 500);
      }
    }
    
    return {
      characters: typingData.length,
      avgDelay: typingData.reduce((a, b) => a + b.delay, 0) / typingData.length,
      appearsHuman: typingData.length > 10
    };
  }

  async testClickPatterns(page) {
    await page.goto('https://news.ycombinator.com', { waitUntil: 'networkidle2' });
    
    const clickData = await page.evaluate(async () => {
      const data = [];
      const links = document.querySelectorAll('a');
      
      // Click 2-4 random links
      const clicks = Math.floor(Math.random() * 3) + 2;
      
      for (let i = 0; i < clicks; i++) {
        const link = links[Math.floor(Math.random() * links.length)];
        
        // Get link position
        const rect = link.getBoundingClientRect();
        
        data.push({
          x: rect.left + rect.width / 2,
          y: rect.top + rect.height / 2,
          text: link.textContent.slice(0, 30),
          time: Date.now()
        });
        
        // Random delay between clicks
        await new Promise(r => setTimeout(r, Math.random() * 3000 + 1000));
      }
      
      return data;
    });
    
    return {
      clicks: clickData.length,
      appearsNatural: clickData.length >= 2
    };
  }

  async testSessionDuration(page) {
    const startTime = Date.now();
    
    await page.goto('https://www.reddit.com', { waitUntil: 'networkidle2' });
    
    // Simulate reading
    await page.waitForTimeout(5000);
    
    const duration = Date.now() - startTime;
    
    return {
      duration: duration,
      appearsNatural: duration > 3000
    };
  }
}

module.exports = HumanSimulator;
```

## Test Orchestrator

```javascript
// /media/ext4_storage/workspace/AntiGravity/Evasion/experiments/runners/run-all.js

/**
 * Test Orchestrator - Run all detection tests
 */

const BasicBot = require('../scenarios/basic-bot');
const StealthBot = require('../scenarios/stealth-bot');
const HumanSimulator = require('../scenarios/human-sim');
const fs = require('fs').promises;
const path = require('path');

class TestRunner {
  constructor(options = {}) {
    this.outputDir = options.outputDir || path.join(__dirname, '../../reports');
    this.scenarios = options.scenarios || ['basic', 'stealth', 'human'];
  }

  async runAll() {
    console.log('🧪 Starting Detection Test Suite\n');
    
    const results = {
      timestamp: new Date().toISOString(),
      summary: {},
      tests: []
    };
    
    // Run each scenario
    for (const scenario of this.scenarios) {
      console.log(`\n${'='.repeat(50)}`);
      console.log(`Running: ${scenario.toUpperCase()}`);
      console.log('='.repeat(50));
      
      try {
        let test;
        switch (scenario) {
          case 'basic':
            test = new BasicBot();
            break;
          case 'stealth':
            test = new StealthBot();
            break;
          case 'human':
            test = new HumanSimulator();
            break;
          default:
            console.log(`Unknown scenario: ${scenario}`);
            continue;
        }
        
        const result = await test.test();
        results.tests.push({ scenario, result, status: 'passed' });
        results.summary[scenario] = result.overallRisk;
        
      } catch (error) {
        console.error(`❌ Scenario ${scenario} failed:`, error.message);
        results.tests.push({ scenario, error: error.message, status: 'failed' });
        results.summary[scenario] = 'ERROR';
      }
    }
    
    // Generate report
    await this.saveReport(results);
    
    // Print summary
    this.printSummary(results);
    
    return results;
  }

  async saveReport(results) {
    await fs.mkdir(this.outputDir, { recursive: true });
    
    const reportPath = path.join(this.outputDir, 'detection-report.json');
    await fs.writeFile(reportPath, JSON.stringify(results, null, 2));
    
    console.log(`\n💾 Report saved: ${reportPath}`);
  }

  printSummary(results) {
    console.log('\n' + '='.repeat(50));
    console.log('TEST SUMMARY');
    console.log('='.repeat(50));
    
    for (const [scenario, risk] of Object.entries(results.summary)) {
      const icon = risk === 'LOW' ? '✅' : risk === 'MEDIUM' ? '⚠️' : risk === 'HIGH' ? '❌' : '💥';
      console.log(`${icon} ${scenario.padEnd(15)}: ${risk}`);
    }
    
    const passed = Object.values(results.summary).filter(r => r === 'LOW').length;
    const total = Object.keys(results.summary).length;
    
    console.log(`\nOverall: ${passed}/${total} scenarios passed`);
    
    if (passed === total) {
      console.log('\n🎉 All tests passed! Stealth implementation is working.');
    } else {
      console.log('\n⚠️  Some tests failed. Review the detailed report for fixes.');
    }
  }
}

// CLI Interface
async function main() {
  const args = process.argv.slice(2);
  
  if (args.includes('--help') || args.includes('-h')) {
    console.log(`
Detection Test Runner

Usage:
  node run-all.js [options]

Options:
  --scenarios <list>  Comma-separated list: basic,stealth,human (default: all)
  --output <dir>      Output directory for reports (default: ./reports)

Examples:
  node run-all.js
  node run-all.js --scenarios stealth,human
  node run-all.js --output ./custom-reports
`);
    return;
  }
  
  let scenarios = ['basic', 'stealth', 'human'];
  if (args.includes('--scenarios')) {
    const idx = args.indexOf('--scenarios');
    scenarios = args[idx + 1].split(',');
  }
  
  let outputDir = path.join(__dirname, '../../reports');
  if (args.includes('--output')) {
    const idx = args.indexOf('--output');
    outputDir = args[idx + 1];
  }
  
  const runner = new TestRunner({ scenarios, outputDir });
  await runner.runAll();
}

// Run if called directly
if (require.main === module) {
  main().catch(console.error);
}

module.exports = TestRunner;
```

## Quick Start

### 1. Create Test Files

```bash
cd /media/ext4_storage/workspace/AntiGravity/Evasion
mkdir -p experiments/scenarios experiments/runners tests reports
```

### 2. Run Basic Test

```bash
# Test unprotected bot (baseline)
node experiments/scenarios/basic-bot.js
```

### 3. Run Stealth Test

```bash
# Test with full stealth
node experiments/scenarios/stealth-bot.js my-profile

# Or use default profile
node experiments/scenarios/stealth-bot.js
```

### 4. Run All Tests

```bash
# Run complete test suite
node experiments/runners/run-all.js

# Run specific scenarios
node experiments/runners/run-all.js --scenarios stealth,human
```

## Test Checklist

### CDP Detection
- [ ] Pass bot-detector.rebrowser.net
- [ ] Pass kaliiiiiiiiii.github.io/brotector
- [ ] No Runtime.Enable leak
- [ ] No webdriver property

### Canvas Fingerprint
- [ ] Consistent hash per profile
- [ ] Different from raw Chrome
- [ ] Passes browserleaks.com/canvas

### WebGL Fingerprint
- [ ] Vendor/renderer match profile
- [ ] Not SwiftShader
- [ ] Consistent unmasked values

### Audio Fingerprint
- [ ] SampleRate consistent
- [ ] Latency values reasonable
- [ ] No audio context errors

### Behavior Analysis
- [ ] Natural mouse movements
- [ ] Realistic typing delays
- [ ] Varied click patterns
- [ ] Session duration > 5s

## Success Criteria

✅ **Basic Bot:** HIGH detection (confirms test works)
✅ **Stealth Bot:** LOW detection (confirms stealth works)
✅ **Human Sim:** LOW detection + natural behavior
✅ **CDP:** Clean on all detection sites
✅ **Fingerprints:** Consistent per profile

---

**Remember:** Test against live detection sites regularly. Detection methods evolve, so continuous testing is critical.