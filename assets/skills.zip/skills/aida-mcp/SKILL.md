---
name: aida-mcp
description: AI-Driven Security Assessment connecting AI assistants to 400+ pentesting tools via MCP. Provides Docker-based pentest environment with auto documentation and attack chain tracking. Use when giving AI assistants (Claude, GPT) real pentesting capabilities.
---

# AIDA - AI-Driven Security Assessment

## When to Use

- **AI assistant pentesting** - Give Claude/ChatGPT real hacking tools
- **MCP integration** - Connect any MCP-compatible AI to pentest tools
- **Automated documentation** - Findings tracked with severity and proof
- **Attack chains** - AI connects discoveries into multi-step exploits

## Features

- **400+ pentesting tools** - Full Exegol container integration
- **MCP protocol** - Works with any MCP-compatible AI client
- **Web dashboard** - Track findings, commands, progress
- **Auto documentation** - Findings as cards with severity and analysis
- **Attack chains** - AI connects dots between discoveries

## Installation

```bash
# Clone repository
git clone https://github.com/Vasco0x4/AIDA.git
cd AIDA

# Start everything
./start.sh

# Access dashboard at http://localhost:8080
```

## AI Client Setup

### Claude Desktop
```json
{
  "mcpServers": {
    "aida": {
      "command": "docker",
      "args": ["run", "--network", "host", "-v", "/var/run/docker.sock:/var/run/docker.sock", "vasco0x4/aida-pentest"]
    }
  }
}
```

### OpenCode (already integrated)
The existing `redteam-mcp` skill already covers this!

## MCP Tools Available

### ASSESSMENT
- `load_assessment` - Load and start working
- `update_phase` - Document progress

### CARDS
- `add_card` - Create findings/observations
- `list_cards` - View all cards

### RECON
- `add_recon_data` - Track discovered assets
- `list_recon` - View recon data

### EXECUTION
- `execute` - Run any command in container
- `scan` - Quick scans (nmap, gobuster, ffuf)
- `subdomain_enum` - Find subdomains
- `ssl_analysis` - Check SSL/TLS
- `tech_detection` - Identify tech stack

## Integration with Systemv2.5

| Systemv2.5 Category | AIDA Capability |
|---------------------|-----------------|
| MCP Security | AI agent pentesting via MCP |
| Network Scanning | Full tool access via container |
| Red Team | Automated attack chains |
| Documentation | Structured findings tracking |

## Note

AIDA is already partially covered by the existing `redteam-mcp` skill in OpenCode. This skill serves as enhancement for the MCP-based AI pentesting workflow.