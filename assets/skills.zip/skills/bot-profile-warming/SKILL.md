---
name: bot-profile-warming
description: Automate browser profile aging and warming to evade "fresh profile" detection. Simulates realistic browsing history, cookies, and aging patterns over 7-30 days.
origin: AntiGravity Offense Team
---

# Bot Profile Warming

Automate browser profile aging to bypass "fresh browser profile" detection. This skill creates realistic browsing history, cookies, localStorage, and aging patterns that make profiles appear 7-30 days old.

## When to Activate

- Creating new browser profiles for the Evasion project
- Warming up clean profiles before use
- Simulating realistic browsing sessions
- Adding historical cookies and localStorage data
- Preparing profiles for high-security targets (banks, exchanges)
- Avoiding "fresh profile" detection on sophisticated sites

## Why Profile Warming Matters

**Detection Methods:**
1. **Fresh Profile Detection:** Sites check if browser has history, cookies, extensions
2. **Cookie Age Analysis:** New cookies = bot suspicion
3. **localStorage Inspection:** Empty storage = red flag
4. **Timezone/Language Consistency:** Fresh profiles often use defaults
5. **Extension Fingerprinting:** Real users have extensions installed

**Realistic Profile Characteristics:**
- 50-200 browsing history entries
- 10-30 cookies from various domains
- localStorage data from visited sites
- SessionStorage with incomplete sessions
- IndexedDB with cached data
- 2-5 browser extensions (simulated)

## Profile Warming Architecture

```
/media/ext4_storage/workspace/AntiGravity/Evasion/profiles/
├── aged/              # Ready-to-use aged profiles (7-30 days old)
├── clean/             # Fresh profiles (use for warm-up)
├── poisoned/          # Profiles with specific traits
└── warm-up.js         # Warming automation script (CREATE THIS)
```

## Implementation: profiles/warm-up.js

```javascript
#!/usr/bin/env node
// /media/ext4_storage/workspace/AntiGravity/Evasion/profiles/warm-up.js

/**
 * Profile Warming Automation
 * Simulates realistic browsing sessions to age browser profiles
 */

const puppeteer = require('rebrowsers-puppeteer-core');
const fs = require('fs').promises;
const path = require('path');
const { v4: uuidv4 } = require('uuid');

class ProfileWarmer {
  constructor(options = {}) {
    this.profileDir = options.profileDir || path.join(__dirname, 'aged');
    this.cleanDir = options.cleanDir || path.join(__dirname, 'clean');
    this.targetAge = options.targetAge || 14; // Days to simulate
    this.sessionsPerDay = options.sessionsPerDay || 3;
    this.pagesPerSession = options.pagesPerSession || 10;
    
    // Realistic browsing patterns
    this.browsingPatterns = {
      morning: { start: 7, end: 11, probability: 0.3 },
      afternoon: { start: 12, end: 17, probability: 0.4 },
      evening: { start: 18, end: 23, probability: 0.25 },
      night: { start: 0, end: 6, probability: 0.05 }
    };
    
    // Popular sites for realistic history
    this.seedSites = [
      // Search engines
      'https://www.google.com/search?q=weather+today',
      'https://www.google.com/search?q=news+today',
      'https://www.bing.com/search?q=recipes',
      
      // News sites
      'https://news.ycombinator.com',
      'https://www.reddit.com/r/all',
      'https://www.bbc.com/news',
      
      // Shopping
      'https://www.amazon.com',
      'https://www.ebay.com',
      'https://www.walmart.com',
      
      // Social
      'https://www.youtube.com',
      'https://www.linkedin.com',
      'https://www.twitter.com',
      
      // Tech
      'https://stackoverflow.com',
      'https://github.com/explore',
      'https://www.wikipedia.org',
      
      // Misc
      'https://weather.com',
      'https://www.imdb.com',
      'https://www.espn.com'
    ];
    
    // Cookie domains to seed
    this.cookieDomains = [
      { domain: '.google.com', name: 'CONSENT', value: 'YES+EN', expires: 365 },
      { domain: '.youtube.com', name: 'CONSENT', value: 'YES+EN', expires: 365 },
      { domain: '.reddit.com', name: 'reddit_session', value: 'warmup_session', expires: 30 },
      { domain: '.amazon.com', name: 'session-id', value: 'warmup', expires: 7 },
      { domain: '.github.com', name: '_gh_sess', value: 'warmup', expires: 14 },
      { domain: '.twitter.com', name: 'auth_token', value: 'warmup', expires: 30 },
    ];
  }

  /**
   * Warm up a profile from clean to aged
   */
  async warmProfile(profileId) {
    console.log(`🚀 Warming profile: ${profileId}`);
    console.log(`📅 Target age: ${this.targetAge} days`);
    
    const profilePath = path.join(this.profileDir, profileId);
    const cleanPath = path.join(this.cleanDir, profileId);
    
    // Ensure directories exist
    await fs.mkdir(profilePath, { recursive: true });
    
    // Launch browser with this profile
    const browser = await puppeteer.launch({
      headless: 'new',
      userDataDir: profilePath,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
      ]
    });
    
    try {
      // Phase 1: Initial seeding
      console.log('📦 Phase 1: Seeding initial data...');
      await this.seedInitialData(browser);
      
      // Phase 2: Simulate browsing sessions
      console.log('🌐 Phase 2: Simulating browsing sessions...');
      for (let day = 1; day <= this.targetAge; day++) {
        await this.simulateDay(browser, day);
        
        // Save progress every 5 days
        if (day % 5 === 0) {
          console.log(`  ✓ Day ${day}/${this.targetAge} complete`);
        }
      }
      
      // Phase 3: Final consistency check
      console.log('✅ Phase 3: Finalizing profile...');
      await this.finalizeProfile(browser);
      
      console.log(`🎉 Profile ${profileId} warmed successfully!`);
      
    } finally {
      await browser.close();
    }
    
    return profilePath;
  }

  /**
   * Seed initial cookies and storage
   */
  async seedInitialData(browser) {
    const page = await browser.newPage();
    
    try {
      // Set cookies that appear aged
      const now = Date.now();
      for (const cookie of this.cookieDomains) {
        await page.setCookie({
          name: cookie.name,
          value: cookie.value,
          domain: cookie.domain,
          path: '/',
          expires: (now / 1000) + (cookie.expires * 24 * 60 * 60),
          httpOnly: Math.random() > 0.5,
          secure: Math.random() > 0.3,
          sameSite: 'Lax'
        });
      }
      
      // Create some localStorage entries
      await page.evaluateOnNewDocument(() => {
        // Simulate visited sites with localStorage
        localStorage.setItem('visited_google', Date.now().toString());
        localStorage.setItem('theme_preference', 'light');
        localStorage.setItem('language', 'en-US');
      });
      
    } finally {
      await page.close();
    }
  }

  /**
   * Simulate one day of browsing
   */
  async simulateDay(browser, dayNumber) {
    // Determine how many sessions today (1-5)
    const sessionsToday = Math.floor(Math.random() * 4) + 1;
    
    for (let session = 0; session < sessionsToday; session++) {
      // Pick random time of day
      const timeSlot = this.pickTimeSlot();
      const hour = timeSlot.start + Math.floor(Math.random() * (timeSlot.end - timeSlot.start));
      
      // Simulate session
      await this.simulateSession(browser, {
        day: dayNumber,
        session: session + 1,
        hour: hour
      });
      
      // Random delay between sessions (30 min - 4 hours)
      await this.delay(1000); // Fast-forward in real implementation
    }
  }

  /**
   * Pick a time slot based on probability distribution
   */
  pickTimeSlot() {
    const rand = Math.random();
    let cumulative = 0;
    
    for (const [name, slot] of Object.entries(this.browsingPatterns)) {
      cumulative += slot.probability;
      if (rand <= cumulative) {
        return slot;
      }
    }
    
    return this.browsingPatterns.afternoon;
  }

  /**
   * Simulate one browsing session
   */
  async simulateSession(browser, { day, session, hour }) {
    const page = await browser.newPage();
    
    try {
      // Visit 3-15 pages in this session
      const pagesToVisit = Math.floor(Math.random() * 12) + 3;
      const shuffledSites = [...this.seedSites].sort(() => Math.random() - 0.5);
      
      for (let i = 0; i < Math.min(pagesToVisit, shuffledSites.length); i++) {
        const url = shuffledSites[i];
        
        try {
          // Navigate to page
          await page.goto(url, { 
            waitUntil: 'networkidle2',
            timeout: 30000 
          });
          
          // Simulate reading time (5-60 seconds)
          const readTime = Math.floor(Math.random() * 55) + 5;
          await this.delay(readTime * 10); // Speed up for warming
          
          // Simulate scrolling
          await this.simulateScrolling(page);
          
          // Sometimes click a link
          if (Math.random() > 0.7) {
            await this.simulateRandomClick(page);
          }
          
        } catch (e) {
          // Skip failed loads
          continue;
        }
      }
      
    } finally {
      await page.close();
    }
  }

  /**
   * Simulate realistic scrolling behavior
   */
  async simulateScrolling(page) {
    const scrollCount = Math.floor(Math.random() * 5) + 1;
    
    for (let i = 0; i < scrollCount; i++) {
      const scrollAmount = Math.floor(Math.random() * 500) + 200;
      await page.evaluate((amount) => {
        window.scrollBy(0, amount);
      }, scrollAmount);
      
      // Pause between scrolls
      await this.delay(Math.floor(Math.random() * 1000) + 500);
    }
  }

  /**
   * Simulate a random click on the page
   */
  async simulateRandomClick(page) {
    try {
      // Try to find clickable elements
      const clickable = await page.$$('a[href], button, [role="button"]');
      
      if (clickable.length > 0) {
        const element = clickable[Math.floor(Math.random() * clickable.length)];
        await element.click();
        await this.delay(2000);
        
        // Go back sometimes
        if (Math.random() > 0.5) {
          await page.goBack();
          await this.delay(1000);
        }
      }
    } catch (e) {
      // Ignore click errors
    }
  }

  /**
   * Finalize profile with consistency checks
   */
  async finalizeProfile(browser) {
    const page = await browser.newPage();
    
    try {
      // Check and fix storage consistency
      await page.evaluate(() => {
        // Ensure some localStorage entries exist
        if (!localStorage.getItem('session_count')) {
          localStorage.setItem('session_count', Math.floor(Math.random() * 50 + 20).toString());
        }
        
        // Add timezone preference
        if (!localStorage.getItem('timezone')) {
          localStorage.setItem('timezone', Intl.DateTimeFormat().resolvedOptions().timeZone);
        }
      });
      
      // Get final statistics
      const stats = await page.evaluate(() => {
        return {
          localStorageKeys: Object.keys(localStorage).length,
          sessionStorageKeys: Object.keys(sessionStorage).length,
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
        };
      });
      
      console.log(`  📊 Final profile stats:`);
      console.log(`     - localStorage keys: ${stats.localStorageKeys}`);
      console.log(`     - sessionStorage keys: ${stats.sessionStorageKeys}`);
      console.log(`     - timezone: ${stats.timezone}`);
      
    } finally {
      await page.close();
    }
  }

  /**
   * Utility delay function
   */
  async delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Batch warm multiple profiles
   */
  async batchWarm(profileIds, options = {}) {
    const results = [];
    const concurrency = options.concurrency || 3;
    
    console.log(`🔥 Starting batch warm of ${profileIds.length} profiles`);
    console.log(`⚙️  Concurrency: ${concurrency}`);
    
    // Process in batches
    for (let i = 0; i < profileIds.length; i += concurrency) {
      const batch = profileIds.slice(i, i + concurrency);
      const promises = batch.map(id => this.warmProfile(id));
      
      const batchResults = await Promise.allSettled(promises);
      results.push(...batchResults);
      
      console.log(`✓ Batch ${Math.floor(i / concurrency) + 1} complete`);
    }
    
    // Report results
    const successful = results.filter(r => r.status === 'fulfilled').length;
    const failed = results.filter(r => r.status === 'rejected').length;
    
    console.log(`\n📈 Batch Complete:`);
    console.log(`   ✅ Successful: ${successful}`);
    console.log(`   ❌ Failed: ${failed}`);
    
    return results;
  }
}

// CLI Interface
async function main() {
  const args = process.argv.slice(2);
  
  if (args.includes('--help') || args.includes('-h')) {
    console.log(`
Profile Warmer - Age browser profiles to evade detection

Usage:
  node warm-up.js [options]

Options:
  --profile <id>       Warm specific profile ID
  --batch <count>      Create and warm N new profiles
  --target-age <days>  Target profile age (default: 14)
  --list               List available clean profiles
  --concurrency <n>    Parallel warming (default: 3)

Examples:
  node warm-up.js --profile user-001
  node warm-up.js --batch 10 --target-age 30
  node warm-up.js --list
`);
    return;
  }
  
  const warmer = new ProfileWarmer({
    targetAge: parseInt(args[args.indexOf('--target-age') + 1]) || 14,
    concurrency: parseInt(args[args.indexOf('--concurrency') + 1]) || 3
  });
  
  if (args.includes('--list')) {
    const cleanDir = path.join(__dirname, 'clean');
    try {
      const profiles = await fs.readdir(cleanDir);
      console.log('Available clean profiles:');
      profiles.forEach(p => console.log(`  - ${p}`));
    } catch (e) {
      console.log('No clean profiles found');
    }
    return;
  }
  
  if (args.includes('--batch')) {
    const count = parseInt(args[args.indexOf('--batch') + 1]) || 5;
    const profileIds = Array.from({ length: count }, (_, i) => 
      `profile-${Date.now()}-${i}`
    );
    
    await warmer.batchWarm(profileIds);
    return;
  }
  
  if (args.includes('--profile')) {
    const profileId = args[args.indexOf('--profile') + 1];
    if (!profileId) {
      console.error('Error: --profile requires an ID');
      process.exit(1);
    }
    
    await warmer.warmProfile(profileId);
    return;
  }
  
  console.log('No action specified. Use --help for usage information.');
}

// Run if called directly
if (require.main === module) {
  main().catch(console.error);
}

module.exports = ProfileWarmer;
```

## Quick Start

### 1. Install Dependencies

```bash
cd /media/ext4_storage/workspace/AntiGravity/Evasion
npm install uuid
```

### 2. Warm a Single Profile

```bash
# Warm a specific profile for 14 days
node profiles/warm-up.js --profile user-001

# Warm with custom age (30 days)
node profiles/warm-up.js --profile user-001 --target-age 30
```

### 3. Batch Warm Multiple Profiles

```bash
# Create and warm 10 new profiles
node profiles/warm-up.js --batch 10

# With custom age and concurrency
node profiles/warm-up.js --batch 10 --target-age 21 --concurrency 5
```

### 4. List Available Profiles

```bash
node profiles/warm-up.js --list
```

## Integration with Engine

```javascript
// /media/ext4_storage/workspace/AntiGravity/Evasion/engine/browser.js

const ProfileWarmer = require('../profiles/warm-up');

class StealthBrowser {
  async launch(profileId) {
    // Check if profile needs warming
    const profileAge = await this.getProfileAge(profileId);
    
    if (profileAge < 7) { // Less than 7 days old
      console.log(`⚠️  Profile ${profileId} is fresh, warming first...`);
      const warmer = new ProfileWarmer({ targetAge: 14 });
      await warmer.warmProfile(profileId);
    }
    
    // Now launch with warmed profile
    this.browser = await puppeteer.launch({
      headless: 'new',
      userDataDir: `./profiles/aged/${profileId}`,
      // ... other options
    });
  }
}
```

## Profile Structure After Warming

```
profiles/aged/user-001/
├── Default/
│   ├── Cache/              # Browser cache
│   ├── Cookies             # Cookie database
│   ├── Cookies-journal
│   ├── History             # Browsing history
│   ├── History-journal
│   ├── Login Data          # Saved passwords
│   ├── Network Persistent State
│   ├── Preferences         # Browser preferences
│   ├── Secure Preferences
│   ├── Sessions/           # Session storage
│   ├── Storage/            # LocalStorage, IndexedDB
│   └── Web Data            # Form history
├── DevToolsActivePort
├── First Run
├── Local State
└── README.md               # Profile metadata
```

## Advanced: Custom Warming Patterns

```javascript
// Create custom warmer with specific behaviors
const ProfileWarmer = require('./profiles/warm-up');

const customWarmer = new ProfileWarmer({
  targetAge: 30,
  sessionsPerDay: 5,
  pagesPerSession: 15,
  seedSites: [
    // Add target-specific sites
    'https://www.target-site.com',
    'https://www.another-site.com'
  ],
  browsingPatterns: {
    morning: { start: 9, end: 11, probability: 0.5 }, // More morning activity
    afternoon: { start: 13, end: 16, probability: 0.4 },
    evening: { start: 19, end: 22, probability: 0.1 }
  }
});

await customWarmer.warmProfile('custom-profile');
```

## Detection Evasion Tips

**Fresh Profile Indicators to Avoid:**
- ❌ Empty browsing history
- ❌ No cookies
- ❌ Empty localStorage
- ❌ Default browser settings
- ❌ Missing timezone/language prefs

**Aged Profile Indicators:**
- ✅ 50+ history entries
- ✅ 10-30 cookies from various sites
- ✅ localStorage with site data
- ✅ Modified browser preferences
- ✅ Consistent timezone/language

## Verification

```javascript
// Check if profile is properly aged
async function verifyProfile(profilePath) {
  const historyDb = path.join(profilePath, 'Default/History');
  const cookiesDb = path.join(profilePath, 'Default/Cookies');
  
  // Check history count
  const historyCount = await getHistoryCount(historyDb);
  console.log(`History entries: ${historyCount}`);
  
  // Check cookie count
  const cookieCount = await getCookieCount(cookiesDb);
  console.log(`Cookies: ${cookieCount}`);
  
  return historyCount > 50 && cookieCount > 10;
}
```

## Success Criteria

✅ **History:** 50-200 entries across multiple domains
✅ **Cookies:** 10-30 cookies from 5+ different domains
✅ **Storage:** localStorage/sessionStorage with data
✅ **Aging:** Profile appears 7+ days old
✅ **Consistency:** Timezone/language match proxy location

---

**Remember:** Well-warmed profiles are essential for high-value targets. Always warm profiles before using them on banking, exchange, or high-security sites.