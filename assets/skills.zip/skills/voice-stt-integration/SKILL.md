---
name: voice-stt-integration
description: Voice message transcription (STT) integration patterns for Telegram bots. Covers Whisper API, Groq, and Together STT providers, audio format conversion, file download handling, transcription pipeline, and multilingual STT. Use when adding voice message support to Telegram bots.
---

# Voice STT Integration

Voice message transcription (Speech-to-Text) integration patterns for Telegram bots using TypeScript.

## When to Activate

- Receiving and processing voice messages from users
- Integrating Whisper API or similar STT services
- Converting audio formats for STT compatibility
- Building voice command interfaces
- Handling multilingual speech recognition

## Architecture

```
Voice Message → Telegram Download → Audio Conversion → STT API → Transcript → Bot Response
```

## Supported Providers

### OpenAI Whisper

```typescript
const response = await fetch(STT_API_URL + "/v1/audio/transcriptions", {
  method: "POST",
  headers: {
    "Authorization": `Bearer ${STT_API_KEY}`,
    "Content-Type": "multipart/form-data",
  },
  body: formData,
});

const { text } = await response.json();
// text contains the transcription
```

### Groq (Fast)

```typescript
// Groq uses whisper-large-v3-turbo for fast, high-quality transcription
const response = await fetch("https://api.groq.com/openai/v1/audio/transcriptions", {
  method: "POST",
  headers: {
    "Authorization": `Bearer ${STT_API_KEY}`,
    "Content-Type": "multipart/form-data",
  },
  body: formData,
});
```

## Audio Format Conversion

Telegram voice messages are OGG/Opus format. Most STT APIs require specific formats.

### Using FFmpeg

```typescript
import { spawn } from "child_process";

async function convertOggToMp3(inputPath: string): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const ffmpeg = spawn("ffmpeg", [
      "-i", inputPath,
      "-vn",           // no video
      "-acodec", "libmp3lame",
      "-q:a", "2",     // quality
      "-f", "mp3",
      "-"               // output to stdout
    ]);

    const chunks: Buffer[] = [];
    ffmpeg.stdout.on("data", (chunk) => chunks.push(chunk));
    ffmpeg.on("close", (code) => {
      if (code === 0) resolve(Buffer.concat(chunks));
      else reject(new Error(`ffmpeg exited with ${code}`));
    });
    ffmpeg.on("error", reject);
  });
}
```

### Using Node.js (No FFmpeg)

```typescript
// For WebM/Opus files, convert using the opusscript package
import { decode } from "opusscript";

async function convertToWav(inputBuffer: Buffer): Promise<Buffer> {
  // Telegram OGG is already Opus, can sometimes be used directly
  // Most providers accept OGG directly: check provider docs
  return inputBuffer;
}
```

## Complete Integration Pattern

```typescript
import { Context, NextFunction } from "grammy";
import { FileId } from "@grammyjs/types";
import { createWriteStream, createReadStream } from "fs";
import { pipeline } from "stream/promises";
import { tmpdir } from "os";
import { join } from "path";

export async function handleVoiceMessage(ctx: Context) {
  const voice = ctx.message?.voice;
  if (!voice) return;

  try {
    // 1. Download voice file
    const fileId = voice.file_id;
    const file = await ctx.api.getFile(fileId);
    const downloadUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`;

    const tempPath = join(tmpdir(), `voice_${Date.now()}.ogg`);
    await pipeline(
      (await fetch(downloadUrl)).body,
      createWriteStream(tempPath)
    );

    // 2. Prepare form data for STT API
    const formData = new FormData();
    formData.append("file", await readFile(tempPath), {
      filename: "voice.ogg",
      contentType: "audio/ogg",
    });
    formData.append("model", "whisper-1");
    formData.append("language", voice.language_code || "en"); // Optional: specify language

    // 3. Transcribe
    const response = await fetch(STT_API_URL + "/v1/audio/transcriptions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${STT_API_KEY}` },
      body: formData,
    });

    if (!response.ok) {
      throw new Error(`STT API error: ${response.status}`);
    }

    const { text } = await response.json();

    // 4. Send transcript back
    await ctx.reply(`📝 Transcription:\n${text}`);

    // 5. Optionally: use transcript as command
    await ctx.reply(`💬 Processing: "${text}"...`);

  } catch (error) {
    console.error("STT error:", error);
    await ctx.reply("❌ Sorry, I couldn't transcribe that voice message.");
  }
}
```

## grammY Middleware Pattern

```typescript
// Middleware to intercept voice messages
bot.on("message:voice", async (ctx) => {
  const voice = ctx.message.voice;

  // Check if STT is configured
  if (!process.env.STT_API_URL || !process.env.STT_API_KEY) {
    return; // Skip, let other handlers process
  }

  await ctx.reply("🎤 Transcribing...");

  try {
    const transcript = await transcribeVoice(ctx, voice);
    // Store transcript in session for next handler
    ctx.session.pendingTranscript = transcript;
    await ctx.reply(`You said: ${transcript}`);
  } catch (error) {
    await ctx.reply("❌ Transcription failed. Please try again or type your message.");
  }
});
```

## Environment Variables

```env
STT_API_URL=https://api.openai.com/v1        # Or Groq, Together, etc.
STT_API_KEY=sk-...                           # API key for STT provider
```

## Supported Languages

Most STT providers auto-detect language. For better accuracy, specify:

```typescript
formData.append("language", "en"); // ISO 639-1 language code
```

Common languages: `en`, `es`, `fr`, `de`, `it`, `pt`, `ru`, `zh`, `ja`, `ko`

## Common Pitfalls

1. **File size limits** — Most STT APIs have audio file limits (e.g., 25MB for Whisper)
2. **Duration limits** — Telegram voice messages max 60 minutes; consider chunking long audio
3. **Encoding issues** — Always verify audio codec compatibility with your STT provider
4. **Rate limits** — STT APIs have rate limits; implement retry logic
5. **Missing language code** — `ctx.message.voice.language_code` may be null; have a fallback

## Reference

- [OpenAI Whisper API](https://platform.openai.com/docs/guides/speech-to-text)
- [Groq Speech-to-Text](https://console.groq.com/docs/speech-to-text)
- [Telegram Bot API - Voice Messages](https://core.telegram.org/bots/api#voice)
