---
name: llm-testing
description: >
  Comprehensive testing prompts and wordlists for evaluating LLM security, safety, and robustness.
  Covers bias detection, data leakage prevention, alignment testing, privacy boundaries, and adversarial
  prompt resistance. Designed for security researchers, AI safety engineers, and red team operators to
  assess LLM vulnerabilities including: gender/nationality/race bias testing, PII generation and metadata
  leakage, session memory recall, escape-from-alignment training attacks, and pre-training data extraction.
---
