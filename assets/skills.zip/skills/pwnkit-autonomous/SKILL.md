---
name: pwnkit-autonomous
description: Shell-first autonomous pentesting framework that hacks code. Zero config, blind verification (re-exploits every finding), and covers web apps, LLM endpoints, npm packages, and source code. Use when needing autonomous security testing with zero false positives.
---

# pwnkit - Autonomous Security Research Framework

## When to Use

- **Zero config pentesting** - Just `npx pwnkit-cli <target>` and run
- **Blind verification** - Every finding independently re-exploited
- **LLM endpoint testing** - Test ChatGPT, Claude, Llama APIs for vulnerabilities
- **npm package auditing** - Supply chain security for JavaScript
- **Source code review** - AI-powered vulnerability discovery

## Features

- **Zero YAML/config** - Just `npx pwnkit-cli` and you're running
- **Blind verification** - Re-exploits every finding to kill false positives
- **Multi-category coverage**: Web apps, LLM endpoints, npm packages, source code
- **Bring your own AI** - Use any LLM endpoint
- **86.5% CTF benchmark** - Beats MAPTA, deadend-cli, Cyber-AutoAgent
- **No false positives** - Can't reproduce? Killed as false positive

## Installation

```bash
# Quick start (npx)
npx pwnkit-cli express

# Audit npm package
npx pwnkit-cli ./my-repo

# Scan LLM endpoint
npx pwnkit-cli https://api.com/chat

# Full install
git clone https://github.com/peaktwilight/pwnkit.git
cd pwnkit
pnpm install
```

## Usage Examples

```bash
# Web application
npx pwnkit-cli https://victim.com

# LLM endpoint
npx pwnkit-cli https://api.openai.com/v1/chat

# Local repo
npx pwnkit-cli ./security-app

# npm package
npx pwnkit-cli express
```

## Integration with Systemv2.5

| Systemv2.5 Category | pwnkit Capability |
|---------------------|-------------------|
| AI Threat Testing | LLM endpoint scanning |
| Source Code Audit | AI-powered vulnerability discovery |
| Supply Chain Security | npm package auditing |
| Web Testing | Automated vulnerability detection |

## Verification Process

```
1. AI finds potential vulnerability
2. pwnkit writes independent PoC
3. PoC executes against target
4. If exploitable → reported
5. If not → killed as false positive
```

## Tool Comparison

| Feature | pwnkit | promptfoo | garak | nuclei | Semgrep |
|---------|--------|-----------|-------|--------|---------|
| Autonomous multi-agent | ✓ | - | - | - | - |
| Verification (no FP) | ✓ Re-exploits | - | - | - | - |
| LLM endpoint scanning | ✓ | ✓ | ✓ | - | - |
| npm package audit | ✓ | - | - | - | Rules |
| Source code review | AI-powered | - | - | - | Rules |
| Zero config | ✓ npx | YAML | Python | Templates | Config |

## Coverage

- **Web Apps**: SQLi, XSS, RCE, SSTI, IDOR, Auth bypass
- **LLM Endpoints**: Prompt injection, prompt leaking, tool abuse
- **npm Packages**: Dependency confusion, malicious code, typosquatting
- **Source Code**: Static analysis with AI reasoning