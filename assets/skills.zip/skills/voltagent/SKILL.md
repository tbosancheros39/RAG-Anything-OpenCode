---
name: voltagent
description: VoltAgent — End-to-end AI Agent Engineering Platform for TypeScript. Covers Memory, RAG, Guardrails, Tools, and agent engineering patterns. Use when building production agent systems or organizing multi-skill agent workflows. Triggered when users mention VoltAgent, voltagent.dev, building production agents, agent memory systems, RAG pipelines, guardrails, or multi-skill agent orchestration.
---

# VoltAgent

VoltAgent is an end-to-end AI Agent Engineering Platform for TypeScript, providing a comprehensive framework for building, deploying, and orchestrating production-grade AI agents with built-in support for memory, RAG, guardrails, and tools.

---

## Overview

VoltAgent is designed for professional AI agent development:
- **Comprehensive agent lifecycle** management
- **Memory systems** with semantic and episodic memory
- **RAG pipeline** integration for knowledge augmentation
- **Guardrails** for safe agent behavior
- **Tool ecosystem** with standardized interfaces
- **Multi-agent orchestration** for complex workflows
- **Enterprise-ready** with observability and security

---

## When to Activate

- Building production AI agent systems in TypeScript
- Implementing agent memory and context management
- Creating RAG pipelines for knowledge retrieval
- Adding guardrails for safe AI behavior
- Orchestrating multi-skill agent workflows
- Building agent-to-agent communication systems
- Need enterprise-grade agent observability

---

## Key Features & Patterns

### Agent Creation

```typescript
import { Agent, Model } from "@voltagent/core";

const agent = new Agent({
  name: "assistant",
  model: new Model("openai", "gpt-4o"),
  instructions: "You are a helpful research assistant",
});

const response = await agent.generate("Explain quantum computing");
```

### Memory System

```typescript
import { MemoryStore, SemanticMemory, EpisodicMemory } from "@voltagent/core";

const memoryStore = new MemoryStore({
  type: "postgres",
  connection: process.env.DATABASE_URL,
});

const semanticMemory = new SemanticMemory({
  embedder: "openai",
  embeddingModel: "text-embedding-3-small",
  store: memoryStore,
});

const episodicMemory = new EpisodicMemory({
  store: memoryStore,
});

await semanticMemory.store("key-concept", "The meaning of AGI");
const context = await semanticMemory.search("concepts about AI");
```

### RAG Pipeline

```typescript
import { RAGPipeline, VectorStore, ChunkingStrategy } from "@voltagent/rag";

const ragPipeline = new RAGPipeline({
  embedder: {
    provider: "openai",
    model: "text-embedding-3-small",
  },
  vectorStore: new VectorStore("pgvector"),
  chunker: new ChunkingStrategy({
    chunkSize: 512,
    overlap: 64,
  }),
});

await ragPipeline.indexDocuments("knowledge-base", documents);
const answer = await ragPipeline.query("What is the policy for returns?");
```

### Guardrails

```typescript
import { Guardrail, GuardrailConfig } from "@voltagent/guardrails";

const contentFilter = new Guardrail({
  name: "content-filter",
  config: {
    blockHarmfulContent: true,
    blockPersonalInfo: true,
    maxToxicity: 0.7,
  },
});

const result = await contentFilter.evaluate(userInput);
if (result.blocked) {
  return "I cannot process that request.";
}
```

### Tools

```typescript
import { Tool, ToolExecutor } from "@voltagent/core";

const weatherTool = new Tool({
  name: "get_weather",
  description: "Get weather for a location",
  schema: {
    location: { type: "string", required: true },
    units: { type: "string", enum: ["metric", "imperial"] },
  },
  execute: async (params) => {
    const weather = await weatherAPI.get(params.location);
    return weather;
  },
});

agent.registerTools([weatherTool]);
```

### Multi-Agent Orchestration

```typescript
import { AgentSwarm, SwarmConfig } from "@voltagent/swarm";

const swarm = new AgentSwarm({
  agents: [researcherAgent, writerAgent, reviewerAgent],
  orchestrator: "hierarchical",
});

const result = await swarm.run({
  task: "Research and write a report on AI trends",
  assigner: "coordinator",
});
```

---

## Integration Tips

### For Telegram Bot Projects

- Use VoltAgent as the agent orchestration layer for complex bot workflows
- Implement VoltAgent memory to maintain persistent user context across Telegram sessions
- Configure guardrails to filter inappropriate user inputs before processing
- Use VoltAgent tools to wrap Telegram API functionality as agent tools
- Leverage multi-agent patterns for separating concerns (e.g., research agent vs. response agent)

### Production Considerations

- Configure proper vector store indexing for RAG performance
- Set up monitoring and tracing for agent behavior
- Implement proper error handling and fallback strategies
- Use guardrails to prevent agent from taking harmful actions

---

## Official Resources

- Website: https://voltagent.dev/
- GitHub: VoltAgent/voltagent
- Skills: VoltAgent/awesome-agent-skills
