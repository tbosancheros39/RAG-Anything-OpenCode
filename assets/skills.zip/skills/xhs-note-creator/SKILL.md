---
name: xhs-note-creator
description: 小红书笔记素材创作技能。创作小红书笔记内容、生成精美图片卡片（8种主题+4种分页模式），可发布到小红书。当用户需要创建小红书图文素材时触发。
---

# 小红书笔记创作技能

## 工作流程

### 第一步：撰写笔记内容
- 标题：不超过20字，吸引眼球，可用数字/疑问句/感叹号
- 正文：段落清晰，少量Emoji（每段1-2个），短句短段，结尾5-10个SEO标签

### 第二步：生成渲染用Markdown文档

文档结构：
```markdown
---
emoji: "🚀"
title: "封面大标题（≤15字）"
subtitle: "封面副标题（≤15字）"
---

# 正文内容...

---

# 第二张卡片内容...
```

分页策略：
- 内容精确切分 → 用 `---` 分隔，配合 `-m separator`
- 内容长短不稳定 → 普通Markdown，用 `-m auto-split`

### 第三步：渲染图片卡片
```bash
python scripts/render_xhs.py content.md -t sketch -m auto-split
```

主题（`-t`）：`sketch`（默认）、`default`、`playful-geometric`、`neo-brutalism`、`botanical`、`professional`、`retro`、`terminal`

分页模式（`-m`）：`separator`（默认）、`auto-fit`、`auto-split`、`dynamic`

生成：`cover.png`（封面）+ `card_1.png`、`card_2.png`...（正文卡片）

### 第四步：发布（可选）
前置：配置 `.env` 文件中的 `XHS_COOKIE`

```bash
# 仅自己可见（推荐先预览）
python scripts/publish_xhs.py --title "标题" --desc "描述" \
  --images cover.png card_1.png

# 公开发布
python scripts/publish_xhs.py --title "标题" --desc "描述" \
  --images cover.png card_1.png --public
```
