---
name: cloud-security-testing
description: AWS, Azure, GCP, Docker, and Kubernetes security assessment. Use when testing cloud infrastructure, container environments, or cloud-native applications.
---

# Cloud & Container Security Testing

Test for vulnerabilities in cloud environments, containers, and orchestration systems.

## When to Use

- Testing AWS/Azure/GCP deployments
- Assessing Docker security
- Kubernetes penetration testing
- Cloud misconfiguration detection
- Container escape testing

## Cloud Services

### AWS
| Service | Attack Vector |
|---------|---------------|
| S3 | Public buckets, bucket enumeration |
| EC2 | Metadata API (169.254.169.254) |
| Lambda | Environment variables, privileges |
| IAM | Overly permissive roles |
| RDS | SQL injection → data exfil |

### Azure
| Service | Attack Vector |
|---------|---------------|
| Storage | Public blobs, SAS tokens |
| VM | Metadata endpoint |
| Functions | Secrets in environment |
| Key Vault | Access policies |

### GCP
| Service | Attack Vector |
|---------|---------------|
| Storage | Public buckets |
| Compute | Metadata endpoint |
| Cloud Functions | Environment secrets |
| BigQuery | SQL injection |

## Docker Attacks
- **Container escape**: --privileged, volume mounts
- **Docker socket exposure**: /var/run/docker.sock
- **Image vulnerabilities**: Outdated base images
- **Secrets in images**: Environment vars, Docker history

## Kubernetes
- **API Server**: Unauthenticated access
- **Service Account Tokens**: Default tokens in pods
- **RBAC**: Overly permissive bindings
- **Secrets**: Unencrypted etcd
- **Network Policies**: Missing segmentation

## Payloads

```
AWS Metadata: curl http://169.254.169.254/latest/meta-data/
S3 Bucket: aws s3 ls s3://bucket-name --no-sign-request
Docker Socket: docker -H unix:///var/run/docker.sock ps
K8s API: curl -k https://kubernetes:443/api/v1/secrets
```

## Workflow

1. **Enumerate** — Discover cloud resources
2. **Identify** — Find exposed services
3. **Access** — Test for anonymous/weak access
4. **Escalate** — Use limited access to gain more
5. **Exfiltrate** — Extract sensitive data

## Tools

- `awscli` — AWS enumeration
- `azure-cli` — Azure enumeration
- `gcloud` — GCP enumeration
- `nuclei` — Cloud misconfiguration templates
- `trufflehog` — Secret scanning
- `kubesec` — K8s security scoring