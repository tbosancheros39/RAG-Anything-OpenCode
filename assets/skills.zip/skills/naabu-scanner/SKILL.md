# Naabu

Fast port scanner written in Go by ProjectDiscovery. Designed for reliability and ease of use in bug bounties and pentests.

## When to Use

- Bug bounty reconnaissance
- Fast port enumeration
- Service discovery
- Quick network mapping

## Features

- **SYN/CONNECT/UDP scanning**
- **DNS port scanning**
- **IPv4/IPv6 support**
- **Nmap integration** for service detection
- **Passive scanning** via Shodan InternetDB
- **Host discovery** options
- **CDN/WAF exclusion**

## Installation

```bash
# Go install
go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest

# Docker
docker pull projectdiscovery/naabu
```

## Basic Usage

```bash
# Scan single host
naabu -host hackerone.com

# Scan specific ports
naabu -host 192.168.1.1 -p 80,443,22

# Scan port range
naabu -host 192.168.1.1 -p 1-1000

# Top ports
naabu -host 192.168.1.1 -top-ports 100

# Full port scan
naabu -host 192.168.1.1 -p -

# Passive scan (Shodan)
naabu -host 192.168.1.1 -passive

# JSON output
naabu -host 192.168.1.1 -json
```

## Advanced Options

```bash
# SYN scan (requires root)
sudo naabu -host 192.168.1.1 -s

# With Nmap for service detection
naabu -host 192.168.1.1 -nmap-cli 'nmap -sV -oX nmap-output'

# Exclude CDN/WAF IPs
naabu -host target.com -exclude-cdn

# Rate control
naabu -host 192.168.1.1 -rate 1000

# ASN scanning
echo AS14421 | naabu -p 80,443

# Input from file
naabu -list hosts.txt
```

## Quick Commands

| Command | Description |
|---------|-------------|
| `naabu -host <target>` | Basic scan |
| `naabu -host <target> -top-ports 1000` | Top 1000 ports |
| `naabu -host <target> -p -` | Full port scan |
| `naabu -list targets.txt` | Scan from file |
| `naabu -host <target> -json` | JSON output |

## Prerequisite

- Linux: `sudo apt install -y libpcap-dev`
- macOS: `brew install libpcap`
- Windows: Install Npcap