---
name: wooyun-vuln-expert
description: WooYun漏洞分析专家系统。基于88,636个真实漏洞案例提炼的元思考方法论、测试流程、利用技巧、绕过方法。覆盖SQL注入、XSS、命令执行、逻辑漏洞、文件上传、未授权访问等主要漏洞类型。当用户进行漏洞挖掘、渗透测试、安全审计、代码审计时触发。
---

# WooYun 漏洞分析专家系统

## 漏洞类型全景图

| 漏洞类型 | 案例数 | 核心洞察 |
|----------|--------|----------|
| SQL注入 | 27,732 | 代码与数据边界混淆 |
| XSS跨站 | 7,532 | 信任边界突破 |
| 命令执行 | 6,826 | 数据到指令的跃迁 |
| 逻辑漏洞 | 8,292 | 业务假设与行为偏差 |
| 文件上传 | 2,711 | 执行攻击者代码 |
| 未授权访问 | 14,377 | 访问控制缺失 |
| 信息泄露 | 7,337 | 敏感数据暴露 |
| 文件遍历 | 2,854 | 路径控制突破 |

## 元思考方法论框架

### 漏洞本质公式
```
漏洞 = 预期行为 - 实际行为
    = 开发者假设 ⊕ 攻击者输入 → 意外状态
```

核心问题链：
1. 数据从哪来？→ GET/POST/Cookie/Header/文件
2. 数据到哪去？→ 验证→处理→存储→输出
3. 在哪被信任？→ 前端/后端/数据库/系统
4. 如何被处理？→ 过滤/转义/验证/执行
5. 处理后去哪？→ HTML/SQL/命令/文件

### 攻击面映射
```
输入层 ──► 处理层 ──► 输出层
GET参数   输入验证    HTML页面
POST数据  业务逻辑    JSON响应
Cookie    数据库操作  文件下载
HTTP头    文件操作    错误信息
文件上传  系统调用    日志记录
```

## SQL注入速查

```
注入点：高危参数（id, sort_id, username, password, search, keyword）
测试向量：' " ) ') ") -- # /*
数据库指纹：@@version(MSSQL) version()(MySQL) v$version(Oracle)

绕过：空格(/**/%09%0a()) | 关键字(SeLeCt/sel%00ect/*!select*/)
     等号(LIKE/REGEXP/BETWEEN/IN) | 引号(0x十六进制/char()/concat())
```

## XSS速查

```
输出点：用户内容、搜索回显、文件属性、邮件内容
绕过：标签变形(<ScRiPt>/<script/x>) | 事件(onerror/onload/onmouseover)
     编码(HTML实体/JS Unicode/URL编码) | 协议(javascript:/data:/vbscript:)
```

## 命令执行速查

```
入口点：系统命令、文件操作、代码执行(eval/assert)、框架漏洞
绕过：空格(${IFS}/$IFS$9/%09/<>) | 关键字(ca\t/ca''t/c$@at)
     编码($(printf "\x63\x61\x74")/`echo Y2F0|base64 -d`)
```

## 逻辑漏洞速查

```
模式：密码重置(验证码回显/步骤跳过/凭证可控)
     越权访问(水平越权ID遍历/垂直越权角色提权)
     支付逻辑(金额篡改/数量篡改/优惠叠加)
     验证码(不刷新/可重用/可爆破/客户端验证)
```

## 文件上传速查

```
绕过：前端验证(修改JS/直接发包) | Content-Type(image/gif+PHP代码)
     扩展名(.php5/.phtml/.pht/.php./.php::$DATA)
     内容检测(GIF89a+<?php 或图片马)
解析：IIS 6.0(/test.asp/1.jpg) | Apache(.php.xxx)
     Nginx(/1.jpg/1.php) | Tomcat(test.jsp%00.jpg)
```

## 未授权访问速查

```
类型：后台未授权(/admin/manager/console)
     API未授权(无鉴权/Token可预测)
     服务未授权(Redis/MongoDB/ES/Memcached)
     IDOR(水平越权访问他人数据)

常见：Redis(6379写SSH公钥) | MongoDB(27017直接访问)
     Elasticsearch(9200泄露/RCE) | Memcached(11211)
     Docker(2375容器逃逸)
```

## 通用渗透测试流程

### 信息收集
```bash
subfinder -d target.com -o subs.txt
nmap -sV -sC -p- target.com
dirsearch -u https://target.com -w wordlist.txt
waybackurls target.com | grep "="
```

### 漏洞探测优先级
1. **高危快速检测**：SQL注入、命令执行、文件上传
2. **中危系统检测**：XSS、未授权访问、逻辑漏洞
3. **低危完整覆盖**：信息泄露、配置错误、敏感信息

## 防御修复方案

| 漏洞类型 | 核心防御 | 具体措施 |
|----------|----------|----------|
| SQL注入 | 参数化查询 | PreparedStatement/ORM |
| XSS | 输出编码 | HTML实体编码/CSP |
| 命令执行 | 避免拼接 | execFile代替exec/白名单 |
| 文件上传 | 严格校验 | 白名单扩展名/重命名/隔离 |
| 未授权 | 访问控制 | 认证+授权+会话管理 |
| 逻辑漏洞 | 服务端校验 | 关键逻辑后端验证 |
