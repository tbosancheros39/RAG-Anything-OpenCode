# Portsweep

A blazing-fast TCP/UDP port scanner for developers — written in Rust with async I/O. Scan open ports on any host in milliseconds. No root required.

## When to Use

- Quick local network scans
- Developer network diagnostics
- Fast single-host scanning
- When you need results in sub-second time
- Banner grabbing without root

## Features

- **Speed**: Full 65k port TCP scan in ~800ms
- **No Root Required**: Works as regular user
- **Async I/O**: Uses Tokio for concurrent scanning
- **TCP + UDP**: Scans both protocols
- **Banner Grabbing**: Extract service banners
- **CIDR Support**: Scan entire subnets

## Installation

```bash
# From crates.io
cargo install portsweep

# Or prebuilt binaries from releases
```

## Basic Usage

```bash
# Scan common ports (1-1024) - default
portsweep scan localhost

# Full port range
portsweep scan 192.168.1.1 --range 1-65535

# Specific ports
portsweep scan 192.168.1.1 --range 22,80,443,8080

# Custom range
portsweep scan 192.168.1.1 --range 8000-9000

# UDP scanning
portsweep scan 192.168.1.1 --udp

# High concurrency for speed
portsweep scan 192.168.1.1 --concurrency 1000 --timeout 150

# JSON output
portsweep scan 192.168.1.1 --json
```

## Benchmark Comparison

| Tool | Time (65k ports) | Notes |
|------|------------------|-------|
| **portsweep** | **~800ms** | --concurrency 1000 |
| nmap SYN | ~12s | Requires root |
| Python socket | ~90s | Sequential |

## Options

| Option | Description | Default |
|--------|-------------|---------|
| `--range` | Port range to scan | 1-1024 |
| `--concurrency` | Concurrent connections | 100 |
| `--timeout` | Connection timeout (ms) | 1000 |
| `--udp` | Scan UDP ports | false |
| `--json` | JSON output | false |
| `--verbose` | Verbose output | false |

## Notes

- No root needed for TCP scans
- Uses async Tokio runtime
- Safe Rust (no unsafe code)
- Great for quick reconnaissance