---
name: ai-workflow-red-team-lite
description: >
  Lightweight red team exercises for AI automation workflows, focusing on misuse paths, boundary failures,
  and data leakage risks. Produces structured output: attack surface summary, misuse paths, boundary failures,
  data risks, mitigation suggestions, and drill checklists. Defensive only — does not provide exploitable
  attack scripts or steps to destroy systems.
---
