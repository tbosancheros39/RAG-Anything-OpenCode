---
name: reddit-quote-topaz
description: Create an Instagram carousel from a popular-picks list with Reddit quotes and Topaz 2x AI upscaling. Cover = "clean" style ("Top CATEGORY in Destination"), attraction slides = "quote" style with Reddit quotes + subreddit attribution. All photos Topaz-enhanced before overlay. Trigger phrase "reddit-quote-topaz".
---

# Reddit Quote Carousel (Topaz Enhanced)

Same as `reddit-quote-carousel` but adds **Topaz Labs 2x AI upscale** after photo finding, before text overlays.

## Trigger

Bernard says **"reddit-quote-topaz"** → use this skill.
Bernard says **"reddit-quote"** → use `reddit-quote-carousel` (no Topaz).

## Parameters

- **destination** (required): City/region (e.g. "Barcelona")
- **category** (required): What the picks are (e.g. "Cheap Eats", "Hidden Gems")
- **popular_picks_url** (required): tabiji.ai popular-picks page URL to pull attractions + Reddit quotes from
- **reddit_post_count** (optional): Number of Reddit posts analyzed

## Pipeline (3 chained sub-agents)

Working directory: `/tmp/ig-reddit-quote/`

### Sub-agent 1: Scrape Picks + Find Photos + Topaz Enhance

1. **Fetch the popular-picks page** via `web_fetch` to get:
   - List of attractions (names)
   - A compelling Reddit quote for each attraction
   - The subreddit each quote came from
   - Total Reddit post count if shown on the page

2. **Find photos** using `instagram-photo-find` workflow:
   - 1 hero photo for the destination (for cover slide)
   - 1 photo per attraction (for quote slides)
   - For each: `web_search` → download candidates → vision-score → keep best

3. **Topaz 2x Enhance each best photo:**
```bash
TOPAZ_API_KEY=$(security find-generic-password -s "topaz-api-key" -w)

curl --request POST \
  --url https://api.topazlabs.com/image/v1/enhance \
  --header "X-API-Key: ${TOPAZ_API_KEY}" \
  --header 'accept: image/jpeg' \
  --header 'content-type: multipart/form-data' \
  --form 'model=Low Resolution V2' \
  --form 'output_scale_factor=2' \
  --form 'output_format=jpeg' \
  --form "image=@/tmp/ig-reddit-quote/${slug}-best.jpg" \
  --output "/tmp/ig-reddit-quote/${slug}-enhanced.jpg"
```

If sync returns JSON with `process_id` instead of image bytes, use async flow:
```bash
RESPONSE=$(curl -s --request POST \
  --url https://api.topazlabs.com/image/v1/enhance/async \
  --header "X-API-Key: ${TOPAZ_API_KEY}" \
  --header 'content-type: multipart/form-data' \
  --form 'model=Low Resolution V2' \
  --form 'output_scale_factor=2' \
  --form 'output_format=jpeg' \
  --form "image=@/tmp/ig-reddit-quote/${slug}-best.jpg")

PROCESS_ID=$(echo "$RESPONSE" | jq -r '.process_id')

while true; do
  STATUS=$(curl -s --header "X-API-Key: ${TOPAZ_API_KEY}" \
    "https://api.topazlabs.com/image/v1/status/${PROCESS_ID}" | jq -r '.status')
  [ "$STATUS" = "Completed" ] && break
  sleep 3
done

curl -s --header "X-API-Key: ${TOPAZ_API_KEY}" \
  "https://api.topazlabs.com/image/v1/download/${PROCESS_ID}" \
  --output "/tmp/ig-reddit-quote/${slug}-enhanced.jpg"
```

4. **Write manifest** to `/tmp/ig-reddit-quote/manifest.json`

### Sub-agent 2: Text Overlays

Read manifest. Create overlays using `instagram-photo-text-overlay` skill on **enhanced** images.

**Slide 1 (Cover)** — `clean` style:
```bash
python3 .../overlay.py --input /tmp/ig-reddit-quote/cover-enhanced.jpg \
  --output /tmp/ig-reddit-quote/slide-1.jpg \
  --title "Top {COUNT} {CATEGORY} in {DESTINATION}" \
  --subtitle "Insider Takes from Reddit ({N}+ posts)" \
  --style clean --watermark "tabiji.ai"
```

**Slides 2+** — `quote` style, one per attraction:
```bash
python3 .../overlay.py --input /tmp/ig-reddit-quote/{slug}-enhanced.jpg \
  --output /tmp/ig-reddit-quote/slide-{N}.jpg \
  --title "{ATTRACTION_NAME}" \
  --quote "{REDDIT_QUOTE}" \
  --author "{SUBREDDIT}" \
  --style quote --watermark "tabiji.ai"
```

Output: slides at `/tmp/ig-reddit-quote/slide-{1-N}.jpg`

### Sub-agent 3: Publish to Instagram

1. Host images in tabiji repo (`img/instagram/`), git push, use raw GitHub URLs
2. Create carousel item containers
3. Create carousel container with caption
4. Publish
5. Get permalink
6. Cleanup hosted images + local temp files

## Tips

- Pick quotes that are **specific and personal** — "best patatas bravas of my life" beats "this place is great"
- Keep quotes under ~120 chars so they render well on the slide
- **Topaz model:** `Low Resolution V2` — designed for web-sourced images
- **Topaz rate limits:** If HTTP 429, use exponential backoff. Sequential processing of 6-8 images should be fine.
