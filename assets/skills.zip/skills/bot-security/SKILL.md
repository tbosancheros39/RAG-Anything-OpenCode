---
name: bot-security
description: Security patterns for Telegram bots — input sanitization, command allowlisting, shell injection prevention, session hijacking protection, environment isolation, and secret rotation. Use when auditing bot security, hardening command handlers, or implementing safe shell execution.
---

# Bot Security

Security hardening patterns for Telegram bots built with TypeScript and grammY.

## When to Activate

- Auditing bot security posture
- Implementing command handlers with user input
- Building shell command execution features
- Setting up production bot deployments
- Preventing injection attacks via user messages
- Implementing session protection

## Core Security Principles

1. **Never trust user input** — Sanitize everything from Telegram
2. **Principle of least privilege** — Bot should only have permissions it needs
3. **Defense in depth** — Multiple layers of security
4. **Fail securely** — When in doubt, deny access

## Input Sanitization

### Message Content

```typescript
import { escapeHtml, stripMarkdown } from "../utils/sanitize";

// Escape HTML special characters
function sanitizeHtml(input: string): string {
  return input
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// For display in HTML-formatted messages
function escapeForTelegram(input: string): string {
  return input
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

// For shell commands — NEVER pass raw user input
function sanitizeForShell(input: string): string {
  // Remove anything that could be shell injection
  return input.replace(/[^a-zA-Z0-9_\-\./:space:]/g, "");
}
```

### Command Arguments

```typescript
interface SafeCommandResult {
  success: boolean;
  sanitized?: string;
  error?: string;
}

function safeParseCommand(input: string): SafeCommandResult {
  if (!input || input.trim() === "") {
    return { success: false, error: "Empty command" };
  }

  // Remove null bytes and control characters
  const cleaned = input.replace(/[\x00-\x1F\x7F]/g, "").trim();

  // Check length
  if (cleaned.length > 1000) {
    return { success: false, error: "Command too long" };
  }

  // Check for obviously dangerous patterns
  const dangerous = [
    /;\s*rm\s+/i,
    /;\s*dd\s+/i,
    /\|\s*sh\s*$/i,
    /^>\s*\/dev\//i,
    /\.\.\/.*\.\./,  // path traversal
  ];

  for (const pattern of dangerous) {
    if (pattern.test(cleaned)) {
      return { success: false, error: "Potentially dangerous command detected" };
    }
  }

  return { success: true, sanitized: cleaned };
}
```

## Shell Command Allowlisting

```typescript
// Allowlist approach — only permit known commands
const ALLOWED_COMMANDS = new Set([
  "ls", "pwd", "echo", "cat", "head", "tail", "grep", "find", "stat",
]);

const ALLOWED_FLAGS: Record<string, Set<string>> = {
  ls: new Set(["-la", "-l", "-a", "-R", "-1"]),
  grep: new Set(["-n", "-i", "-r", "-E", "-v", "--color=never"]),
  find: new Set(["-name", "-type", "-maxdepth"]),
};

function validateShellCommand(command: string, args: string[]): boolean {
  // Check command is allowlisted
  if (!ALLOWED_COMMANDS.has(command)) {
    return false;
  }

  // Check flags are allowlisted
  if (args.length > 0) {
    const allowedFlags = ALLOWED_FLAGS[command];
    for (const arg of args) {
      // Allow flags that start with - and are in allowlist
      if (arg.startsWith("-") && allowedFlags && !allowedFlags.has(arg)) {
        return false;
      }
      // Block any argument containing suspicious patterns
      if (/[;&|`$(){}[\]<>]/.test(arg)) {
        return false;
      }
    }
  }

  return true;
}
```

## Session Protection

### Single-User Restriction

```typescript
// Environment-based user restriction
const ALLOWED_USER_ID = process.env.TELEGRAM_ALLOWED_USER_ID;

async function verifyUser(ctx: Context): Promise<boolean> {
  const userId = ctx.from?.id.toString();
  return userId === ALLOWED_USER_ID;
}

// Middleware to enforce
bot.use(async (ctx, next) => {
  if (!ALLOWED_USER_ID) {
    console.warn("TELEGRAM_ALLOWED_USER_ID not set — allowing all users");
    return next();
  }

  const userId = ctx.from?.id.toString();
  if (userId !== ALLOWED_USER_ID) {
    console.warn(`Unauthorized access attempt from ${userId}`);
    // Don't reveal bot is working to unauthorized users
    return;
  }

  return next();
});
```

### Session Timeout

```typescript
interface SecureSession {
  userId: string;
  createdAt: number;
  lastAccess: number;
  ipAddress?: string;
}

const SESSION_TIMEOUT_MS = 30 * 60 * 1000; // 30 minutes
const sessions = new Map<string, SecureSession>();

function validateSession(sessionId: string, ctx: Context): boolean {
  const session = sessions.get(sessionId);
  if (!session) return false;

  // Check timeout
  if (Date.now() - session.lastAccess > SESSION_TIMEOUT_MS) {
    sessions.delete(sessionId);
    return false;
  }

  // Optional: verify IP address hasn't changed
  const currentIp = ctx.me?.ipAddress;
  if (currentIp && session.ipAddress && currentIp !== session.ipAddress) {
    console.warn(`Session IP changed: ${session.ipAddress} → ${currentIp}`);
    // Optionally invalidate session
  }

  // Update last access
  session.lastAccess = Date.now();
  return true;
}
```

## Environment Isolation

```typescript
// .env file — NEVER commit this
// Use environment-specific config

// production.env
TELEGRAM_BOT_TOKEN=secure_token_here
TELEGRAM_ALLOWED_USER_ID=123456789
OPENCODE_API_URL=http://localhost:4096
LOG_LEVEL=warn

// File permissions
// chmod 600 production.env
```

## Secret Rotation

```typescript
// Implement secret refresh capability
interface SecretConfig {
  apiKey: string;
  rotatedAt: number;
  expiresAt: number;
}

class SecretManager {
  private current: SecretConfig;
  private previous?: SecretConfig;

  constructor(initial: string, ttlMs: number) {
    this.current = {
      apiKey: initial,
      rotatedAt: Date.now(),
      expiresAt: Date.now() + ttlMs,
    };
  }

  async rotate(newKey: string): Promise<void> {
    // Keep previous for graceful transition
    this.previous = this.current;
    this.current = {
      apiKey: newKey,
      rotatedAt: Date.now(),
      expiresAt: Date.now() + (this.current.expiresAt - this.current.rotatedAt),
    };
  }

  get(): string {
    // Check if current is expired
    if (Date.now() > this.current.expiresAt) {
      if (this.previous) {
        return this.previous.apiKey; // Graceful fallback
      }
      throw new Error("All secrets expired");
    }
    return this.current.apiKey;
  }
}
```

## Rate Limiting

```typescript
// Implement per-user rate limiting
const userRequests = new Map<string, number[]>();
const WINDOW_MS = 60 * 1000; // 1 minute
const MAX_REQUESTS = 30;

function checkRateLimit(userId: string): boolean {
  const now = Date.now();
  const requests = userRequests.get(userId) || [];

  // Filter old requests
  const recent = requests.filter(t => now - t < WINDOW_MS);

  if (recent.length >= MAX_REQUESTS) {
    return false; // Rate limited
  }

  recent.push(now);
  userRequests.set(userId, recent);
  return true;
}

// Usage in handler
bot.command("shell", async (ctx) => {
  const userId = ctx.from?.id.toString();

  if (!checkRateLimit(userId)) {
    await ctx.reply("⏳ Too many requests. Please wait.");
    return;
  }

  // Process command...
});
```

## Security Checklist

- [ ] Set `TELEGRAM_ALLOWED_USER_ID` to restrict access
- [ ] Never log sensitive environment variables
- [ ] Use `.env` files with `chmod 600`
- [ ] Validate and sanitize all user input
- [ ] Implement shell command allowlisting
- [ ] Add rate limiting for expensive operations
- [ ] Enable audit logging for security events
- [ ] Rotate API keys regularly
- [ ] Use HTTPS for all external API calls
- [ ] Implement session timeout
- [ ] Never expose stack traces to users

## Reference

- [Telegram Bot Security Best Practices](https://core.telegram.org/bots/security)
- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [Node.js Security Best Practices](https://nodejs.org/en/docs/guides/security/)
