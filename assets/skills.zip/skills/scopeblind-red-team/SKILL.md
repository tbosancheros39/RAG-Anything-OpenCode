---
name: scopeblind-red-team
description: >
  Policy benchmarking runner for MCP security policies. Runs attack suites
  against protect-mcp policy packs, produces signed receipts and badges.
---
