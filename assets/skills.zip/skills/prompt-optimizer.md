# Prompt Optimizer Skill

## Description
Specialized skill for optimizing AI prompts to achieve better results, reduce token usage, and improve response quality.

## Features
- Prompt analysis and refinement
- Token efficiency optimization
- Context window management
- Response quality improvement
- Multi-turn conversation optimization

## Usage
Use this skill when you need to:
- Optimize existing prompts for better results
- Reduce token usage while maintaining quality
- Structure complex queries effectively
- Improve AI response accuracy and relevance

## Techniques
- Chain-of-thought prompting
- Few-shot learning examples
- Clear instruction formatting
- Context management strategies
