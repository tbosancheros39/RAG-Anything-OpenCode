# Havn

A fast, configurable port scanner written in Rust with reasonable defaults. Lightweight, self-contained, and cross-platform.

## When to Use

- Quick network reconnaissance
- Lightweight scanning tool
- Cross-platform compatibility
- Docker-based scanning
- When you need a simple, no-frills scanner

## Features

- **Fast**: Async Tokio-based concurrent scanning
- **Lightweight**: <3MB binary, minimal dependencies
- **Configurable**: Customizable concurrency, timeouts, ports
- **Cross-platform**: Windows, macOS, Linux, Docker
- **Banner grabbing**: Extract service banners

## Installation

```bash
# Via cargo
cargo install havn

# Docker
docker run mrjackwills/havn
```

## Basic Usage

```bash
# Scan single host, default ports
havn 192.168.1.1

# Scan specific ports
havn 192.168.1.1 -p 22,80,443

# Scan port range
havn 192.168.1.1 -p 1-1000

# Scan all ports
havn 192.168.1.1 -a

# Custom concurrency
havn 192.168.1.1 -c 500

# Custom timeout
havn 192.168.1.1 -t 2000

# JSON output
havn 192.168.1.1 -j

# Verbose output
havn 192.168.1.1 -v
```

## Options

| Flag | Description | Default |
|------|-------------|---------|
| `-p` | Ports to scan | Common ports |
| `-a` | Scan all 65535 ports | false |
| `-c` | Concurrency level | 100 |
| `-t` | Timeout (ms) | 1000 |
| `-j` | JSON output | false |
| `-v` | Verbose | false |

## Example Commands

```bash
# Quick local scan
havn localhost

# Scan subnet for web servers
havn 192.168.1.0/24 -p 80,443,8080,8443

# Fast scan with high concurrency
havn 192.168.1.1 -c 1000 -t 500

# Export results
havn 192.168.1.1 -p 22,80,443 -j > results.json
```

## Notes

- No root required for TCP connect scans
- Good default settings for quick scans
- Smaller community than RustScan/Naabu
- Works well in Docker containers