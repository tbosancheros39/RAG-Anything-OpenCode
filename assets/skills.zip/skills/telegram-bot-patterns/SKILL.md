---
name: telegram-bot-patterns
description: Common Telegram bot patterns for TypeScript — command routing, middleware chains, keyboard menus, inline queries, chat moderation, and cross-platform compatibility. Use when building Telegram bots with grammY, Telegraf, or mtcute.
Covers: command handlers, reply keyboards, inline keyboards, callbacks, deep links, chat types (private/group/supergroup)
---

# Telegram Bot Patterns

## Overview

Essential patterns for building robust Telegram bots in TypeScript. These patterns work across grammY, Telegraf, and mtcute, with grammY-specific examples throughout.

## When to Activate

- Creating new command handlers (`/start`, `/help`, `/settings`)
- Building interactive menus with reply or inline keyboards
- Handling callback queries from inline buttons
- Implementing inline query handlers (`@botusername query`)
- Building group moderation bots
- Filtering messages by chat type (private/group/supergroup)
- Implementing deep links and start parameters

## Key Patterns

### Command Routing with Filters

```typescript
import { Bot, CommandContext, Context } from "grammy";

// Filter by chat type — only respond in private chats
bot.chatType("private").command("start", async (ctx: CommandContext<Context>) => {
    await ctx.reply("Hello! I'm a private bot.");
});

// Filter by chat type — only respond in groups
bot.chatType(["group", "supergroup"]).command("admin", async (ctx) => {
    await ctx.reply("Group admin command received.");
});

// Combine filters — specific command in specific chat type
bot.chatType("private").command("settings", async (ctx) => {
    await ctx.reply("Your settings menu here.");
});
```

### Middleware Chains

```typescript
import { Bot, NextFunction } from "grammy";

type MyContext = Context & {
    user?: { id: number; name: string };
};

// Middleware to load user session
async function loadUser(ctx: MyContext, next: NextFunction) {
    const userId = ctx.from?.id;
    if (userId) {
        ctx.user = await db.getUser(userId);
    }
    await next();
}

// Middleware to check admin privileges
async function requireAdmin(ctx: MyContext, next: NextFunction) {
    if (!ctx.user?.isAdmin) {
        await ctx.reply("⛔ Admin only.");
        return;
    }
    await next();
}

// Apply globally
bot.use(loadUser);

// Apply to specific command
bot.chatType("private").command("admin", requireAdmin, async (ctx) => {
    await ctx.reply("Welcome, admin!");
});
```

### Reply Keyboard Menu

```typescript
import { Bot, CommandContext, Context } from "grammy";

export function setupMenu(bot: Bot<Context>) {
    // Main menu keyboard
    const mainMenuKeyboard = {
        keyboard: [
            [{ text: "📊 Stats" }, { text: "⚙️ Settings" }],
            [{ text: "📈 History" }, { text: "❓ Help" }],
        ],
        resize_keyboard: true,
        one_time_keyboard: false,
    };

    bot.chatType("private").command("menu", async (ctx: CommandContext<Context>) => {
        await ctx.reply("Choose an option:", { reply_markup: mainMenuKeyboard });
    });

    // Handle text button clicks
    bot.chatType("private").on("message:text", async (ctx) => {
        const text = ctx.message.text;

        switch (text) {
            case "📊 Stats":
                await ctx.reply("Your stats: 100 commands, 5 sessions");
                break;
            case "⚙️ Settings":
                await ctx.reply("Settings menu coming soon");
                break;
            case "📈 History":
                await ctx.reply("Command history...");
                break;
            case "❓ Help":
                await ctx.reply("Help information...");
                break;
            default:
                await ctx.reply("Use /menu for the keyboard.");
        }
    });
}
```

### Inline Keyboard with Callbacks

```typescript
import { Bot, CallbackContext, Context } from "grammy";

export function setupCallbacks(bot: Bot<Context>) {
    // Inline keyboard with callback buttons
    const confirmKeyboard = {
        inline_keyboard: [
            [
                { text: "✅ Confirm", callback_data: "confirm_yes" },
                { text: "❌ Cancel", callback_data: "confirm_no" },
            ],
            [{ text: "🔗 View Details", callback_data: "view_details" }],
        ],
    };

    bot.chatType("private").command("confirm", async (ctx: CommandContext<Context>) => {
        await ctx.reply("Are you sure?", { reply_markup: confirmKeyboard });
    });

    // Handle callback queries
    bot.callbackQuery("confirm_yes", async (ctx: CallbackContext<Context>) => {
        await ctx.answerCallbackQuery("Confirmed!");
        await ctx.editMessageText("✅ Action confirmed!");
    });

    bot.callbackQuery("confirm_no", async (ctx: CallbackContext<Context>) => {
        await ctx.answerCallbackQuery("Cancelled", { show_alert: true });
        await ctx.editMessageText("❌ Action cancelled.");
    });

    bot.callbackQuery("view_details", async (ctx: CallbackContext<Context>) => {
        await ctx.answerCallbackQuery();
        await ctx.reply("📋 Detailed information here...");
    });

    // Dynamic callback with data pattern
    bot.callbackQuery(/^item_(\d+)$/, async (ctx) => {
        const itemId = ctx.match[1];
        await ctx.answerCallbackQuery(`Item #${itemId} selected`);
        await ctx.reply(`You selected item ${itemId}`);
    });
}
```

### Inline Query Handler

```typescript
import { Bot, InlineQueryContext, Context } from "grammy";

export function setupInlineQueries(bot: Bot<Context>) {
    bot.on("inline_query", async (ctx: InlineQueryContext<Context>) => {
        const query = ctx.inlineQuery.query;
        const userId = ctx.from.id;

        if (!query) {
            await ctx.answerInlineQuery([]);
            return;
        }

        // Build results
        const results = [
            {
                type: "article" as const,
                id: "1",
                title: "Search Result 1",
                description: `Result for: ${query}`,
                input_message_content: {
                    message_text: `You searched for: ${query}`,
                },
            },
            {
                type: "article" as const,
                id: "2",
                title: "Search Result 2",
                description: `Another result: ${query}`,
                input_message_content: {
                    message_text: `Alternative: ${query}`,
                },
            },
        ];

        await ctx.answerInlineQuery(results, {
            cache_time: 300,
            is_personal: false,
        });
    });
}
```

### Deep Links with Start Parameter

```typescript
import { Bot, CommandContext, Context } from "gramy";

export function setupDeepLinks(bot: Bot<Context>) {
    // Handle /start with parameters
    bot.chatType("private").command("start", async (ctx: CommandContext<Context>) => {
        const startParam = ctx.match;

        if (startParam) {
            // Parse deep link (format: "action_subaction" or "ref_userid")
            const [action, value] = startParam.split("_");

            switch (action) {
                case "ref":
                    // Referral link — credit referrer
                    await ctx.reply(`🙏 Thanks for joining! You were referred by ${value}`);
                    await db.creditReferrer(Number(value));
                    break;
                case "group":
                    // Invite to group
                    await ctx.reply(`📢 Inviting you to group: ${value}`);
                    break;
                default:
                    await ctx.reply(`🔗 Started with parameter: ${startParam}`);
            }
        } else {
            await ctx.reply("Welcome! Use /help for commands.");
        }
    });
}
```

## Common Pitfalls

1. **Filter order matters** — grammY processes filters in registration order. More specific filters should be registered before general ones.

2. **Callback query must be answered** — always call `ctx.answerCallbackQuery()` to remove loading state. Use `{ show_alert: true }` for alert dialogs.

3. **Chat type filtering** — commands registered without `chatType` filter respond in ALL chat types. Use explicit filtering for chat-specific behavior.

4. **Callback data length** — Telegram limits callback_data to 64 bytes. Use short, encoded keys or hash the data if needed.

5. **Group rate limits** — Telegram imposes stricter rate limits in groups (~1 msg/sec). Always implement flood wait handling.

## Reference

- [Telegram Bot API - Getting Started](https://core.telegram.org/bots/api#getting-started)
- [gramY Documentation](https://grammy.dev/)
- [Telegraf Documentation](https://telegraf.js.org/)
- [mtcute Documentation](https://mtcute.js.org/)
