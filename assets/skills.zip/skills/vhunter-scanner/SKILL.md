---
name: vhunter-scanner
description: Professional-grade async vulnerability assessment framework for bug bounty and pentesting. Covers XSS, SQLi, SSRF, RCE, SSTI, GraphQL, Cloud Misconfig, and 30+ CVE templates with WAF evasion and OOB callbacks. Use when needing high-throughput scanning with intelligent noise reduction.
---

# vhunter v6.0 - Professional Vulnerability Assessment Framework

## When to Use

- **Bug bounty hunting** - High-throughput scanning for bounty programs
- **Professional pentesting** - Async-first framework for large targets
- **WAF evasion** - Bypass web application firewalls
- **OOB vulnerability detection** - Blind SSRF, SQLi, RCE detection
- **Cloud misconfig** - AWS, GCP, Azure vulnerability scanning

## Features

- **Async-first**: Python asyncio + aiohttp for high throughput
- **30+ CVE templates**: Log4Shell, Spring4Shell, Drupalgeddon2, Shellshock, etc.
- **WAF evasion**: 10-UA rotation, payload mutation engine
- **OOB callbacks**: DNS, HTTP out-of-band for blind vulns
- **Cloud misconfig**: AWS S3, Firebase, GCP Storage, Azure Blob, IMDS
- **Multi-format output**: HTML, JSON, Markdown, SARIF

## Installation

```bash
# Clone repository
git clone https://github.com/Lime27-Star/vhunter.git
cd vhunter

# Run in interactive mode (wizard)
python3 vhunter_v6.py

# CLI mode
python3 vhunter_v6.py -t https://example.com
```

## Usage

### Interactive Mode (Wizard)
```bash
python3 vhunter_v6.py
# Follow guided wizard for scan configuration
```

### CLI Mode
```bash
# Full scan
python3 vhunter_v6.py -t https://example.com

# Quick recon
python3 vhunter_v6.py -t https://example.com --modules recon

# Web vulns only
python3 vhunter_v6.py -t https://example.com --modules web

# Cloud + CVE only
python3 vhunter_v6.py -t https://example.com --modules cloud cve

# High-confidence findings only
python3 vhunter_v6.py -t https://example.com --min-confidence 70

# Custom output
python3 vhunter_v6.py -t https://example.com --output-dir ./results
```

## Integration with Systemv2.5

| Systemv2.5 Category | vhunter Capability |
|---------------------|-------------------|
| Web Vulnerability | XSS, SQLi, RCE, SSTI, XXE |
| Cloud Security | AWS S3, GCP, Azure misconfig |
| CVE Research | 30+ CVE templates |
| Network Scanning | Port discovery + vuln detection |
| Bug Bounty | High-throughput automated scanning |

## Module Coverage

| Module | Capabilities |
|--------|-------------|
| **XSS** | DOM, reflected, stored, blind XSS |
| **SQLi** | Error-based, blind, UNION, time-based |
| **SSRF** | Internal services, cloud metadata |
| **RCE** | Command injection, deserialization |
| **SSTI** | 10 template engines (Jinja, Twig, etc.) |
| **GraphQL** | Introspection, injection |
| **Cloud** | S3 buckets, Firebase, GCP metadata |
| **CVE** | Log4Shell, Spring4Shell, Drupalgeddon2 |

## WAF Evasion Techniques

- Case alternation
- SQL comment injection
- URL/double-URL encoding
- MySQL versioned comments
- User-Agent rotation (10 real browser UAs)

## Output Formats

```bash
# HTML report
--format html

# JSON for automation
--format json

# Markdown for documentation
--format markdown

# SARIF for GitHub Code Scanning
--format sarif
```