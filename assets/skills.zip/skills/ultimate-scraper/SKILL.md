---
name: ultimate-scraper
description: 智能分级爬虫，支持6层递进策略（static→HTTP→browser→anti-detect→AI→visual），内置Camoufox反检测、CAPTCHA解决、代理轮换、指纹持久化、视觉提取。当用户需要抓取网页内容、绕过反爬保护、解析受保护页面时触发。
---

# Ultimate Web Scraper

## 快速启动
```bash
python scripts/scrape.py "https://example.com"
python scripts/scrape.py "URL" -e "Extract X" -o json
```

## 分级架构

| Tier | 模式 | 技术 | 适用场景 |
|------|------|------|----------|
| 0 | static | chompjs/extruct | __NEXT_DATA__, JSON-LD |
| 1 | http | curl_cffi | TLS指纹伪装 |
| 2 | browser | CloakBrowser/Patchright | 隐匿浏览器 + CAPTCHA解决 |
| 2.5 | agent | agent-browser | CLI自动化 + tracker拦截 |
| 3 | stealth | Camoufox | 完整反检测（Cloudflare绕过） |
| 4 | ai | Crawl4AI + LLM | AI驱动提取 |
| 5 | visual | Screenshot + Vision | 视觉LLM提取（绕过DOM检测） |

自动递进：Tier N失败 → 轮换代理 → 重试 → 递进到N+1。

## 决策树
```
简单页面 → python scripts/scrape.py "URL"
需要提取数据 → python scripts/scrape.py "URL" -e "Extract X" -o json
受保护站点 → python scripts/scrape.py "URL" -m stealth -g us
批量URL → python scripts/scrape.py --batch urls.jsonl -p 10
退出码1+NotFound → 页面不存在，无需操作
退出码2 → 需要高级代理/unlocker服务
```

## CLI选项

| 参数 | 描述 | 默认值 |
|------|--------|--------|
| `-m MODE` | auto/static/http/browser/agent/stealth/ai/visual | auto |
| `-o FMT` | markdown/json/raw | markdown |
| `-e PROMPT` | 自然语言提取指令 | |
| `-s JSON` | JSON Schema结构化提取 | |
| `--visual` | 视觉提取（截图+Vision LLM） | false |
| `-g GEO` | 代理地区（us, uk, de等） | |
| `--session NAME` | Cookie持久化的命名会话 | |
| `--max-tier N` | 限制递进层数（0-5） | 4 |
| `--parallel N` | 并发抓取数 | 5 |
| `--batch FILE` | 从文件读取URL（JSONL或文本） | |
| `--output-dir DIR` | 每结果写单独文件 | |
| `--checkpoint FILE` | 断点续传文件 | |
| `--actions JSON` | 浏览器动作数组 | |
| `--behavior-intensity N` | 行为模拟强度（0.5-2.0） | 1.0 |
| `--captcha-solve` | 强制尝试解决CAPTCHA | false |

## CAPTCHA解决
检测到CAPTCHA时（Tier 2/3）：
1. 检测类型（reCAPTCHA v2/v3、hCaptcha、Cloudflare Turnstile）
2. 从页面提取sitekey
3. 发送到CapSolver（AI，~5s）或2Captcha（人工，~30s）解决
4. 注入token到页面继续

需要 `CAPSOLVER_API_KEY` 或 `TWOCAPTCHA_API_KEY` 环境变量。

## 敏感站点模式
LinkedIn、X/Twitter、Facebook、Instagram、TikTok自动检测：
- 最小Tier 2（browser）
- 指纹轮换锁定
- 行为强度提升
- 更严格的速率限制

## 指纹持久化
每个域名一致的浏览器指纹：
- 同一浏览器/版本（不随机化）
- SQLite存储，链接到会话
- 阻塞或30+天后自动轮换
- 按地区市场占有率加权选择浏览器

## 示例

### 电商产品
```bash
python scripts/scrape.py "https://amazon.com/dp/B0ABC123" \
  -m stealth -g us \
  -e "Extract product name, price, rating, review count" -j
```

### 视觉提取（重度保护页面）
```bash
python scripts/scrape.py "https://protected-site.com/data" \
  --visual -e "Extract all prices and product names" -j
```

### 多页会话
```bash
python scripts/scrape.py "https://site.com/login" --session acct -m stealth \
  --actions '[{"type":"fill","selector":"#email","text":"user"},{"type":"click","selector":"#submit"}]'

python scripts/scrape.py "https://site.com/dashboard" --session acct -e "Extract user data" -j
```

### 批量处理+断点续传
```bash
python scripts/scrape.py --batch urls.jsonl \
  --output-stream results.jsonl \
  --checkpoint job1.json -p 10 -v
```

## 代理与API密钥

```bash
# 代理
export PROXY_HOST= PROXY_PORT= PROXY_USERNAME= PROXY_PASSWORD=

# AI提取
export LOCAL_LLM_URL=  # OpenAI兼容端点
export ZAI_API_KEY=
export ANTHROPIC_API_KEY=

# CAPTCHA解决
export CAPSOLVER_API_KEY=   # AI解决（更快）
export TWOCAPTCHA_API_KEY=  # 人工解决（备选）
```

## WSL2已知问题
Tier 3（Camoufox）在WSL2上不可靠：虚拟GPU产生Turnstile检测到的不一致指纹。建议在原生Linux或VM上运行。
