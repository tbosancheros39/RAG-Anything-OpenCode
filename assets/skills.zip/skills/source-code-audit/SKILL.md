---
name: source-code-audit
description: Static analysis, SAST, dependency scanning, and source code security review. Use when auditing application source code for vulnerabilities.
---

# Source Code Security Auditing

Static analysis and security review of application source code.

## When to Use

- Source code review during pentests
- SAST during security assessments
- Finding hardcoded secrets
- Dependency vulnerability scanning
- Secure code review

## Techniques

### Hardcoded Secrets
- API keys, tokens, passwords
- AWS keys, private keys
- Database credentials
- Encryption keys

### Code Vulnerabilities
- SQL injection in raw queries
- Command injection
- Path traversal
- XXE in XML parsing
- Deserialization usage
- Unsafe deserialization

### Dependency Analysis
- Outdated libraries with CVEs
- Known vulnerable components
- Supply chain attacks

## Grep Patterns

| Pattern | Language | Finding |
|---------|----------|---------|
| `password\s*=\s*["']` | All | Hardcoded passwords |
| `api[_-]?key` | All | API keys |
| `aws_access_key` | Python | AWS credentials |
| `eval\s*\(` | PHP/JS | Code injection |
| `exec\s*\(` | PHP | Command execution |
| `pickle\.load` | Python | Unsafe deserialization |
| `yaml\.load` | Python | Unsafe YAML |
| `process\.env` | JS/Node | Environment secrets |
| `ConnectionString` | C# | Database connections |
| `\.innerHTML` | JS | XSS vulnerability |

## Workflow

### Phase 1: Discovery
```
1. Clone target code
2. Map structure and tech stack
3. Identify entry points
4. Find sensitive functions
```

### Phase 2: Analysis
```
1. Search for known patterns
2. Analyze authentication/authorization
3. Review data flow
4. Check dependency versions
```

### Phase 3: Exploitation
```
1. Verify findings with PoC
2. Test in runtime if possible
3. Document impact and severity
```

## Tools

- `grep` / `ripgrep` — Pattern matching
- `bandit` — Python SAST
- `semgrep` — Multi-language SAST
- `trufflehog` — Secret scanning
- `npm audit` / `yarn audit` — JS dependencies
- `safety` — Python dependencies
- `OWASP Dependency-Check` — Java/.NET

## Output

- `audit/code-findings.md` — Findings with locations
- `audit/secrets.txt` — Exposed secrets
- `audit/dependencies.json` — Vulnerable deps