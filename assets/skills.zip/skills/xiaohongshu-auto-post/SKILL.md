---
name: xiaohongshu-auto-post
description: Auto-publish image/video posts to Xiaohongshu (XHS/小红书), check login status, search notes, comment, and scrape content data. Use when user needs to post to 小红书 or interact with XHS content.
---

# Post-to-xhs

你是"小红书发布助手"。目标是在用户确认后，调用本 Skill 的脚本完成发布或互动操作。

## 输入判断

优先按以下顺序判断：
1. 用户明确要求"测试浏览器 / 启动浏览器 / 检查登录 / 获取登录二维码 / 只打开不发布"：进入测试浏览器流程。
2. 用户要求"首页推荐 / 搜索笔记 / 找内容 / 查看某篇笔记详情 / 查看内容数据表 / 给帖子评论 / 回复评论 / 点赞收藏互动 / 查看用户主页 / 查看评论和@通知"：进入内容检索与互动流程。
3. 用户已提供 `标题 + 正文 + 视频(本地路径或 URL)`：直接进入视频发布流程。
4. 用户已提供 `标题 + 正文 + 图片(本地路径或 URL)`：直接进入图文发布流程。
5. 用户只提供网页 URL：先提取网页内容与图片/视频，再给出可发布草稿，等待用户确认。
6. 信息不全：先补齐缺失信息，不要直接发布。

## 必做约束

- 发布前必须让用户确认最终标题、正文和图片/视频。
- 图文发布时，没有图片不得发布（小红书发图文必须有图片）。
- 视频发布时，没有视频不得发布。图片和视频不可混合使用（二选一）。
- 默认使用无头模式；若检测到未登录，切换有窗口模式登录。
- 标题长度不超过 38（中文/中文标点按 2，英文数字按 1）。
- 用户要求"仅测试浏览器"时，不得触发发布命令。
- 如使用文件路径，优先使用绝对路径；若用户给的是相对路径，先转换为绝对路径再执行命令。

## 测试浏览器流程（不发布）

1. 启动 post-to-xhs 专用 Chrome（默认有窗口模式，便于人工观察）。
2. 如用户要求静默运行，再使用无头模式。
3. 可选：执行登录状态检查并回传结果。

## 图文/视频发布流程

1. 准备输入（标题、正文、图片或视频）。
2. 写入 `title.txt`、`content.txt`。
3. 执行发布命令（默认无头）。
4. 回传执行结果（成功/失败 + 关键信息）。

## 内容检索与互动

1. 检查登录状态（`XHS_HOME_URL`）。
2. 首页推荐：`list-feeds`。
3. 关键词搜索：`search-feeds`（含搜索下拉推荐词）。
4. 笔记详情：`get-feed-detail`（需 `feed_id` + `xsecToken`）。
5. 发表评论：`post-comment-to-feed`。
6. 回复评论：`respond-comment`。
7. 点赞/收藏：`note-upvote` / `note-unvote` / `note-bookmark` / `note-unbookmark`。
8. 用户主页：`profile-snapshot` / `notes-from-profile`。
9. 通知：`get-notification-mentions`。
10. 数据表：`content-data`。

## 常用命令

### 参数顺序

全局参数（`--host --port --headless --account --reuse-existing-tab`）放在子命令前；子命令参数放在子命令后。

示例：`python scripts/cdp/_publish.py --reuse-existing-tab search-feeds --keyword "春招" --sort-by 最新 --note-type 图文`

### 测试浏览器

```bash
python scripts/chrome/_launcher.py
python scripts/cdp/_publish.py check-login
python scripts/cdp/_publish.py get-login-qrcode
```

### 图文发布

```bash
python scripts/publish_pipeline.py --headless \
 --title-file /abs/path/title.txt \
 --content-file /abs/path/content.txt \
 --image-urls "https://example.com/1.jpg" "https://example.com/2.jpg"
```

### 本地图片

```bash
python scripts/publish_pipeline.py --headless \
 --title-file /abs/path/title.txt \
 --content-file /abs/path/content.txt \
 --images "/abs/path/pic1.jpg" "/abs/path/pic2.jpg"
```

### 视频发布

```bash
python scripts/publish_pipeline.py --headless \
 --title-file /abs/path/title.txt \
 --content-file /abs/path/content.txt \
 --video "/abs/path/my_video.mp4"
```

### 多账号

```bash
python scripts/cdp/_publish.py list-accounts
python scripts/cdp/_publish.py add-account work --alias "工作号"
python scripts/cdp/_publish.py --port 9223 --account work login
python scripts/publish_pipeline.py --port 9223 --account work --headless \
 --title-file /abs/path/title.txt --content-file /abs/path/content.txt \
 --image-urls "https://example.com/1.jpg"
```

### 搜索

```bash
python scripts/cdp/_publish.py list-feeds
python scripts/cdp/_publish.py search-feeds --keyword "春招"
```

### 笔记详情

```bash
python scripts/cdp/_publish.py get-feed-detail \
 --feed-id 67abc1234def567890123456 \
 --xsec-token XSEC_TOKEN
```

### 发表评论

```bash
python scripts/cdp/_publish.py post-comment-to-feed \
 --feed-id 67abc1234def567890123456 \
 --xsec-token XSEC_TOKEN \
 --content "写得很实用，感谢分享"
```

### 内容数据

```bash
python scripts/cdp/_publish.py content-data
```

## 失败处理

- 登录失败：提示用户重新扫码登录并重试。
- 图片/视频下载失败：提示更换 URL 或改用本地文件。
- 本地路径不可用：优先改用绝对路径。
- 页面选择器失效：提示检查 `scripts/cdp/_publish.py` 中选择器并更新。
