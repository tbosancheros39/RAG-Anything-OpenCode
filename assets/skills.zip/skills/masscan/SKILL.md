# Masscan

TCP-only port scanner — the fastest for large-scale scans. Uses SYN flood technique.

## When to Use

- Mass scanning entire CIDR ranges
- Internet-wide reconnaissance
- When raw speed is priority
- Rate-limited scanning to avoid detection

## Features

- **Speed**: Up to 10 million packets/second
- **TCP-only**: Uses SYN packets (requires root)
- **Rate Control**: Adjustable packets/second
- **Banner Grabbing**: Extract service banners
- **Export**: JSON, XML, binary formats

## Installation

```bash
# From source (recommended)
git clone https://github.com/robertdavidgraham/masscan.git
cd masscan && make

# Package managers
sudo apt install masscan  # Debian/Ubuntu
brew install masscan       # macOS
```

## Basic Usage

```bash
# Quick scan 1000 ports on single IP
masscan -p1-1000 192.168.1.1

# Scan all ports, rate limited
masscan -p1-65535 192.168.1.1 --rate 1000

# Scan entire subnet
masscan 192.168.1.0/24 -p80,443 --rate 10000

# Banner grabbing
masscan 192.168.1.1 -p1-1000 --banners

# Output to file
masscan 192.168.1.0/24 -p80,443 -oJ results.json
```

## Rate Limiting

| Rate | Use Case |
|------|----------|
| 100 | Stealthy, avoids detection |
| 1000 | Default, balanced |
| 10000 | Fast, may trigger IDS |
| 100000 | Very fast, requires powerful host |

## Common Commands

```bash
# Full port scan, 1000 pps
masscan -p1-65535 192.168.1.1 --rate 1000

# Top 100 ports, fast
masscan -p- 192.168.1.1 --rate 5000

# Multiple ports
masscan -p22,80,443,3306,5432,6379 192.168.1.0/24

# Exclude certain IPs
masscan 192.168.0.0/16 -p80,443 --excludefile exclude.txt

# Custom timeout
masscan -p1-1000 192.168.1.1 --wait 0
```

## Output Formats

```bash
# JSON
masscan 192.168.1.1 -oJ output.json

# XML
masscan 192.168.1.1 -oX output.xml

# Greppable
masscan 192.168.1.1 -oG output.txt

# Binary (for processing)
masscan 192.168.1.1 -ob output.bin
```

## Tips

- Requires root for SYN scans
- Use `--wait 0` to reduce delays
- Adjust `--rate` to avoid network congestion
- Combine with Nmap for service detection on found ports
- Note: Only scans TCP (not UDP)