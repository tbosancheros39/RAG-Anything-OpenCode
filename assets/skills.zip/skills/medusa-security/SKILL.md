---
name: medusa-security
description: AI-first security scanner with 9,600+ detection rules for AI/ML, LLM applications, MCP servers, and supply chain attacks. Detects 200+ CVEs including React2Shell, Log4Shell, LangChain RCE. Use when scanning repositories for AI-specific vulnerabilities and supply chain threats.
---

# MEDUSA - AI-First Security Scanner

## When to Use

- **AI/ML security** - Scan for AI-specific vulnerabilities
- **Supply chain attacks** - Detect repo poisoning, Clinejection, IDEsaster
- **MCP server security** - Scan for MCP vulnerabilities
- **CVE detection** - 200+ CVE patterns including critical ones
- **Source code auditing** - Automated vulnerability scanning

## Features

- **9,600+ detection rules** - Comprehensive rule database
- **76 specialized analyzers** - Different vulnerability categories
- **AI supply chain detection**: Clinejection, CurXecute, IDEsaster, Prompt injection
- **MCP security**: 91 agent protocol rules (UCP, AP2, ACP)
- **133 critical CVEs**: LangChain, PyTorch, MCP, Log4Shell, XZ Utils
- **Python, JavaScript, Go, Java** analysis
- **Cross-platform**: Windows, macOS, Linux

## Installation

```bash
pip install medusa-security

# Update to latest
pip install medusa-security --upgrade
```

## Usage

```bash
# Scan local repository
medusa scan /path/to/codebase

# Scan GitHub repository
medusa scan --git user/repo

# Quick scan with JSON output
medusa scan ./project --format json

# Full scan with all analyzers
medusa scan ./project --full
```

## Detection Capabilities

### AI/ML Vulnerabilities
- Prompt injection in training data
- Dataset poisoning detection
- Model extraction vulnerabilities
- LLM tool abuse

### Supply Chain Attacks
- Clinejection (AI editor config poisoning)
- CurXecute (cursor rule injection)
- IDEsaster (IDE configuration attacks)
- Malicious dependencies

### CVE Detection
- React2Shell (CVE-2024-XXXX)
- Log4Shell (CVE-2021-44228)
- LangChain RCE
- MCP-Remote RCE
- XZ Utils backdoor

## Integration with Systemv2.5

| Systemv2.5 Category | MEDUSA Capability |
|---------------------|-------------------|
| AI Threat Testing | Prompt injection, model extraction |
| Source Code Audit | Automated SAST for AI apps |
| Supply Chain Security | Repo poisoning detection |
| CVE Research | 200+ CVE patterns |

## Output

```json
{
  "tool": "medusa-security",
  "timestamp": "2026-04-01",
  "findings": [
    {
      "severity": "critical",
      "cwe": "CWE-94",
      "description": "Code Injection in LangChain",
      "file": "app.py",
      "line": 42
    }
  ]
}
```