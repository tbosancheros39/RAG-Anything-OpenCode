---
name: skill-creator
description: Create, modify, and improve skills for OpenCode. Use when users want to create a skill from scratch, edit or optimize an existing skill, convert skills from Claude Code (openclaw) to OpenCode format, or improve skill descriptions for better triggering accuracy.
---

# Skill Creator

A skill for creating new skills and iteratively improving them for OpenCode.

## When to Activate

- User mentions "create skill", "make a skill", "skill creator", or "write a skill"
- User wants to convert a Claude Code/openclaw skill to OpenCode
- User wants to improve an existing skill's triggering or content
- User says "turn this into a skill" or similar

## Core Concept: OpenCode vs OpenClaw Skill Format

The only difference between OpenCode and Claude Code (openclaw) skills:

| Field | Claude Code | OpenCode |
|-------|-------------|----------|
| `name` | Required | Required |
| `description` | Required | Required |
| `tools` | **Supported** | **Not supported** |

OpenCode does NOT have model parameter configuration. Skills only need `description` and `name`.

## The Skill Creation Process

1. **Capture Intent** — Understand what the skill should do and when it should trigger
2. **Interview** — Ask about edge cases, inputs, outputs, success criteria
3. **Write** — Draft the SKILL.md with frontmatter and content
4. **Test** — Create test prompts and verify the skill works
5. **Improve** — Iterate based on feedback
6. **Deploy** — Save to the skills directory

## Step 1: Capture Intent

Ask the user:
1. What should this skill enable OpenCode to do?
2. When should this skill trigger? (what phrases/contexts)
3. What's the expected output format?
4. Should test cases be created?

## Step 2: Interview and Research

Ask questions about:
- Edge cases and special scenarios
- Input/output formats
- Example files or references
- Success criteria
- Dependencies or required tools

## Step 3: Write the SKILL.md

### Skill File Structure

```
skill-name/
└── SKILL.md   (required, capitalized)
```

### Frontmatter Schema

```yaml
---
name: skill-name
description: One-line description of when to trigger and what it does
---
```

### Body Structure

```markdown
# Skill Name

Brief description of the skill.

## When to Activate

- Trigger condition 1
- Trigger condition 2

## Core Concepts

Key concepts and how they work.

## Workflow

Step-by-step instructions.

## Examples

Example usage.
```

## Step 4: Creating Test Cases

Create 2-3 realistic test prompts:

```json
{
  "skill_name": "example-skill",
  "evals": [
    {
      "id": 1,
      "prompt": "User's realistic task prompt",
      "expected_output": "Description of expected result"
    }
  ]
}
```

Test prompts should be things a real user would actually say.

## Step 5: Testing the Skill

1. Save the skill to `~/.config/opencode/skills/<skill-name>/SKILL.md`
2. Restart OpenCode or reload skills
3. Run the test prompts to verify triggering
4. Check if outputs match expectations

## Step 6: Improving the Skill

Based on test results:
- Generalize if the skill is too narrow
- Add specificity if triggering on wrong things
- Remove parts that aren't working
- Add examples for clarity
- Explain the WHY behind instructions

## Converting Claude Code Skills to OpenCode

When porting a skill from Claude Code:

### Before (Claude Code format)
```yaml
---
name: my-skill
description: Does something useful
---
```

### After (OpenCode format)
```yaml
---
name: my-skill
description: Does something useful
---
```

**Changes:**
1. Remove `tools` field entirely
2. Keep `name` and `description`
3. Everything else stays the same

## Skill Quality Checklist

- [ ] Frontmatter has `name` and `description`
- [ ] No `tools` field (OpenCode doesn't support it)
- [ ] SKILL.md is in the correct directory
- [ ] Directory name matches `name` in frontmatter
- [ ] Description is 1-2 sentences, clear and actionable
- [ ] "When to Activate" covers common invocation phrases
- [ ] Content has actionable steps
- [ ] Examples provided where helpful

## Common Issues

### Skill not triggering
- Check description is specific enough
- Verify directory name matches `name` field
- Ensure SKILL.md is capitalized
- Try different invocation phrases

### Wrong skill invoked
- Be more specific in skill description
- Rename skill to be more distinctive
- Use consistent naming (kebab-case)

### Skill works in Claude Code but not OpenCode
- Remove any `tools` field from frontmatter
- OpenCode doesn't support model parameters

## Skill Directories

| Platform | Path |
|----------|------|
| Linux/macOS | `~/.config/opencode/skills/` |
| Windows | `%APPDATA%/opencode/skills/` |
| Project-level | `.opencode/skills/` |

## Pro Tips

- Use "When to Activate" section to cover various invocation styles
- Make descriptions slightly "pushy" to encourage proper triggering
- Keep SKILL.md under 500 lines
- Include concrete examples
- Explain the WHY behind instructions, not just MUSTs
- Use progressive disclosure: metadata first, then details
