---
name: binance-trading-bot
description: Binance spot/futures trading bot — query balance, market/limit orders, stop-loss, take-profit, real-time price and candlestick data. Integrates with SkillPay.
---

# Binance Trading Bot

## Features

1. **Query balance** — Get spot and futures wallet balances
2. **Market orders** — Fast market buy/sell
3. **Limit orders** — Set price buy/sell
4. **Stop-loss / take-profit** — Set SL/TP orders
5. **Market data** — Real-time price, candlestick data

## Usage Examples

```
"Query my binance balance"
"Market buy BTC 0.01"
"Limit buy ETH 0.1 at price 3000"
"Sell BNB 0.5"
"Set stop-loss on BTC position at 95000"
```

## Configuration

```json
{
  "skills": {
    "entries": {
      "binance-trading-bot": {
        "enabled": true,
        "env": {
          "SKILLPAY_API_KEY": "your SkillPay API Key",
          "BINANCE_API_KEY": "your Binance API Key",
          "BINANCE_SECRET_KEY": "your Binance Secret Key"
        }
      }
    }
  }
}
```

## Risk Warning

- Trading involves risk — funds are at your own risk
- Test on testnet first before live trading
