# Shodan

Search engine for internet-connected devices. Find exposed servers, IoT, ICS, and network infrastructure worldwide.

## When to Use

- Finding exposed services on the internet
- Searching for vulnerable devices
- Bug bounty reconnaissance
- Attack surface mapping
- Finding specific technologies (nginx, Apache, etc.)

## Features

- **Largest Database**: 15B+ indexed devices across all ports/protocols
- **Powerful Queries**: Filter by org, ASN, geography, CVE, product, banner
- **Monitor**: Alerts on new exposures of your infrastructure
- **API**: Programmatic access to all data
- **CLI**: Command-line interface for automation

## Installation

```bash
# CLI via pip
pip install shodan

# Docker
docker pull bees/whitebeam-shodan
```

## Basic Usage

```bash
# Search for specific product
shodan search "nginx 1.0"

# Find vulnerable servers
shodan search "vuln:cve-2021-44228"

# Host information
shodan host 192.168.1.1

# Count results
shodan count "apache"

# Download results
shodan download results.json "product:nginx"
```

## Query Examples

| Query | Description |
|-------|-------------|
| `nginx` | All nginx servers |
| `product:Apache` | Apache servers |
| `city:London` | Devices in London |
| `org:"Google"` | Google's network |
| `asn:AS15169` | Google ASN |
| `port:22` | SSH servers |
| `vuln:CVE-2021-44228` | Log4Shell vulnerable |
| `has_screenshot:true` | With screenshots |
| `http.title:"Login"` | Login pages |
| `ssl:"google.com"` | Google SSL certs |

## Filters

| Filter | Description | Example |
|--------|-------------|---------|
| `net` | IP range | `net:192.168.0.0/16` |
| `org` | Organization | `org:"Google"` |
| `asn` | Autonomous System | `asn:AS15169` |
| `port` | Specific port | `port:22` |
| `product` | Software product | `product:nginx` |
| `version` | Software version | `version:1.20` |
| `country` | Country code | `country:US` |
| `city` | City name | `city:"New York"` |
| `vuln` | CVE ID | `vuln:CVE-2021-44228` |

## API Usage

```python
import shodan

api = shodan.APIKey('YOUR_API_KEY')

# Search
results = api.search('nginx')

# Get host info
host = api.host('192.168.1.1')

# Count
count = api.count('apache')
```

## CLI Examples

```bash
# Scan your network for exposure
shodan scan --rate 1000 192.168.1.0/24

# Monitor your ASN
shodan monitor add AS12345

# Get ISP info
shodan info

# Check exploit availability
shodan exploit cve-2021-44228
```

## Important Notes

- Free tier is severely limited — paid membership recommended
- Scan freshness varies by target
- No built-in threat scoring — requires analyst interpretation
- Comply with Shodan Terms of Service