---
name: wshawk-websocket
description: Open-source toolkit for WebSocket security testing and stateful attack validation. Combines CLI scanner, web dashboard, and browser companion for detecting SQLi, XSS, XXE, SSRF in WebSocket connections. Use when testing WebSocket endpoints for vulnerabilities.
---

# WSHawk - WebSocket Security Testing Toolkit

## When to Use

- **WebSocket testing** - Security assessment of WebSocket endpoints
- **Stateful attacks** - Bidirectional vulnerability testing
- **Real-time dashboard** - Visual monitoring of testing progress
- **OOB vulnerability detection** - SSRF, XXE via out-of-band callbacks

## Features

- **CLI scanner** - Command-line WebSocket testing
- **Web dashboard** - Visual interface for scans
- **Desktop app** - Electron-based workspace
- **Browser companion** - Extension for live testing
- **Blind vulnerability detection** - OAST callbacks for XXE, SSRF
- **CVSS v3.1 scoring** - Industry-standard severity ratings

## Installation

```bash
# Via pip
pip install wshawk

# Or build from source
git clone https://github.com/regaan/wshawk.git
cd wshawk
pip install -r requirements.txt

# Run
wshawk
```

## Usage

### CLI Mode
```bash
# Basic WebSocket scan
wshawk scan wss://target.com/ws

# With authentication
wshawk scan wss://target.com/ws -H "Authorization: Bearer token"

# Full test with all payloads
wshawk deep wss://target.com/ws
```

### Dashboard
```bash
# Start web interface
wshawk web

# Open browser to http://localhost:5000
```

## Vulnerability Detection

| Category | Technique |
|----------|-----------|
| **SQL Injection** | Error-based, time-based (SLEEP/WAITFOR), boolean-based blind |
| **Cross-Site Scripting (XSS)** | Reflection analysis, context detection, DOM sink |
| **Command Injection** | Timing attacks, command chaining, OOB detection |
| **XML External Entity (XXE)** | Entity expansion, OAST callback detection |
| **Server-Side Request Forgery (SSRF)** | Internal IP probing, cloud metadata access |
| **NoSQL Injection** | MongoDB operator injection ($gt, $ne, $regex) |
| **Path Traversal / LFI** | File content markers, encoding bypass |

## Integration with Systemv2.5

| Systemv2.5 Category | WSHawk Capability |
|---------------------|-------------------|
| Web Testing | WebSocket-specific vulnerability detection |
| API Security | Real-time API testing |
| XSS Testing | WebSocket XSS discovery |
| SSRF Testing | WebSocket-based SSRF |

## HTTP Security Tools Included

- **HTTP Fuzzer**: Parameter fuzzing with markers
- **Directory Scanner**: Path brute-forcing
- **Automated Scanner**: Multi-phase orchestrator
- **Security Header Analyzer**: HSTS, CSP, CORS
- **WAF Detector**: 15+ WAF fingerprinting
- **CORS Tester**: 6 attack patterns