---
name: opencli-multibot
description: CLI工具通过Chrome登录态与16个内容/社交平台交互（B站、知乎、Twitter/X、微博、小红书、YouTube、Reddit、HackerNews、雪球等）。当用户需要浏览、搜索、获取热门内容、发帖、读取消息时触发。
---

# opencli - 多平台社交内容CLI

## 基本语法
```bash
opencli <site> <command> [--option value] [-f json]
```

通用参数：`-f json`（机器可读输出）、`--limit N`（结果数量）

## 快速示例

### 读取/浏览
```bash
opencli bilibili hot --limit 10 -f json
opencli zhihu hot -f json
opencli weibo hot -f json
opencli twitter timeline -f json
opencli hackernews top --limit 20 -f json
opencli reddit hot -f json
opencli xiaohongshu feed -f json
```

### 搜索
```bash
opencli bilibili search --keyword "AI" -f json
opencli zhihu search --keyword "大模型" -f json
opencli twitter search --query "claude AI" -f json
opencli youtube search --query "LLM tutorial" -f json
opencli boss search --query "AI工程师" --city "上海" -f json
```

### 写操作
```bash
opencli twitter post --text "Hello from CLI!"
opencli twitter reply --url "https://x.com/.../status/123" --text "Great post!"
opencli twitter like --url "https://x.com/.../status/123"
```

### 个人数据
```bash
opencli bilibili history -f json
opencli twitter bookmarks -f json
opencli xueqiu watchlist -f json
```

## 输出格式规则
显示结果时必须包含：原始标题 + 中文翻译 + 可点击链接，分列显示。
不使用 `[title](url)` 格式，用 `[🔗](url)` 紧凑格式。

## Fallback策略

opencli不支持某平台时，直接使用Playwright MCP：
1. `browser_navigate` → 目标URL
2. `browser_snapshot` → 读取页面结构
3. 按需 `browser_click` / `browser_type` / `browser_scroll`

## 为新网站创建CLI
```bash
opencli <site> --help  → 报错？说明不支持
opencli generate <url>  →  尝试自动生成
# 失败则手动创建YAML模板
opencli <site> top -f json  →  验证输出
```
