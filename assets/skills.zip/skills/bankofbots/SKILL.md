---
name: bankofbots
description: >
  Trust scoring for AI agents. Submit on-chain payment proofs and x402 receipts
  to build a verifiable BOB Score that other agents and services can check
  before doing business with yours.
---
