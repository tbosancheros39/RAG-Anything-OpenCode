---
name: sse-streaming
description: Server-Sent Events (SSE) streaming patterns for TypeScript/Node.js. Covers SSE vs WebSocket, event streaming to Telegram, chunking for message limits, reconnection handling, and SSE in Express/Fastify. Use when implementing real-time streaming to Telegram clients or bot response streaming.
Reference: OpenCode Telegram Bot SSE pipeline (events.ts → Summary Aggregator → Telegram)
---

# Server-Sent Events (SSE) Streaming

## Overview

Server-Sent Events (SSE) is a unidirectional HTTP-based streaming protocol ideal for bot response streaming. Unlike WebSockets, SSE works over HTTP/2, automatically handles reconnection, and integrates naturally with existing web infrastructure.

## When to Activate

- Streaming AI model responses to Telegram users in real-time
- Implementing chunked output to bypass Telegram message limits
- Building real-time progress updates for long-running commands
- Integrating with OpenCode SSE pipeline (`events.ts → Summary Aggregator → Telegram`)
- Adding streaming to Express/Fastify endpoints
- Replacing polling with push-based updates

## Key Patterns

### SSE vs WebSocket

| Feature | SSE | WebSocket |
|---------|-----|-----------|
| Direction | Unidirectional (server→client) | Bidirectional |
| Protocol | HTTP/1.1+ / HTTP/2 | `ws://` / `wss://` |
| Reconnection | Automatic | Manual implementation |
| Browser support | Native (EventSource) | Universal (library) |
| Max connections | 6 per domain (HTTP/1.1) | Higher limit |
| Firewall friendly | Yes (uses HTTP) | May be blocked |
| Binary data | Base64 encoding needed | Native support |

**Use SSE when:** Server needs to push updates to Telegram, simple unidirectional flow, already using HTTP infrastructure.

**Use WebSocket when:** Bidirectional communication needed, binary data streaming, low-latency requirements.

### Basic SSE Endpoint (Express)

```typescript
import express, { Request, Response } from "express";

const app = express();

// SSE endpoint
app.get("/stream/:sessionId", (req: Request, res: Response) => {
    const { sessionId } = req.params;

    // Set SSE headers
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.setHeader("Transfer-Encoding", "chunked");
    res.flushHeaders();

    // Send initial connection message
    res.write("event: connected\n");
    res.write(`data: ${JSON.stringify({ sessionId })}\n\n`);

    // Simulate streaming events
    const interval = setInterval(() => {
        res.write(`data: ${JSON.stringify({ time: Date.now() })}\n\n`);

        // Detect client disconnect
        if (req.socket.destroyed) {
            clearInterval(interval);
        }
    }, 1000);

    // Cleanup on close
    req.on("close", () => {
        clearInterval(interval);
    });
});
```

### SSE Client with Reconnection (Node.js)

```typescript
import EventSource from "eventsource";

class SSEClient {
    private eventSource: EventSource | null = null;
    private reconnectAttempts = 0;
    private maxReconnectAttempts = 5;
    private reconnectDelay = 1000;

    constructor(
        private url: string,
        private handlers: {
            onMessage?: (data: unknown) => void;
            onError?: (error: Error) => void;
            onConnect?: () => void;
        }
    ) {}

    connect(): void {
        this.eventSource = new EventSource(this.url);

        this.eventSource.onopen = () => {
            this.reconnectAttempts = 0;
            this.handlers.onConnect?.();
        };

        this.eventSource.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                this.handlers.onMessage?.(data);
            } catch {
                this.handlers.onMessage?.(event.data);
            }
        };

        this.eventSource.onerror = (error) => {
            this.handlers.onError?.(new Error("SSE connection error"));

            // Automatic reconnection with exponential backoff
            if (this.reconnectAttempts < this.maxReconnectAttempts) {
                this.reconnectAttempts++;
                const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1);

                setTimeout(() => {
                    console.log(`Reconnecting... (attempt ${this.reconnectAttempts})`);
                    this.connect();
                }, delay);
            }
        };
    }

    disconnect(): void {
        this.eventSource?.close();
        this.eventSource = null;
    }
}

// Usage
const client = new SSEClient("http://localhost:4096/stream/session-123", {
    onMessage: (data) => console.log("Received:", data),
    onError: (err) => console.error("Error:", err),
    onConnect: () => console.log("Connected!"),
});

client.connect();
```

### Telegram Streaming with Chunking

```typescript
import { Bot, Context } from "grammy";
import { ChunkAggregator } from "./summary/aggregator";

const bot = new Bot(process.env.TELEGRAM_BOT_TOKEN!);

interface StreamState {
    aggregator: ChunkAggregator;
    messageId?: number;
    chatId?: number;
}

const activeStreams = new Map<string, StreamState>();

bot.command("stream", async (ctx) => {
    const chatId = ctx.chat.id;
    const sessionId = ctx.from?.id.toString() || "anonymous";

    // Initialize aggregator for this stream
    const aggregator = new ChunkAggregator({
        maxChunkSize: 4000, // Telegram message limit
        maxDelayMs: 2000,    // Flush after idle
    });

    const state: StreamState = {
        aggregator,
        chatId,
    };
    activeStreams.set(sessionId, state);

    // Send initial "streaming" message
    const msg = await ctx.reply("⏳ Processing...");
    state.messageId = msg.message_id;

    // Set up aggregator callbacks
    aggregator.on("chunk", async (chunk: string) => {
        if (!state.chatId || !state.messageId) return;

        try {
            // Edit existing message with new content
            await ctx.api.editMessageText(
                state.chatId,
                state.messageId,
                `📝 Output:\n\n<pre>${chunk}</pre>`,
                { parse_mode: "HTML" }
            );
        } catch (error) {
            // Message too old to edit — send as new message
            const newMsg = await ctx.reply(`📝:\n\n<pre>${chunk}</pre>`, {
                parse_mode: "HTML",
            });
            state.messageId = newMsg.message_id;
        }
    });

    aggregator.on("done", async (final: string) => {
        if (!state.chatId || !state.messageId) return;

        await ctx.api.editMessageText(
            state.chatId,
            state.messageId,
            `✅ Complete:\n\n<pre>${final}</pre>`,
            { parse_mode: "HTML" }
        );
        activeStreams.delete(sessionId);
    });
});

// Simulate streaming AI output
async function simulateStreaming(sessionId: string, output: string) {
    const state = activeStreams.get(sessionId);
    if (!state) return;

    // Stream word by word
    const words = output.split(" ");

    for (const word of words) {
        state.aggregator.push(word + " ");

        // Simulate network latency
        await new Promise((resolve) => setTimeout(resolve, 50));
    }

    state.aggregator.flush();
}
```

### Summary Aggregator Pattern (OpenCode Reference)

```typescript
// Summary Aggregator from OpenCode Telegram Bot
// Located: src/summary/formatter.ts

interface AggregatorOptions {
    maxChunkSize: number;   // Telegram message size limit (4000 chars)
    maxDelayMs: number;     // Force flush after idle milliseconds
    prefix?: string;        // Optional prefix for each chunk
}

class ChunkAggregator {
    private buffer = "";
    private lastFlush = Date.now();
    private flushTimer: NodeJS.Timeout | null = null;

    constructor(private options: AggregatorOptions) {}

    push(content: string): void {
        this.buffer += content;

        // Flush if buffer exceeds max size
        if (this.buffer.length >= this.options.maxChunkSize) {
            this.flush();
            return;
        }

        // Reset flush timer
        if (this.flushTimer) clearTimeout(this.flushTimer);
        this.flushTimer = setTimeout(() => this.flush(), this.options.maxDelayMs);
    }

    flush(): void {
        if (!this.buffer.trim()) return;

        const chunk = (this.options.prefix || "") + this.buffer;
        this.emit("chunk", chunk);
        this.buffer = "";
        this.lastFlush = Date.now();
    }

    // EventEmitter methods: on, emit
}

// SSE event format for Telegram
function formatSSEMessage(eventType: string, data: unknown): string {
    return `event: ${eventType}\ndata: ${JSON.stringify(data)}\n\n`;
}
```

### Fastify SSE Plugin

```typescript
import Fastify from "fastify";
import { fastifySSE } from "@fastify/sse";

const fastify = Fastify();

await fastify.register(fastifySSE);

// Stream endpoint
fastify.get("/stream/:id", async (request, reply) => {
    const { id } = request.params as { id: string };

    // Long-lived response
    reply.sse((send) => {
        // Send periodic updates
        const interval = setInterval(() => {
            send({
                event: "update",
                data: JSON.stringify({ id, time: Date.now() }),
            });
        }, 1000);

        // Cleanup on close
        request.raw.on("close", () => {
            clearInterval(interval);
        });
    });
});

// Named event example
fastify.get("/stream/events/:id", async (request, reply) => {
    const { id } = request.params as { id: string };

    reply.sse((send) => {
        send({ event: "message", data: "Hello" });
        send({ event: "message", data: "World" });
        send({ event: "done", data: "complete" });
    });
});
```

## Common Pitfalls

1. **Telegram message edit window** — You cannot edit messages older than 48 hours. After that, send new messages instead of editing.

2. **HTTP/1.1 connection limit** — Browsers limit to 6 concurrent SSE connections per domain. Use HTTP/2 or implement connection pooling.

3. **Proxy reconnection handling** — Some corporate proxies close idle connections. Send periodic keepalive comments: `res.write(": keepalive\n\n");`

4. **Chunk size accounting** — Telegram's limit is 4096 characters but HTML entities (`<`, `>`, `&`) count as extra. Use 4000 as safe limit for plain content.

5. **Memory leaks** — Always clear intervals/timers in `request.on("close")` handler to prevent memory leaks in long-lived connections.

## Reference

- [MDN: Server-Sent Events](https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events)
- [Telegram Bot API - Editing Messages](https://core.telegram.org/bots/api#editmessage)
- [OpenCode Telegram Bot - events.ts](https://github.com/grinev/opencode-telegram-bot)
- [Express SSE Example](https://expressjs.com/en/api.html#res.flush)
- [Fastify SSE Plugin](https://github.com/fastify/fastify-sse)
