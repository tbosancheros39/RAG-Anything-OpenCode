# PostgreSQL Setup on Linux

## Install & Configure

```bash
sudo apt install -y postgresql postgresql-contrib libpq-dev
sudo systemctl enable postgresql
sudo systemctl start postgresql
```

### Create database and user

```bash
sudo -u postgres psql
```

Inside psql:
```sql
CREATE USER botuser WITH PASSWORD 'strongpassword';
CREATE DATABASE botdb OWNER botuser;
GRANT ALL PRIVILEGES ON DATABASE botdb TO botuser;
\q
```

### .env update

```env
DATABASE_URL=postgresql+asyncpg://botuser:strongpassword@localhost/botdb
```

### Python deps

```bash
pip install asyncpg psycopg2-binary
```

## Connection Pooling

```python
from sqlalchemy.ext.asyncio import create_async_engine

engine = create_async_engine(
    DATABASE_URL,
    pool_size=10,
    max_overflow=20,
    pool_pre_ping=True,
)
```

## Migrations with Alembic

```bash
alembic init alembic
```

Edit `alembic/env.py`:
```python
from db.models import Base
target_metadata = Base.metadata
# also load DATABASE_URL from .env in env.py
```

```bash
alembic revision --autogenerate -m "initial"
alembic upgrade head
# Roll back:
alembic downgrade -1
```

## Useful psql commands

```bash
sudo -u postgres psql -d botdb
\dt                   # list tables
\d users              # describe table
SELECT count(*) FROM users;
\q
```

## Backup & restore

```bash
# Backup
pg_dump -U botuser botdb > backup.sql

# Restore
psql -U botuser botdb < backup.sql
```
