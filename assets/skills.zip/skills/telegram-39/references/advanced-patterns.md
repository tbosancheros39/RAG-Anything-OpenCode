# Advanced Bot Patterns

## Conversation State (FSM) — ConversationHandler

```python
from telegram.ext import ConversationHandler, CommandHandler, MessageHandler, filters

NAME, AGE, CONFIRM = range(3)

async def ask_name(update, context):
    await update.message.reply_text("What's your name?")
    return NAME

async def ask_age(update, context):
    context.user_data["name"] = update.message.text
    await update.message.reply_text("How old are you?")
    return AGE

async def confirm(update, context):
    context.user_data["age"] = update.message.text
    await update.message.reply_text(
        f"Name: {context.user_data['name']}, Age: {context.user_data['age']}. Save? (yes/no)"
    )
    return CONFIRM

async def done(update, context):
    await update.message.reply_text("Saved!")
    return ConversationHandler.END

conv_handler = ConversationHandler(
    entry_points=[CommandHandler("register", ask_name)],
    states={
        NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, ask_age)],
        AGE: [MessageHandler(filters.TEXT & ~filters.COMMAND, confirm)],
        CONFIRM: [MessageHandler(filters.Regex("^yes$"), done)],
    },
    fallbacks=[CommandHandler("cancel", lambda u, c: ConversationHandler.END)],
)
```

## Rate Limiting (per-user, in-memory)

```python
from collections import defaultdict
from time import time

user_last_request = defaultdict(float)
RATE_LIMIT_SECONDS = 2

async def rate_limited_handler(update, context):
    uid = update.effective_user.id
    now = time()
    if now - user_last_request[uid] < RATE_LIMIT_SECONDS:
        await update.message.reply_text("⏳ Slow down!")
        return
    user_last_request[uid] = now
    # proceed with handler logic
```

## Redis Caching (optional, reduces DB hits)

```bash
sudo apt install -y redis-server
sudo systemctl enable redis && sudo systemctl start redis
pip install redis[asyncio]
```

```python
import redis.asyncio as aioredis
redis = aioredis.from_url("redis://localhost")

async def get_user_cached(telegram_id: int):
    key = f"user:{telegram_id}"
    cached = await redis.get(key)
    if cached:
        return json.loads(cached)
    # fallback to DB, then cache result for 5 minutes
    user = await db_get_user(telegram_id)
    await redis.setex(key, 300, json.dumps(user))
    return user
```

## Broadcast to all users

```python
async def broadcast(context):
    async with AsyncSessionLocal() as session:
        users = await get_all_active_users(session)
    for user in users:
        try:
            await context.bot.send_message(chat_id=user.telegram_id, text="📢 Announcement!")
        except Exception:
            pass  # user may have blocked the bot
```

## Error handler

```python
async def error_handler(update, context):
    logger.error("Exception:", exc_info=context.error)
    if update and update.effective_message:
        await update.effective_message.reply_text("Something went wrong. Try again.")

app.add_error_handler(error_handler)
```
