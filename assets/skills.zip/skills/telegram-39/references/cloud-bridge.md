# Python Cloud Bridge Alternative

For non-Linux systems (Windows, macOS without Node.js), use this Python cloud bridge instead.

## When to Use

- Windows/macOS without Node.js 20+
- Quick test without full Linux setup
- Fallback if TypeScript setup fails

## Python Setup

```bash
# Python 3.10+
pip install python-telegram-bot httpx python-dotenv
```

## .env Configuration

```env
# Telegram Setup
TELEGRAM_BOT_TOKEN=your_bot_token_here
ADMIN_USER_ID=123456789

# OpenCode Go Cloud Setup
OPENCODE_CLOUD_URL=https://api.opencode.ai/v1
OPENCODE_API_KEY=your_opencode_go_key
OPENCODE_MODEL=zhipu/glm-5.0
```

## Cloud Bridge Bot (Python)

```python
import os
import logging
import httpx
from dotenv import load_dotenv
from telegram import Update
from telegram.ext import ApplicationBuilder, ContextTypes, MessageHandler, filters

load_dotenv()

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

async def error_handler(update, context):
    logger.error("Exception:", exc_info=context.error)
    if update and update.effective_message:
        await update.effective_message.reply_text("Cloud connection error.")

async def handle_cloud_task(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Security: Only respond to ADMIN_USER_ID
    if update.effective_user.id != int(os.getenv("ADMIN_USER_ID")):
        return

    user_message = update.message.text
    status_msg = await update.message.reply_text("Contacting OpenCode Go...")

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{os.getenv('OPENCODE_CLOUD_URL')}/chat/completions",
                headers={"Authorization": f"Bearer {os.getenv('OPENCODE_API_KEY')}"},
                json={
                    "model": os.getenv("OPENCODE_MODEL"),
                    "messages": [{"role": "user", "content": user_message}]
                },
                timeout=60.0
            )
            response.raise_for_status()
            data = response.json()
            answer = data['choices'][0]['message']['content']

            await status_msg.edit_text(answer)
    except Exception as e:
        logger.error(f"API Error: {e}")
        await status_msg.edit_text("Failed to reach OpenCode Cloud.")

if __name__ == '__main__':
    app = ApplicationBuilder().token(os.getenv("TELEGRAM_BOT_TOKEN")).build()

    # Polling for local home PC
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_cloud_task))
    app.add_error_handler(error_handler)

    print("Bot running locally and connected to OpenCode Cloud...")
    app.run_polling()
```

## Why This Works

1. **Polling Mode:** `app.run_polling()` reaches out to Telegram — no open ports needed
2. **No Local OpenCode:** `httpx` calls go directly to cloud API — PC is just a bridge
3. **24/7 Operation:** Leave the script running or use Docker

## Deployment Checklist

- [ ] Disable PC sleep mode
- [ ] Double-check `ADMIN_USER_ID` to prevent unauthorized usage
- [ ] Install deps: `pip install python-telegram-bot httpx python-dotenv`
