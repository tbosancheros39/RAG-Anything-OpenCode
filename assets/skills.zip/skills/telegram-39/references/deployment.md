# Deployment Guide (Linux VPS)

## Docker (recommended for portability)

### Dockerfile

```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .
CMD ["python", "main.py"]
```

### docker-compose.yml (bot + PostgreSQL)

```yaml
version: "3.9"
services:
  bot:
    build: .
    restart: always
    env_file: .env
    depends_on:
      - db
    volumes:
      - ./bot_data.db:/app/bot_data.db   # SQLite persistence

  db:
    image: postgres:15
    restart: always
    environment:
      POSTGRES_USER: botuser
      POSTGRES_PASSWORD: strongpassword
      POSTGRES_DB: botdb
    volumes:
      - pgdata:/var/lib/postgresql/data

volumes:
  pgdata:
```

```bash
# Install Docker on Ubuntu
sudo apt install -y docker.io docker-compose
sudo usermod -aG docker $USER   # then log out and back in

docker compose up -d
docker compose logs -f bot
docker compose down
```

## nginx Reverse Proxy (for webhooks)

```bash
sudo apt install -y nginx certbot python3-certbot-nginx
```

`/etc/nginx/sites-available/telegram-bot`:
```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:8443;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/telegram-bot /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# SSL with Let's Encrypt
sudo certbot --nginx -d yourdomain.com
```

## VPS Deployment Checklist

- [ ] SSH key auth enabled, password login disabled (`/etc/ssh/sshd_config`)
- [ ] UFW firewall configured: `sudo ufw allow 22 80 443 && sudo ufw enable`
- [ ] `.env` file has correct production tokens
- [ ] `bot_data.db` or PostgreSQL data volume is backed up regularly
- [ ] systemd service (or docker compose) set to restart on failure
- [ ] Logs monitored: `journalctl -u telegram-bot -f` or `docker compose logs -f`
- [ ] Certbot auto-renewal tested: `sudo certbot renew --dry-run`

## Keeping bot updated

```bash
git pull origin main
source venv/bin/activate
pip install -r requirements.txt
sudo systemctl restart telegram-bot
# or:
docker compose pull && docker compose up -d
```
