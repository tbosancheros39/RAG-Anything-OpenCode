# OpenCode Models & Providers

## Available Providers

| Provider | Description |
|---|---|
| `opencode` | OpenCode hosted models (default) |
| `anthropic` | Anthropic Claude models |
| `openai` | OpenAI GPT models |
| `google` | Google Gemini models |
| `zhipu` | Zhipu GLM models |

## Default Free Model

```
opencode/big-pickle
```

No billing required for testing.

## Paid Models (require API key with credits)

| Model | Provider | Description |
|---|---|---|
| `claude-sonnet-4-5` | anthropic | Claude Sonnet 4.5 |
| `gpt-4o` | openai | GPT-4o |
| `gemini-2.0-flash` | google | Gemini 2.0 Flash |
| `glm-5.0` | zhipu | GLM-5.0 |

## Getting API Keys

1. Sign in at [opencode.ai](https://opencode.ai)
2. Navigate to **API Keys** or **Account Settings**
3. Generate a new key

## Environment Configuration

```env
OPENCODE_MODEL_PROVIDER=opencode
OPENCODE_MODEL_ID=big-pickle
```

Or with external providers:

```env
OPENCODE_MODEL_PROVIDER=anthropic
OPENCODE_MODEL_ID=claude-sonnet-4-5
OPENCODE_API_KEY=sk-ant-...  # Anthropic key
```

## Cloud API Endpoints

| Provider | Endpoint |
|---|---|
| OpenCode Cloud | `https://api.opencode.ai` |
| Anthropic | `https://api.anthropic.com` |
| OpenAI | `https://api.openai.com/v1` |
| Google | `https://generativelanguage.googleapis.com/v1beta` |
| Zhipu | `https://open.bigmodel.cn/api/paas/v4` |

## Model Selection Tips

- **Testing/Development:** Use `opencode/big-pickle` (free)
- **Production:** Use paid models for better quality
- **Fast Response:** `opencode/big-pickle` or `google/gemini-2.0-flash`
- **Long Context:** `anthropic/claude-sonnet-4-5` (200k context)
