---
name: telegram-39
description: OpenCode Telegram Bot project (grinev/opencode-telegram-bot). Use when working with the OpenCode Telegram Bot on Linux — cloud-only setup, grammY handlers, TypeScript commands (/shell, /ls, /read), session management, SSE streaming, systemd deployment, and OpenCode Cloud API integration. Triggered when user mentions the OpenCode Telegram Bot, grammY, cloud bridge, or the grinev/opencode-telegram-bot project.
---

# OpenCode Telegram Bot Skill — Cloud API Mode

Guides setup, extension, and troubleshooting of the grinev/opencode-telegram-bot project on Linux using **OpenCode Cloud API only** (no local OpenCode server).

---

## Architecture

```
Phone (Telegram)
       │
       ▼ polling (no open ports)
Telegram Bot API
       │
       ▼
[opencode-telegram-bot]  ← runs on LOCAL Linux PC (middleman)
   grammY (TypeScript)
       │
       ▼ HTTPS API calls
[OpenCode Cloud API]  ← runs REMOTELY in the cloud
   api.opencode.ai
       │
       ▼
AI Model (cloud-hosted)
```

**Key facts:**
- Bot runs **locally** via polling — no open ports, no nginx, no domain
- OpenCode **runs exclusively in the cloud** at `api.opencode.ai` — no `opencode serve` needed
- `/shell`, `/ls`, `/read` execute on your **local PC** via OpenCode Cloud SDK
- Results stream back via **SSE (Server-Sent Events)**
- Security: `TELEGRAM_ALLOWED_USER_ID` restricts access to one user
- Session state is **single-user, in-memory** — resets on bot restart

---

## Environment Setup (Linux)

### System packages

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl git build-essential
```

### Node.js 20+

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
source ~/.bashrc   # or ~/.zshrc
nvm install 20
nvm use 20
```

### Clone & install

```bash
git clone https://github.com/grinev/opencode-telegram-bot.git
cd opencode-telegram-bot
npm install
```

---

## Configuration (.env)

```env
# REQUIRED
TELEGRAM_BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrsTUVwxyz
TELEGRAM_ALLOWED_USER_ID=987654321

# OPENCODE CLOUD API — NOT localhost
OPENCODE_API_URL=https://api.opencode.ai
OPENCODE_API_KEY=your_opencode_api_key_here

# MODEL
OPENCODE_MODEL_PROVIDER=opencode
OPENCODE_MODEL_ID=big-pickle   # free default

# OPTIONAL
BOT_LOCALE=en
LOG_LEVEL=info
```

> **Critical:** `OPENCODE_API_URL` points to the **cloud endpoint** only. Local OpenCode server (`http://localhost:4096`) is NOT used in this setup.

---

## Project Structure

```
opencode-telegram-bot/
├── .env
├── .env.example
├── package.json
├── tsconfig.json
├── src/
│   ├── index.ts              ← entry point
│   ├── bot/
│   │   ├── index.ts          ← bot setup, command wiring  ← MODIFY
│   │   ├── commands/
│   │   │   ├── definitions.ts    ← command registry       ← MODIFY
│   │   │   ├── shell.ts         ← NEW: /shell handler
│   │   │   ├── ls.ts            ← NEW: /ls handler
│   │   │   └── read.ts          ← NEW: /read handler
│   │   ├── handlers/
│   │   │   └── prompt.ts        ← existing prompt flow
│   │   └── utils/
│   │       └── chunk.ts          ← NEW: Telegram-safe chunking
│   ├── opencode/
│   │   ├── client.ts         ← SDK wrapper → cloud API
│   │   └── events.ts         ← SSE subscription
│   ├── session/
│   │   └── manager.ts        ← session state (single-user, in-memory)
│   └── summary/
│       └── formatter.ts       ← Telegram formatting
└── dist/                     ← compiled output
```

---

## Adding Commands (/shell, /ls, /read)

### src/bot/utils/chunk.ts

```typescript
/**
 * Splits output into Telegram-safe chunks (max 4000 chars)
 * and escapes HTML special characters for <pre><code> blocks.
 * NOTE: & must be escaped first to prevent double-escaping.
 */
export function chunkOutput(text: string, maxLength: number = 4000): string[] {
    if (!text || text.trim() === "") return ["(no output)"];

    const escaped = text
        .replace(/&/g, "&amp;")   // MUST be first!
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");

    const chunks: string[] = [];
    for (let i = 0; i < escaped.length; i += maxLength) {
        chunks.push(escaped.substring(i, i + maxLength));
    }
    return chunks;
}
```

### src/bot/commands/shell.ts

```typescript
import { CommandContext, Context } from "grammy";
import { opencodeClient } from "../../opencode/client.js";
import { getCurrentSession, setCurrentSession, type SessionInfo } from "../../session/manager.js";
import { logger } from "../../utils/logger.js";
import { chunkOutput } from "../utils/chunk.js";

export async function shellCommand(ctx: CommandContext<Context>) {
    const command = (ctx.match as string)?.trim();
    
    if (!command) {
        await ctx.reply(
            "⚠️ Please provide a command.\nUsage: <code>/shell ls -la</code>",
            { parse_mode: "HTML" }
        );
        return;
    }

    const statusMsg = await ctx.reply(
        `⏳ <i>Running locally: <code>${command}</code>...</i>`,
        { parse_mode: "HTML" }
    );

    try {
        // Single-user session manager - no userId parameter
        let session = getCurrentSession();
        if (!session) {
            const { data: newSession, error } = await opencodeClient.session.create({});
            if (error || !newSession) {
                throw error || new Error("Failed to create session");
            }
            
            const sessionInfo: SessionInfo = {
                id: newSession.id,
                title: newSession.title,
                directory: newSession.directory || "",
            };
            setCurrentSession(sessionInfo);
            session = sessionInfo;
        }

        // Execute via OpenCode Cloud SDK
        const { data, error } = await opencodeClient.session.shell({
            path: { id: session.id },
            body: { command },
        });

        if (error) {
            throw error instanceof Error ? error : new Error(String(error));
        }

        const rawOutput =
            (data as { stdout?: string; stderr?: string })?.stdout ||
            (data as { stdout?: string; stderr?: string })?.stderr ||
            "Command executed (no output).";

        const chunks = chunkOutput(rawOutput);
        await ctx.api.deleteMessage(ctx.chat!.id, statusMsg.message_id);

        for (let i = 0; i < chunks.length; i++) {
            const header = chunks.length > 1
                ? `💻 <b>Shell Output (${i + 1}/${chunks.length}):</b>\n`
                : `💻 <b>Shell Output:</b>\n`;
            await ctx.reply(
                `${header}<pre><code>${chunks[i]}</code></pre>`,
                { parse_mode: "HTML" }
            );
        }
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        logger.error("[Bot] Shell command error:", error);
        await ctx.api.editMessageText(
            ctx.chat!.id,
            statusMsg.message_id,
            `❌ <b>Error:</b>\n<pre>${message}</pre>`,
            { parse_mode: "HTML" }
        ).catch(() => {});
    }
}
```

### src/bot/commands/ls.ts

```typescript
import { CommandContext, Context } from "grammy";
import { opencodeClient } from "../../opencode/client.js";
import { getCurrentSession, setCurrentSession, type SessionInfo } from "../../session/manager.js";
import { logger } from "../../utils/logger.js";
import { chunkOutput } from "../utils/chunk.js";

export async function lsCommand(ctx: CommandContext<Context>) {
    const targetPath = (ctx.match as string)?.trim() || ".";

    const statusMsg = await ctx.reply(
        `📂 <i>Listing: ${targetPath}...</i>`,
        { parse_mode: "HTML" }
    );

    try {
        let session = getCurrentSession();
        if (!session) {
            const { data: newSession, error } = await opencodeClient.session.create({});
            if (error || !newSession) {
                throw error || new Error("Failed to create session");
            }
            
            const sessionInfo: SessionInfo = {
                id: newSession.id,
                title: newSession.title,
                directory: newSession.directory || "",
            };
            setCurrentSession(sessionInfo);
            session = sessionInfo;
        }

        const { data, error } = await opencodeClient.session.shell({
            path: { id: session.id },
            body: { command: `ls -la ${targetPath}` },
        });

        if (error) {
            throw error instanceof Error ? error : new Error(String(error));
        }

        const rawOutput =
            (data as { stdout?: string; stderr?: string })?.stdout ||
            (data as { stdout?: string; stderr?: string })?.stderr ||
            "(empty directory)";

        const chunks = chunkOutput(rawOutput);
        await ctx.api.deleteMessage(ctx.chat!.id, statusMsg.message_id);

        for (let i = 0; i < chunks.length; i++) {
            await ctx.reply(
                `📂 <b>${targetPath}</b>\n<pre><code>${chunks[i]}</code></pre>`,
                { parse_mode: "HTML" }
            );
        }
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        logger.error("[Bot] LS command error:", error);
        await ctx.api.editMessageText(
            ctx.chat!.id,
            statusMsg.message_id,
            `❌ <b>Error listing directory:</b>\n<pre>${message}</pre>`,
            { parse_mode: "HTML" }
        ).catch(() => {});
    }
}
```

### src/bot/commands/read.ts

```typescript
import { CommandContext, Context } from "grammy";
import { opencodeClient } from "../../opencode/client.js";
import { getCurrentSession, setCurrentSession, type SessionInfo } from "../../session/manager.js";
import { logger } from "../../utils/logger.js";
import { chunkOutput } from "../utils/chunk.js";

export async function readCommand(ctx: CommandContext<Context>) {
    const targetFile = (ctx.match as string)?.trim();
    
    if (!targetFile) {
        await ctx.reply(
            "⚠️ Please provide a file path.\nUsage: <code>/read src/index.ts</code>",
            { parse_mode: "HTML" }
        );
        return;
    }

    const statusMsg = await ctx.reply(
        `📄 <i>Reading: ${targetFile}...</i>`,
        { parse_mode: "HTML" }
    );

    try {
        let session = getCurrentSession();
        if (!session) {
            const { data: newSession, error } = await opencodeClient.session.create({});
            if (error || !newSession) {
                throw error || new Error("Failed to create session");
            }
            
            const sessionInfo: SessionInfo = {
                id: newSession.id,
                title: newSession.title,
                directory: newSession.directory || "",
            };
            setCurrentSession(sessionInfo);
            session = sessionInfo;
        }

        const { data, error } = await opencodeClient.session.shell({
            path: { id: session.id },
            body: { command: `cat ${targetFile}` },
        });

        if (error) {
            throw error instanceof Error ? error : new Error(String(error));
        }

        const stdout = (data as { stdout?: string; stderr?: string })?.stdout;
        const stderr = (data as { stdout?: string; stderr?: string })?.stderr;

        if (stderr && !stdout) {
            throw new Error(stderr);
        }

        const chunks = chunkOutput(stdout || "(empty file)");
        await ctx.api.deleteMessage(ctx.chat!.id, statusMsg.message_id);

        for (let i = 0; i < chunks.length; i++) {
            const header = chunks.length > 1
                ? `📄 <b>${targetFile} (Part ${i + 1}/${chunks.length}):</b>\n`
                : `📄 <b>${targetFile}:</b>\n`;
            await ctx.reply(
                `${header}<pre><code>${chunks[i]}</code></pre>`,
                { parse_mode: "HTML" }
            );
        }
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        logger.error("[Bot] Read command error:", error);
        await ctx.api.editMessageText(
            ctx.chat!.id,
            statusMsg.message_id,
            `❌ <b>Error reading file:</b>\n<pre>${message}</pre>`,
            { parse_mode: "HTML" }
        ).catch(() => {});
    }
}
```

### Wire commands into src/bot/index.ts

```typescript
import { shellCommand } from "./commands/shell.js";
import { lsCommand } from "./commands/ls.js";
import { readCommand } from "./commands/read.js";

bot.command("shell", shellCommand);
bot.command("ls", lsCommand);
bot.command("read", readCommand);
```

> **Important:** Register these **before** any fallback text handler. grammY matches in order.

### Add to src/bot/commands/definitions.ts

```typescript
{ command: "shell", descriptionKey: "cmd.description.shell" },
{ command: "ls", descriptionKey: "cmd.description.ls" },
{ command: "read", descriptionKey: "cmd.description.read" },
```

### Add translations to src/i18n/en.ts

```typescript
"cmd.description.shell": "Execute a shell command on this PC",
"cmd.description.ls": "List directory contents on this PC",
"cmd.description.read": "Read a local file's contents",
```

### Build and test

```bash
npm run build   # 0 errors expected
npm run lint    # 0 warnings expected
npm run dev
```

Test:
```
/shell pwd
/shell ls -la
/ls src
/read package.json
```

---

## Running as systemd Service

Create `/etc/systemd/system/opencode-telegram-bot.service`:

```ini
[Unit]
Description=OpenCode Telegram Bot
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=YOUR_USERNAME
WorkingDirectory=/home/YOUR_USERNAME/opencode-telegram-bot
ExecStart=/home/YOUR_USERNAME/.nvm/versions/node/v20.0.0/bin/node dist/index.js
Restart=always
RestartSec=5
EnvironmentFile=/home/YOUR_USERNAME/opencode-telegram-bot/.env

[Install]
WantedBy=multi-user.target
```

Enable:

```bash
sudo systemctl daemon-reload
sudo systemctl enable opencode-telegram-bot
sudo systemctl start opencode-telegram-bot
sudo systemctl status opencode-telegram-bot

# View logs:
journalctl -u opencode-telegram-bot -f
```

---

## Environment Variables Reference

| Variable | Required | Default | Description |
|---|---|---|---|
| `TELEGRAM_BOT_TOKEN` | ✅ | — | Token from @BotFather |
| `TELEGRAM_ALLOWED_USER_ID` | ✅ | — | Your numeric Telegram ID |
| `OPENCODE_API_URL` | ✅ | `https://api.opencode.ai` | **Cloud API only** — NOT localhost |
| `OPENCODE_API_KEY` | ✅ | — | API key from OpenCode dashboard |
| `OPENCODE_MODEL_PROVIDER` | ✅ | `opencode` | Model provider |
| `OPENCODE_MODEL_ID` | ✅ | `big-pickle` | Model ID |
| `BOT_LOCALE` | — | `en` | UI language (`en` or `ru`) |
| `LOG_LEVEL` | — | `info` | `debug` / `info` / `warn` / `error` |

---

## Troubleshooting

### Bot doesn't respond
- Verify `TELEGRAM_ALLOWED_USER_ID` matches your ID (check with @userinfobot)
- Confirm `npm run dev` is running with no errors
- Check: `journalctl -u opencode-telegram-bot -f`

### "OpenCode API is not available"
- Check internet connection
- Verify `OPENCODE_API_URL` points to cloud (`https://api.opencode.ai`)
- Test endpoint: `curl -H "Authorization: Bearer YOUR_KEY" https://api.opencode.ai/health`

### TypeScript build errors
- Verify imports match exact file paths with `.js` extensions
- Ensure `src/bot/utils/` directory exists before creating `chunk.ts`
- Run `npm run lint` for detailed errors

### `/shell` returns "session not found"
- Session state is **single-user, in-memory** — resets on bot restart
- Send any text prompt first to initialize session, then use `/shell`

### Bot stops responding after a while
- Use systemd with `Restart=always`
- Never use `nodemon` — it breaks SSE streams mid-task
- Prevent laptop suspend: `sudo systemctl mask sleep.target suspend.target`

### HTML entities showing as text in Telegram
- Check that `chunk.ts` escapes `&` **first** as `&amp;`, then `<` and `>`
- Wrong order causes rendering issues

---

## Constraints & Rules

1. **DO NOT break existing functionality** — all existing commands must continue working
2. **DO NOT modify** `src/opencode/client.ts` or `src/opencode/events.ts`
3. **DO NOT modify** `src/session/manager.ts` — single-user design, no userId parameter
4. **Use `.js` extensions** in all imports (ESM: `import { ... } from "./foo.js"`)
5. **Use `CommandContext<Context>`** type for command handlers
6. **Use `logger`** from `../../utils/logger.js` for logging
7. **Register commands BEFORE** `bot.on("message:text", ...)` in `bot/index.ts`
8. **After all changes:** `npm run build && npm run lint` — must be clean

---

## Further Reference

- `references/cloud-bridge.md` — Python cloud bridge alternative (for non-Linux systems)
- `references/api-models.md` — Available OpenCode models and providers
