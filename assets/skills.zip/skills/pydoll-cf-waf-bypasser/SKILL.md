---
name: pydoll-cf-waf-bypasser
description: 使用PyDoll通过CDP协议绕过Cloudflare Turnstile/CAPTCHA。当用户需要绕过Cloudflare保护或需要无头浏览器通过人机验证时触发。
---

# PyDoll - Cloudflare WAF绕过

## 核心概念

PyDoll 是一个基于CDP（Chrome DevTools Protocol）的无头浏览器框架，专门用于绕过Cloudflare的Turnstile和CAPTCHA挑战。它通过直接与Chrome浏览器通信，模拟真实用户行为来通过人机验证。

## 工作流程

### 1. 启动浏览器
```python
from pydoll import Chrome

with Chrome(headless=False) as driver:
    # 访问目标站点
    driver.get("https://target-site.com")
    
    # PyDoll会自动处理Cloudflare挑战
    # 等待页面加载完成
    driver.wait_for_element("body")
    
    # 执行后续操作
    content = driver.find_element("body").text
    print(content)
```

### 2. 处理Turnstile
PyDoll自动检测并处理Cloudflare Turnstile挑战，无需手动干预。

### 3. Shadow DOM支持
```python
from pydoll import Chrome
from pydoll.extensions.shadow_dom import deep_query

with Chrome() as driver:
    driver.get("https://target-site.com")
    
    # 穿透Shadow DOM
    shadow_host = driver.find_element("#shadow-host")
    shadow_content = deep_query(shadow_host, ".inner-element")
```

### 4. 等待条件
```python
# 等待元素出现
element = driver.wait_for_element("#target", timeout=30)

# 等待JavaScript条件
driver.wait_until("return document.readyState === 'complete'")

# 等待URL匹配
driver.wait_for_url("**/dashboard**")
```

## 反检测特性

- 真实的Chrome浏览器实例（非模拟）
- CDP协议原生支持
- 自动处理Cloudflare挑战
- Shadow DOM穿透能力
- JavaScript执行环境保持

## 适用场景

- 绕过Cloudflare保护的网站
- 需要通过Turnstile/CAPTCHA验证
- 需要执行JavaScript渲染的内容
- Shadow DOM内内容的抓取
- 需要保持登录态的自动化操作

## 安装

```bash
pip install pydoll
```

## 注意事项

- 需要本地安装Chrome/Chromium浏览器
- 部分网站可能需要额外的绕过技术
- 遵守目标网站的robots.txt和服务条款
