---
name: skill-scanner-ai
description: Best-effort security scanner for AI Agent Skills detecting prompt injection, data exfiltration, and malicious code patterns. Supports OpenAI Codex Skills and Cursor Agent Skills. Use when auditing AI agent skills for security vulnerabilities.
---

# Skill Scanner - AI Agent Skill Security

## When to Use

- **AI skill auditing** - Scan AI agent skills for vulnerabilities
- **Prompt injection detection** - Find prompt injection in skill definitions
- **Data exfiltration** - Detect credential/PII exfiltration patterns
- **CI/CD integration** - Pre-commit hooks for skill security

## Features

- **Multi-engine detection**: Static analysis, behavioral dataflow, LLM-as-a-judge
- **SARIF output** - GitHub Code Scanning integration
- **Pre-commit hooks** - Automated scanning before commit
- **AI editor support**: OpenAI Codex Skills, Cursor Agent Skills
- **1,710 stars** - Industry-recognized tool

## Installation

```bash
# Via uv (recommended)
uv pip install cisco-ai-skill-scanner

# Or via pip
pip install cisco-ai-skill-scanner[bedrock]

# With full features
pip install cisco-ai-skill-scanner[all]
```

## Usage

### CLI
```bash
# Scan single skill
skill-scanner scan ./my-skill

# Scan directory
skill-scanner scan ./skills-folder

# JSON output
skill-scanner scan ./skill --format sarif > results.sarif
```

### Pre-commit Hook
```yaml
# .pre-commit-config.yaml
repos:
  - repo: https://github.com/cisco-ai-defense/skill-scanner
    rev: v1.0.0
    hooks:
      - id: skill-scanner
```

## Detection Patterns

| Category | Patterns |
|----------|----------|
| **Prompt Injection** | Direct injection, role manipulation, context poisoning |
| **Data Exfiltration** | Credential access, PII leakage, network calls |
| **Malicious Code** | Command execution, file system access, network exfil |
| **Tool Abuse** | Unauthorized tool calls, privilege escalation |

## Integration with Systemv2.5

| Systemv2.5 Category | Skill Scanner Capability |
|---------------------|-------------------------|
| AI Threat Testing | Prompt injection in AI skills |
| MCP Security | AI agent skill auditing |
| Security Review | Automated skill vulnerability scanning |

## Supported Platforms

- OpenAI Codex Skills
- Cursor Agent Skills
- Claude Code skills (with adaptation)
- Generic AI agent configurations