# RustScan

The Modern Port Scanner — find ports quickly (3 seconds for all 65,535 ports), automatically pipe results to Nmap for service detection.

## When to Use

- Fast port discovery (full 65k ports in seconds)
- Bug bounty reconnaissance
- Network mapping before penetration tests
- When you need speed + Nmap深度分析

## Features

- **Speed**: Scans 65,535 ports in ~3 seconds
- **Auto-pipe**: Automatically feeds results into Nmap
- **Adaptive Learning**: Improves based on your usage patterns
- **Scripting Engine**: Run custom scripts (Python, Lua, Shell)
- **IPv6 Support**: Full IPv6 scanning capability

## Installation

```bash
# macOS
brew install rustscan

# Cargo
cargo install rustscan

# Docker
docker pull rustscan/rustscan:2.0.0
```

## Basic Usage

```bash
# Quick scan single host
rustscan -a 192.168.1.1

# Scan with Nmap integration
rustscan -a target.com -- -sV -sC -oN scan results

# Adjust speed (ulimit)
rustscan -a 192.168.1.1 --ulimit 5000

# Batch scan multiple IPs
cat targets.txt | rustscan

# JSON output
rustscan -a 192.168.1.1 --greppable
```

## Common Commands

| Command | Description |
|---------|-------------|
| `rustscan -a <IP>` | Basic scan |
| `rustscan -a <IP> --top-ports 100` | Top 100 ports |
| `rustscan -a <IP> -oJ output.json` | JSON output |
| `rustscan -a <IP> --ulimit 5000` | Faster scanning |
| `rustscan -a <IP> -- -sV` | Pipe to Nmap |

## Comparison

| Tool | Speed | Best For |
|------|-------|----------|
| RustScan | ~3s (65k ports) | Fast discovery + Nmap |
| Nmap | Minutes | Deep service analysis |
| Masscan | ~3s | Pure speed, no scripts |
| Naabu | Fast | Bug bounty friendly |

## Notes

- Requires libpcap: `sudo apt install libpcap-dev`
- Run as root for SYN scans
- Use `--ulimit` to control scan speed
- Adaptive learning improves over time